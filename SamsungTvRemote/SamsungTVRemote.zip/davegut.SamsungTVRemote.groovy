/*	===== HUBITAT INTEGRATION VERSION =====================================================
Hubitat - Samsung TV Remote Driver
		Copyright 2022 Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== 2022 Version 4.1 ====================================================================
Version 4.1-2
a.	Fix issue of commands sometimes not executing when WS is closed by increasing delay
	between wsOpen and sendCommand.
b.	Added wsOpen and wsClose to user interface per request.
c.	Clarified "conflict" error on SmartThings Command with additional message. If a
	Conflict is detected, the device is off-line in SmartThings.  It can take several
	minutes for ST to detect.  This is a ST issue.
d.	Created libraries to ease code maintenance and reuse.
===========================================================================================*/
def driverVer() { return "4.1-2" }
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

metadata {
	definition (name: "Samsung TV Remote",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungTvRemote/SamsungTVRemote.groovy"
			   ){
		capability "Refresh"
		capability "Configuration"
		capability "SamsungTV"
		command "showMessage", [[name: "Not Implemented"]]
		capability "Switch"
		capability "PushableButton"
		capability "Variable"
	}
	preferences {
		input ("deviceIp", "text", title: "Samsung TV Ip", defaultValue: "")
		if (deviceIp) {
			input ("tvPwrOnMode", "enum", title: "TV Startup Display", 
				   options: ["ART_MODE", "Ambient", "none"], defaultValue: "none")
			input ("logEnable", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
			input ("infoLog", "bool", 
				   title: "Enable information logging " + helpLogo(),
				   defaultValue: true)
			input ("traceLog", "bool", title: "Enable trace logging as directed by developer", defaultValue: false)
			stPreferences()
		}
		def onPollOptions = ["local": "Local", "off": "DISABLE"]
		input ("pollMethod", "enum", title: "Power Polling Method", defaultValue: "local",
			   options: onPollOptions)
		input ("pollInterval","enum", title: "Power Polling Interval (seconds)",
			   options: ["off", "10", "15", "20", "30", "60"], defaultValue: "60")
		tvAppsPreferences()
	}
}

String helpLogo() { // library marker davegut.kasaCommon, line 11
	return """<a href="https://github.com/DaveGut/HubitatActive/blob/master/SamsungTvRemote/README.md">""" +
		"""<div style="position: absolute; top: 10px; right: 10px; height: 80px; font-size: 20px;">Samsung TV Remote Help</div></a>"""
}

//	===== Installation, setup and update =====
def installed() {
	state.token = "12345678"
	def tokenSupport = "false"
	sendEvent(name: "wsStatus", value: "closed")
	sendEvent(name: "wsStatus", value: "45")
	runIn(1, updated)
}

def updated() {
	unschedule()
	close()
	def updStatus = [:]
	if (!deviceIp) {
		logWarn("\n\n\t\t<b>Enter the deviceIp and Save Preferences</b>\n\n")
		updStatus << [status: "ERROR", data: "Device IP not set."]
	} else {
		if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
			updateDataValue("driverVersion", driverVer())
			updStatus << [driverVer: driverVer()]
		}
		if (logEnable) { runIn(1800, debugLogOff) }
		if (traceLog) { runIn(600, traceLogOff) }
		updStatus << [logEnable: logEnable, infoLog: infoLog, traceLog: traceLog]
		updStatus << [setOnPollInterval: setOnPollInterval()]
		if (!pollMethod) {
			pollMethod = "local"
			device.updateSetting("pollMethod", [type:"enum", value: "local"])
		}
		updStatus << [pollMethod: newPollMethod]
		if (!state.appData) { state.appData == [:] }
		if (findAppCodes) {
			runIn(1, updateAppCodes)
		}
		runIn(1, configure)
	}
	sendEvent(name: "numberOfButtons", value: 45)
	sendEvent(name: "wsStatus", value: "closed")
	updStatus << [attributes: listAttributes()]
	state.standbyTest = false
	logInfo("updated: ${updStatus}")
	logTrace("updated: onPollCount = $state.onPollCount")
	state.onPollCount = 0
}

def setOnPollInterval() {
	if (pollMethod == "off") {
		pollInterval = "DISABLED"
		device.updateSetting("pollInterval", [type:"enum", value: "off"])
	} else {
		if (pollInterval == null) {
			pollInterval = "60"
			device.updateSetting("pollInterval", [type:"enum", value: "60"])
		}
		if (pollInterval == "60") {
			runEvery1Minute(onPoll)
		} else if (pollInterval != "off") {
			schedule("0/${pollInterval} * * * * ?",  onPoll)
		}
	}
	return pollInterval
}

def configure() {
	def respData = [:]
	def tvData = [:]
	try{
		httpGet([uri: "http://${deviceIp}:8001/api/v2/", timeout: 5]) { resp ->
			tvData = resp.data
			runIn(1, getArtModeStatus)
		}
	} catch (error) {
		tvData << [status: "error", data: error]
		logError("configure: TV Off during setup or Invalid IP address.\n\t\tTurn TV On and Run CONFIGURE or Save Preferences!")

	}
	if (!tvData.status) {
		def wifiMac = tvData.device.wifiMac
		updateDataValue("deviceMac", wifiMac)
		def alternateWolMac = wifiMac.replaceAll(":", "").toUpperCase()
		updateDataValue("alternateWolMac", alternateWolMac)
		device.setDeviceNetworkId(alternateWolMac)
		def modelYear = "20" + tvData.device.model[0..1]
		updateDataValue("modelYear", modelYear)
		def frameTv = "false"
		if (tvData.device.FrameTVSupport) {
			frameTv = tvData.device.FrameTVSupport
		}
		updateDataValue("frameTv", frameTv)
		if (tvData.device.TokenAuthSupport) {
			tokenSupport = tvData.device.TokenAuthSupport
			updateDataValue("tokenSupport", tokenSupport)
		}
		def uuid = tvData.device.duid.substring(5)
		updateDataValue("uuid", uuid)
		respData << [status: "OK", dni: alternateWolMac, modelYear: modelYear,
					 frameTv: frameTv, tokenSupport: tokenSupport]
		sendEvent(name: "artModeStatus", value: "none")
		def data = [request:"get_artmode_status",
					id: "${getDataValue("uuid")}"]
		data = JsonOutput.toJson(data)
		artModeCmd(data)
		state.configured = true
	} else {
		respData << tvData
	}
	runIn(1, stUpdate)
	logInfo("configure: ${respData}")
	return respData
}

//	===== Polling/Refresh Capability =====
def onPoll() {
	if (traceLog) { state.onPollCount += 1 }
	if (pollMethod == "st") {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "stPollParse"
			]
		asyncGet(sendData, "stPollParse")
	} else if (pollMethod == "local") {
		def sendCmdParams = [
			uri: "http://${deviceIp}:8001/api/v2/",
			timeout: 6
		]
		asynchttpGet("onPollParse", sendCmdParams)
	} else {
		logWarn("onPoll: Polling is disabled")
	}
	if (getDataValue("driverVersion") != driverVer()) {
		logInfo("Auto Configuring changes to this TV.")
		updated()
		pauseExecution(3000)
	}
}

def stPollParse(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			def onOff = respData.components.main.switch.switch.value
			if (device.currentValue("switch") != onOff) {
				logInfo("stPollParse: [switch: ${onOff}]")
				sendEvent(name: "switch", value: onOff)
				if (onOff == "on") {
					runIn(3, setPowerOnMode)
				} else {
					close()
				}
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("stPollParse: ${respLog}")
	}
}

def onPollParse(resp, data) {
	def powerState
	if (resp.status == 200) {
		def tempPower = new JsonSlurper().parseText(resp.data).device.PowerState
		if (tempPower == null) {
			powerState = "on"
		} else { 
			powerState = tempPower
		}
	} else {
		logTrace("onPollParse: [state: error, status: $resp.status]")
		powerState = "NC"
	}
	def onOff = "on"
	if (powerState == "on") {
		state.standbyTest = false
		onOff = "on"
	} else {
		if (device.currentValue("switch") == "on") {
			//	If currently on, will need two non-"on" values to set switch off
			if (!state.standbyTest) {
				state.standbyTest = true
				runIn(5, onPoll)
			} else {
				state.standbyTest = false
				onOff = "off"
			}
		} else {
			//	If powerState goes to standby, this indicates tv screen is off
			//	as the tv powers down (takes 0.5 to 2 minutes to disconnect).
			onOff = "off"
		}
		logTrace("onPollParse: [switch: ${device.currentValue("switch")}, onOff: ${onOff}, powerState: $powerState, stbyTest: $state.standbyTest]")
	}
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff)
		if (onOff == "on") {
			runIn(5, setPowerOnMode)
			refresh()
		} else {
			close()
			refresh()
		}
		logInfo("onPollParse: [switch: ${onOff}, powerState: ${powerState}]")
	}
}

//	===== Capability Switch =====

def on() {
	logInfo("on: [frameTv: ${getDataValue("frameTv")}]")
	def wolMac = getDataValue("alternateWolMac")
	def cmd = "FFFFFFFFFFFF$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac"
	wol = new hubitat.device.HubAction(
		cmd,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "255.255.255.255:7",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING])
	sendHubCommand(wol)
	runIn(5, onPoll)
}

def setPowerOnMode() {
	logInfo("setPowerOnMode: [tvPwrOnMode: ${tvPwrOnMode}]")
	if(tvPwrOnMode == "ART_MODE") {
		getArtModeStatus()
		pauseExecution(1000)
		artMode()
	} else if (tvPwrOnMode == "Ambient") {
		ambientMode()
	}
	refresh()
}

def off() {
	logInfo("off: [frameTv: ${getDataValue("frameTv")}]")
	sendKey("POWER", "Press")
	pauseExecution(3000)
	sendKey("POWER", "Release")
	runIn(5, onPoll)
}

//	===== BUTTON INTERFACE =====
def push(pushed) {
	logDebug("push: button = ${pushed}, trigger = ${state.triggered}")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	pushed = pushed.toInteger()
	switch(pushed) {
		//	===== Physical Remote Commands =====
		case 2 : mute(); break
		case 3 : numericKeyPad(); break
		case 4 : Return(); break
		case 6 : artMode(); break
		case 7 : ambientMode(); break
		case 45: ambientmodeExit(); break
		case 8 : arrowLeft(); break
		case 9 : arrowRight(); break
		case 10: arrowUp(); break
		case 11: arrowDown(); break
		case 12: enter(); break
		case 13: exit(); break
		case 14: home(); break
		case 18: channelUp(); break
		case 19: channelDown(); break
		case 20: guide(); break
		case 21: volumeUp(); break
		case 22: volumeDown(); break
		//	===== Direct Access Functions
		case 23: menu(); break
		case 24: source(); break
		case 25: info(); break
		case 26: channelList(); break
		//	===== Other Commands =====
		case 34: previousChannel(); break
		case 35: hdmi(); break
		case 36: fastBack(); break
		case 37: fastForward(); break
		//	===== Application Interface =====
		case 38: appOpenByName("Browser"); break
		case 39: appOpenByName("YouTube"); break
		case 40: appOpenByName("RunNetflix"); break
		case 41: close()
		case 42: toggleSoundMode(); break
		case 43: togglePictureMode(); break
		case 44: appOpenByName(device.currentValue("variable")); break
		default:
			logDebug("push: Invalid Button Number!")
			break
	}
}

//	===== Libraries =====
#include davegut.samsungTvWebsocket
#include davegut.samsungTvApps
#include davegut.SmartThingsInterface
#include davegut.samsungTvST
#include davegut.Logging
