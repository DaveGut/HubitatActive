library (
	name: "samsungTvST",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung TV SmartThings Capabilities",
	category: "utilities",
	documentationLink: ""
)

command "toggleInputSource", [[name: "SmartThings Function"]]
command "toggleSoundMode", [[name: "SmartThings Function"]]
command "togglePictureMode", [[name: "SmartThings Function"]]
command "setTvChannel", ["SmartThings Function"]
attribute "tvChannel", "string"
attribute "tvChannelName", "string"
command "setInputSource", ["SmartThings Function"]
attribute "inputSource", "string"
command "setVolume", ["SmartThings Function"]
command "setPictureMode", ["SmartThings Function"]
command "setSoundMode", ["SmartThings Function"]
command "setLevel", ["SmartThings Function"]
attribute "transportStatus", "string"
attribute "level", "NUMBER"
attribute "trackDescription", "string"


/*
def stPreferences() {
	input ("connectST", "bool", title: "Connect to SmartThings for added functions", defaultValue: false)
	if (connectST) {
		onPollOptions = ["st": "SmartThings", "local": "Local", "off": "DISABLE"]
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		input ("stPollInterval", "enum", title: "SmartThings Poll Interval (minutes)",
			   options: ["off", "1", "5", "15", "30"], defaultValue: "15")
		input ("stTestData", "bool", title: "Get ST data dump for developer", defaultValue: false)
	}

	
}

def stUpdate() {
	def stData = [:]
	if (connectST) {
		stData << [connectST: "true"]
		stData << [connectST: connectST]
		if (!stApiKey || stApiKey == "") {
			logWarn("\n\n\t\t<b>Enter the ST API Key and Save Preferences</b>\n\n")
			stData << [status: "ERROR", date: "no stApiKey"]
		} else if (!stDeviceId || stDeviceId == "") {
			getDeviceList()
			logWarn("\n\n\t\t<b>Enter the deviceId from the Log List and Save Preferences</b>\n\n")
			stData << [status: "ERROR", date: "no stDeviceId"]
		} else {
			if (device.currentValue("volume") == null) {
//				sendEvent(name: "volume", value: 0)
//				sendEvent(name: "level", value: 0)
			}
			def stPollInterval = stPollInterval
			if (stPollInterval == null) { 
				stPollInterval = "15"
				device.updateSetting("stPollInterval", [type:"enum", value: "15"])
			}
			switch(stPollInterval) {
				case "1" : runEvery1Minute(refresh); break
				case "5" : runEvery5Minutes(refresh); break
				case "15" : runEvery15Minutes(refresh); break
				case "30" : runEvery30Minutes(refresh); break
				default: unschedule("refresh")
			}
			deviceSetup()
			stData << [stPollInterval: stPollInterval]
		}
	} else {
		stData << [connectST: "false"]
	}
	logInfo("stUpdate: ${stData}")
}

def deviceSetup() {
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "deviceSetup")
	}
}

def getDeviceList() {
	def sendData = [
		path: "/devices",
		parse: "getDeviceListParse"
		]
	asyncGet(sendData)
}

def getDeviceListParse(resp, data) {
	def respData
	if (resp.status != 200) {
		respData = [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	} else {
		try {
			respData = new JsonSlurper().parseText(resp.data)
		} catch (err) {
			respData = [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	}
	if (respData.status == "ERROR") {
		logWarn("getDeviceListParse: ${respData}")
	} else {
		log.info ""
		respData.items.each {
			log.trace "${it.label}:   ${it.deviceId}"
		}
		log.trace "<b>Copy your device's deviceId value and enter into the device Preferences.</b>"
	}
}

def deviceSetupParse(mainData) {
	def setupData = [:]
	def supportedInputs =  mainData.mediaInputSource.supportedInputSources.value
	state.supportedInputs = supportedInputs
	setupData << [supportedInputs: supportedInputs]
	
	def pictureModes = mainData["custom.picturemode"].supportedPictureModes.value
	state.pictureModes = pictureModes
	setupData << [pictureModes: pictureModes]
	
	def soundModes =  mainData["custom.soundmode"].supportedSoundModes.value
	state.soundModes = soundModes
	setupData << [soundModes: soundModes]
	
	logInfo("deviceSetupParse: ${setupData}")
}
*/



def deviceRefresh() { refresh() }

def refresh() {
	if (connectST && stApiKey!= null) {
		def cmdData = [
			component: "main",
			capability: "refresh",
			command: "refresh",
			arguments: []]
		deviceCommand(cmdData)
	}
}

def poll() {
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "statusParse")
	}
}

def setLevel(level) { setVolume(level) }

def setVolume(volume) {
	def cmdData = [
		component: "main",
		capability: "audioVolume",
		command: "setVolume",
		arguments: [volume.toInteger()]]
	deviceCommand(cmdData)
}

def togglePictureMode() {
	//	requires state.pictureModes
	def pictureModes = state.pictureModes
	def totalModes = pictureModes.size()
	def currentMode = device.currentValue("pictureMode")
	def modeNo = pictureModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def newPictureMode = pictureModes[newModeNo]
	setPictureMode(newPictureMode)
}

def setPictureMode(pictureMode) {
	def cmdData = [
		component: "main",
		capability: "custom.picturemode",
		command: "setPictureMode",
		arguments: [pictureMode]]
	deviceCommand(cmdData)
}

def toggleSoundMode() {
	def soundModes = state.soundModes
	def totalModes = soundModes.size()
	def currentMode = device.currentValue("soundMode")
	def modeNo = soundModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def soundMode = soundModes[newModeNo]
	setSoundMode(soundMode)
}

def setSoundMode(soundMode) { 
	def cmdData = [
		component: "main",
		capability: "custom.soundmode",
		command: "setSoundMode",
		arguments: [soundMode]]
	deviceCommand(cmdData)
}

def toggleInputSource() {
	def inputSources = state.supportedInputs
	def totalSources = inputSources.size()
	def currentSource = device.currentValue("inputSource")
	def sourceNo = inputSources.indexOf(currentSource)
	def newSourceNo = sourceNo + 1
	if (newSourceNo == totalSources) { newSourceNo = 0 }
	def inputSource = inputSources[newSourceNo]
	setInputSource(inputSource)
}

def setInputSource(inputSource) {
	def cmdData = [
		component: "main",
		capability: "mediaInputSource",
		command: "setInputSource",
		arguments: [inputSource]]
	deviceCommand(cmdData)
}

def setTvChannel(newChannel) {
	def cmdData = [
		component: "main",
		capability: "tvChannel",
		command: "setTvChannel",
		arguments: [newChannel]]
	deviceCommand(cmdData)
}


/*
def deviceCommand(cmdData) {
	logTrace("deviceCommand: $cmdData")
	def respData = [:]
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData << [status: "FAILED", data: "no stDeviceId"]
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/commands",
			cmdData: cmdData
		]
		respData = syncPost(sendData)
	}
	if (respData.status == "OK") {
		if (respData.results[0].status == "COMPLETED") {
			if (cmdData.capability && cmdData.capability != "refresh") {
				refresh()
			} else {
				poll()
			}
		}
	}else {
		logWarn("deviceCommand: [status: ${respData.status}, data: ${respData}]")
		if (respData.toString().contains("Conflict")) {
			logWarn("<b>Conflict internal to SmartThings.  Device may be offline in SmartThings</b>")
		}
	}
}

def statusParse(mainData) {
	if (stTestData) {
		device.updateSetting("stTestData", [type:"bool", value: false])
		log.warn mainData
	}
	def stData = [:]
	if (logEnable || traceLog) {
		def quickLog = [:]
		try {
			quickLog << [
				switch: [device.currentValue("switch"), mainData.switch.switch.value],
				volume: [device.currentValue("volume"), mainData.audioVolume.volume.value.toInteger()],
				mute: [device.currentValue("mute"), mainData.audioMute.mute.value],
				input: [device.currentValue("inputSource"), mainData.mediaInputSource.inputSource.value],
				channel: [device.currentValue("tvChannel"), mainData.tvChannel.tvChannel.value.toString()],
				channelName: [device.currentValue("tvChannelName"), mainData.tvChannel.tvChannelName.value],
				pictureMode: [device.currentValue("pictureMode"), mainData["custom.picturemode"].pictureMode.value],
				soundMode: [device.currentValue("soundMode"), mainData["custom.soundmode"].soundMode.value],
				transportStatus: [device.currentValue("transportStatus"), mainData.mediaPlayback.playbackStatus.value]]
		} catch (err) {
			quickLog << [error: ${err}, data: mainData]
		}
		logDebug("statusParse: [quickLog: ${quickLog}]")
		logTrace("statusParse: [quickLog: ${quickLog}]")
	}

	if (device.currentValue("switch") == "on") {
		Integer volume = mainData.audioVolume.volume.value.toInteger()
		if (device.currentValue("volume") != volume) {
			sendEvent(name: "volume", value: volume)
			sendEvent(name: "level", value: volume)
			stData << [volume: volume]
		}

		String mute = mainData.audioMute.mute.value
		if (device.currentValue("mute") != mute) {
			sendEvent(name: "mute", value: mute)
			stData << [mute: mute]
		}

		String inputSource = mainData.mediaInputSource.inputSource.value
		if (device.currentValue("inputSource") != inputSource) {
			sendEvent(name: "inputSource", value: inputSource)		
			stData << [inputSource: inputSource]
		}

		String tvChannel = mainData.tvChannel.tvChannel.value.toString()
		if (tvChannel == "" || tvChannel == null) {
			tvChannel = " "
		}
		String tvChannelName = mainData.tvChannel.tvChannelName.value
		if (tvChannelName == "") {
			tvChannelName = " "
		}
		if (device.currentValue("tvChannelName") != tvChannelName) {
			sendEvent(name: "tvChannel", value: tvChannel)
			sendEvent(name: "tvChannelName", value: tvChannelName)
			if (tvChannelName.contains(".")) {
				getAppData(tvChannelName)
			} else {
				sendEvent(name: "currentApp", value: " ")
			}
			stData << [tvChannel: tvChannel, tvChannelName: tvChannelName]
			if (getDataValue("frameTv") == "true" && !state.artModeWs) {
				String artMode = "off"
				if (tvChannelName == "art") { artMode = "on" }
				sendEvent(name: "artModeStatus", value: artMode)
			}
		}

		String trackDesc = inputSource
		if (tvChannelName != " ") { trackDesc = tvChannelName }
		if (device.currentValue("trackDescription") != trackDesc) {
			sendEvent(name: "trackDescription", value:trackDesc)
			stData << [trackDescription: trackDesc]
		}

		String pictureMode = mainData["custom.picturemode"].pictureMode.value
		if (device.currentValue("pictureMode") != pictureMode) {
			sendEvent(name: "pictureMode",value: pictureMode)
			stData << [pictureMode: pictureMode]
		}

		String soundMode = mainData["custom.soundmode"].soundMode.value
		if (device.currentValue("soundMode") != soundMode) {
			sendEvent(name: "soundMode",value: soundMode)
			stData << [soundMode: soundMode]
		}

		String transportStatus = mainData.mediaPlayback.playbackStatus.value
		if (transportStatus == null || transportStatus == "") {
			transportStatus = "n/a"
		}
		if (device.currentValue("transportStatus") != transportStatus) {
			sendEvent(name: "transportStatus", value: transportStatus)
			stData << [transportStatus: transportStatus]
		}
	}
	
	if (stData != [:]) {
		logInfo("statusParse: ${stData}")
	}
}

private asyncGet(sendData, passData = "none") {
	if (!stApiKey || stApiKey.trim() == "") {
		logWarn("asyncGet: [status: ERROR, errorMsg: no stApiKey]")
	} else {
		logDebug("asyncGet: ${sendData}, ${passData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]]
		try {
			asynchttpGet(sendData.parse, sendCmdParams, [reason: passData])
		} catch (error) {
			logWarn("asyncGet: [status: FAILED, errorMsg: ${error}]")
		}
	}
}

private syncGet(path){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncGet: ${sendData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]
		]
		try {
			httpGet(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 errorMsg: error]
		}
	}
	return respData
}

private syncPost(sendData){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncPost: ${sendData}")
		def cmdBody = [commands: [sendData.cmdData]]
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()],
			body : new groovy.json.JsonBuilder(cmdBody).toString()
		]
		try {
			httpPost(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data.results]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 errorMsg: error]
		}
	}
	return respData
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
				runIn(1, statusParse, [data: respData.components.main])
			} else {
				statusParse(respData.components.main)
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}
*/