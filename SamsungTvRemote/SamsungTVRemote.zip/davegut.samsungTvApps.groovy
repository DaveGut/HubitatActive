library (
	name: "samsungTvApps",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung TV Applications",
	category: "utilities",
	documentationLink: ""
)

command "appOpenByName", ["string"]
command "appOpenByCode", ["string"]
command "appClose"
attribute "currentApp", "string"
command "appRunBrowser"
command "appRunYouTube"
command "appRunNetflix"
command "appRunPrimeVideo"
command "appRunYouTubeTV"
command "appRunHulu"

def tvAppsPreferences() {
	input ("findAppCodes", "bool", title: "Scan for App Codes (takes 10 minutes)", defaultValue: false)
}

import groovy.json.JsonSlurper

def appOpenByName(appName) {
	def thisApp = findThisApp(appName)
	def logData = [appName: thisApp[0], appId: thisApp[1]]
	if (thisApp[1] != "none") {
		[status: "execute appOpenByCode"]
		appOpenByCode(thisApp[1])
	} else {
		def url = "http://${deviceIp}:8080/ws/apps/${appName}"
		try {
			httpPost(url, "") { resp ->
				sendEvent(name: "currentApp", value: respData.name)
				logData << [status: "OK", currentApp: respData.name]
			}
			runIn(5, refresh)
		} catch (err) {
			logData << [status: "appName Not Found", data: err]
			logWarn("appOpenByName: ${logData}")
		}
	}
	logDebug("appOpenByName: ${logData}")
}

def appOpenByCode(appId) {
	def appName = state.appData.find { it.value == appId }
	if (appName != null) {
		appName = appName.key
	}
	def logData = [appId: appId, appName: appName]
	def uri = "http://${deviceIp}:8001/api/v2/applications/${appId}"
	try {
		httpPost(uri, body) { resp ->
			if (appName == null) {
				runIn(3, getAppData, [data: appId])
			} else {
				sendEvent(name: "currentApp", value: appName)
				logData << [currentApp: appName]
			}
			runIn(5, refresh)
			logData << [status: "OK", data: resp.data]
		}
	} catch (err) {
		logData << [status: "appId Not Found", data: err]
		logWarn("appOpenByCode: ${logData}")
	}
	logDebug("appOpenByCode: ${logData}")
}

def appClose() {
	def appId
	def appName = device.currentValue("currentApp")
	if (appName == " " || appName == null) {
		logWarn("appClose: [status: FAILED, reason: appName not set.]")
		return
	}
	def thisApp = findThisApp(appName)
	appId = thisApp[1]
	def logData = [appName: appName, appId: appId]
	Map params = [uri: "http://${deviceIp}:8001/api/v2/applications/${appId}",
				  timeout: 3]
	try {
		asynchttpDelete("appCloseParse", params, [appId: appId])
		logData: [status: "OK"]
		exit()
	} catch (err) {
		logData: [status: "FAILED", data: err]
		logWarn("appClose: ${logData}")
	}
	logDebug("appClose: ${logData}")
}

def appCloseParse(resp, data) {
	def logData = [appId: data.appId]
	if (resp.status == 200) {
		sendEvent(name: "currentApp", value: " ")
		logData << [status: "OK"]
	} else {
		logData << [status: "FAILED", status: resp.status]
		logWarn("appCloseParse: ${logData}")
	}
	logDebug("appCloseParse: ${logData}")
}

def findThisApp(appName) {
	def thisApp = state.appData.find { it.key.toLowerCase().contains(appName.toLowerCase()) }
	def appId = "none"
	if (thisApp != null) {
		appName = thisApp.key
		appId = thisApp.value
	} else {
		//	Handle special case for browser (using switch to add other cases.
		switch(appName.toLowerCase()) {
			case "browser":
				appId = "org.tizen.browser"
				appName = "Browser"
				break
			case "youtubetv":
				appId = "PvWgqxV3Xa.YouTubeTV"
				appName = "YouTube TV"
				break
			case "netflix":
				appId = "3201907018807"
				appName = "Netflix"
				break
			case "youtube":
				appId = "9Ur5IzDKqV.TizenYouTube"
				appName = "YouTube"
				break
			case "amazoninstantvideo":
				appId = "3201910019365"
				appName = "Prime Video"
				break
			default:
				logWarn("findThisApp: ${appName} not found in appData")
		}
	}
	return [appName, appId]
}

def getAppData(appId) {
	def logData = [appId: appId]
	def thisApp = state.appData.find { it.value == appId }
	if (thisApp && !state.appIdIndex) {
		sendEvent(name: "currentApp", value: thisApp.key)
		logData << [currentApp: thisApp.key]
	} else {
		Map params = [uri: "http://${deviceIp}:8001/api/v2/applications/${appId}",
					  timeout: 3]
		try {
			asynchttpGet("getAppDataParse", params, [appId: appId])
		} catch (err) {
			logData: [status: "FAILED", data: err]
		}
	}
	logDebug("getAppData: ${logData}")
}

def getAppDataParse(resp, data) {
	def logData = [appId: data.appId]
	if (resp.status == 200) {
		def respData = new JsonSlurper().parseText(resp.data)
		logData << [resp: respData]
		state.appData << ["${respData.name}": respData.id]
		if(!state.appIdIndex && device.currentValue("currentApp") != currApp) {
			sendEvent(name: "currentApp", value: respData.name)
			logData << [currentApp: respData.name]
		}
	} else if (resp.status == 404) {
		logData << [status: "appNotPresent", code: resp.status]
	} else {
		logData << [status: "FAILED", reason: "${resp.status} response from TV"]
	}
	if (logData.status == "FAO:ED") {
		logWarn("getAppDataParse: ${logData}")
	} else {
		logInfo("getAppDataParse: ${logData}")
	}
}

def updateAppCodes() {
	state.appData = [:]
	if (device.currentValue("switch") == "on") {
		logInfo("updateAppCodes: [currentDbSize: ${state.appData.size()}, availableCodes: ${appIdList().size()}]")
		unschedule("onPoll")
		runIn(900, setOnPollInterval)
		state.appIdIndex = 0
		findNextApp()
	} else {
		logWarn("getAppList: [status: FAILED, reason: tvOff]")
	}
	device.updateSetting("findAppCodes", [type:"bool", value: false])
}

def findNextApp() {
	def appIds = appIdList()
	def logData = [:]
	if (state.appIdIndex < appIds.size()) {
		def nextApp = appIds[state.appIdIndex]
		state.appIdIndex += 1
		getAppData(nextApp)
		runIn(6, findNextApp)
	} else {
		runIn(20, setOnPollInterval)
		logData << [status: "Complete", appIdsScanned: state.appIdIndex]
		logData << [totalApps: state.appData.size(), appData: state.appData]
		state.remove("appIdIndex")
		logInfo("findNextApp: ${logData}")
	}
}

def appIdList() {
	def appList = [
		"kk8MbItQ0H.VUDU", "vYmY3ACVaa.emby", "ZmmGjO6VKO.slingtv", "MCmYXNxgcu.DisneyPlus",
		"PvWgqxV3Xa.YouTubeTV", "LBUAQX1exg.Hulu", "AQKO41xyKP.AmazonAlexa", "3KA0pm7a7V.TubiTV",
		"cj37Ni3qXM.HBONow", "gzcc4LRFBF.Peacock", "9Ur5IzDKqV.TizenYouTube", "BjyffU0l9h.Stream",
		"3202203026841", "3202103023232", "3202103023185", "3202012022468", "3202012022421",
		"3202011022316", "3202011022131", "3202010022098", "3202009021877", "3202008021577",
		"3202008021462", "3202008021439", "3202007021336", "3202004020674", "3202004020626",
		"3202003020365", "3201910019457", "3201910019449", "3201910019420", "3201910019378",
		"3201910019365", "3201910019354", "3201909019271", "3201909019175", "3201908019041",
		"3201908019022", "3201907018807", "3201907018786", "3201907018784", "3201906018693",
		"3201901017768", "3201901017640", "3201812017479", "3201810017091", "3201810017074",
		"3201807016597", "3201806016432", "3201806016390", "3201806016381", "3201805016367",
		"3201803015944", "3201803015934", "3201803015869", "3201711015226", "3201710015067",
		"3201710015037", "3201710015016", "3201710014874", "3201710014866", "3201707014489",
		"3201706014250", "3201706012478", "3201704012212", "3201704012147", "3201703012079",
		"3201703012065", "3201703012029", "3201702011851", "3201612011418", "3201611011210",
		"3201611011005", "3201611010983", "3201608010385", "3201608010191", "3201607010031",
		"3201606009910", "3201606009798", "3201606009684", "3201604009182", "3201603008746",
		"3201603008210", "3201602007865", "3201601007670", "3201601007625", "3201601007230",
		"3201512006963", "3201512006785", "3201511006428", "3201510005981", "3201506003488",
		"3201506003486", "3201506003175", "3201504001965", "121299000612", "121299000101",
		"121299000089", "111399002220", "111399002034", "111399000741", "111299002148",
		"111299001912", "111299000769", "111012010001", "11101200001", "11101000407",
		"11091000000"
	]
	return appList
}

def appRunBrowser() { appOpenByName("Browser") }

def appRunYouTube() { appOpenByName("YouTube") }

def appRunNetflix() { appOpenByName("Netflix") }

def appRunPrimeVideo() { appOpenByName("Prime Video") }

def appRunYouTubeTV() { appOpenByName("YouTubeTV") }

def appRunHulu() { appOpenByName("Hulu") }
