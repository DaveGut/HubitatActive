library (
	name: "ST-Common",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "ST Wash/Dryer Common Methods",
	category: "utilities",
	documentationLink: ""
)

def commonUpdate() {
	if (!stApiKey || stApiKey == "") {
		return [status: "FAILED", reason: "No stApiKey"]
	}
	if (!stDeviceId || stDeviceId == "") {
		getDeviceList()
		return [status: "FAILED", reason: "No stDeviceId"]
	}

	unschedule()
	def updateData = [:]
	updateData << [status: "OK"]
	if (debugLog) { runIn(1800, debugLogOff) }
	updateData << [stDeviceId: stDeviceId]
	updateData << [debugLog: debugLog, infoLog: infoLog]
	if (!getDataValue("driverVersion") || 
		getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		updateData << [driverVer: driverVer()]
	}
	setPollInterval(pollInterval)
	updateData << [pollInterval: pollInterval]

	runIn(5, refresh)
	return updateData
}

def setPollInterval(pollInterval) {
	logDebug("setPollInterval: ${pollInterval}")
	state.pollInterval = pollInterval
	switch(pollInterval) {
		case "1" : runEvery1Minute(poll); break
		case "5" : runEvery5Minutes(poll); break
		case "10" : runEvery10Minutes(poll); break
		case "30" : runEvery30Minutes(poll); break
		default: runEvery10Minutes(poll)
	}
}

def deviceCommand(cmdData) {
	def respData = [:]
	if (simulate() == true) {
		respData = testResp(cmdData)
	} else if (!stDeviceId || stDeviceId.trim() == "") {
		respData << [status: "FAILED", data: "no stDeviceId"]
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/commands",
			cmdData: cmdData
		]
		respData = syncPost(sendData)
	}
	if (cmdData.capability && cmdData.capability != "refresh") {
		runIn(2, refresh)
	} else {
		poll()
	}
	return respData
}

def refresh() {
	if (stApiKey!= null) {
		def cmdData = [
			component: "main",
			capability: "refresh",
			command: "refresh",
			arguments: []]
		deviceCommand(cmdData)
	}
}

def poll() {
	if (simulate() == true) {
		def children = getChildDevices()
		if (children) {
			children.each {
				it.statusParse(testData())
			}
		}
		statusParse(testData())
	} else if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "statusParse")
	}
}

def deviceSetup() {
	if (simulate() == true) {
		def children = getChildDevices()
		deviceSetupParse(testData())
	} else if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "deviceSetup")
	}
}

def getDeviceList() {
	def sendData = [
		path: "/devices",
		parse: "getDeviceListParse"
		]
	asyncGet(sendData)
}

def getDeviceListParse(resp, data) {
	def respData
	if (resp.status != 200) {
		respData = [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	} else {
		try {
			respData = new JsonSlurper().parseText(resp.data)
		} catch (err) {
			respData = [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	}
	if (respData.status == "ERROR") {
		logWarn("getDeviceListParse: ${respData}")
	} else {
		log.info ""
		respData.items.each {
			log.trace "${it.label}:   ${it.deviceId}"
		}
		log.trace "<b>Copy your device's deviceId value and enter into the device Preferences.</b>"
	}
}

def calcTimeRemaining(completionTime) {
	Integer currTime = now()
	Integer compTime
	try {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	} catch (e) {
		compTime = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", completionTime,TimeZone.getTimeZone('UTC')).getTime()
	}
	Integer timeRemaining = ((compTime-currTime) /1000).toInteger()
	if (timeRemaining < 0) { timeRemaining = 0 }
	return timeRemaining
}
