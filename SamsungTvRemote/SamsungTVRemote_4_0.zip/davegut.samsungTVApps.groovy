library (
	name: "samsungTV-Apps",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung TV Smart App Interface",
	category: "utilities",
	documentationLink: ""
)

def appRunBrowser() { appOpenByName("Browser") }
def appRunYouTube() { appOpenByName("YouTube") }
def appRunNetflix() { appOpenByName("Netflix") }
def appRunPrimeVideo() { appOpenByName("Prime Video") }
def appRunYouTubeTV() { appOpenByName("YouTubeTV") }
def appRunHulu() { appOpenByName("Hulu") }
