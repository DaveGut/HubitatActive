library (
	name: "samsungTV-Keys",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung TV Keys",
	category: "utilities",
	documentationLink: ""
)

//	===== Web Socket Remote Commands =====
def mute() {
	sendKey("MUTE")
	runIn(5, stRefresh)
}
def unmute() {
	sendKey("MUTE")
	runIn(5, stRefresh)
}
def volumeUp() { 
	sendKey("VOLUP") 
	runIn(5, stRefresh)
}
def volumeDown() { 
	sendKey("VOLDOWN")
	runIn(5, stRefresh)
}

def play() { sendKey("PLAY") }
def pause() { sendKey("PAUSE") }
def stop() { sendKey("STOP") }

def exit() {
	sendKey("EXIT")
	runIn(5, stRefresh)
}
def Return() { sendKey("RETURN") }

def fastBack() {
	sendKey("LEFT", "Press")
	pauseExecution(1000)
	sendKey("LEFT", "Release")
}
def fastForward() {
	sendKey("RIGHT", "Press")
	pauseExecution(1000)
	sendKey("RIGHT", "Release")
}

def arrowLeft() { sendKey("LEFT") }
def arrowRight() { sendKey("RIGHT") }
def arrowUp() { sendKey("UP") }
def arrowDown() { sendKey("DOWN") }
def enter() { sendKey("ENTER") }

def numericKeyPad() { sendKey("MORE") }

def home() { sendKey("HOME") }
def menu() { sendKey("MENU") }
def guide() { sendKey("GUIDE") }
def info() { sendKey("INFO") }

def source() { 
	sendKey("SOURCE")
	runIn(5, stRefresh)
}
def hdmi() {
	sendKey("HDMI")
	runIn(5, stRefresh)
}

def channelList() { sendKey("CH_LIST") }
def channelUp() { 
	sendKey("CHUP") 
	runIn(5, stRefresh)
}
def nextTrack() { channelUp() }
def channelDown() { 
	sendKey("CHDOWN") 
	runIn(5, stRefresh)
}
def previousTrack() { channelDown() }
def previousChannel() { 
	sendKey("PRECH") 
	runIn(5, stRefresh)
}

def showMessage() { logWarn("showMessage: not implemented") }

//	===== Button Interface (facilitates dashboard integration) =====
def push(pushed) {
	logDebug("push: button = ${pushed}, trigger = ${state.triggered}")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	pushed = pushed.toInteger()
	switch(pushed) {
		//	===== Physical Remote Commands =====
		case 2 : mute(); break
		case 3 : numericKeyPad(); break
		case 4 : Return(); break
		case 6 : artMode(); break			//	New command.  Toggles art mode
		case 7 : ambientMode(); break
		case 45: ambientmodeExit(); break
		case 8 : arrowLeft(); break
		case 9 : arrowRight(); break
		case 10: arrowUp(); break
		case 11: arrowDown(); break
		case 12: enter(); break
		case 13: exit(); break
		case 14: home(); break
		case 18: channelUp(); break
		case 19: channelDown(); break
		case 20: guide(); break
		case 21: volumeUp(); break
		case 22: volumeDown(); break
		//	===== Direct Access Functions
		case 23: menu(); break			//	Main menu with access to system settings.
		case 24: source(); break		//	Pops up home with cursor at source.  Use left/right/enter to select.
		case 25: info(); break			//	Pops up upper display of currently playing channel
		case 26: channelList(); break	//	Pops up short channel-list.
		//	===== Other Commands =====
		case 34: previousChannel(); break
		case 35: hdmi(); break			//	Brings up next available source
		case 36: fastBack(); break		//	causes fast forward
		case 37: fastForward(); break	//	causes fast rewind
		case 38: appRunBrowser(); break		//	Direct to source 1 (ofour right of TV on menu)
		case 39: appRunYouTube(); break
		case 40: appRunNetflix(); break
		case 42: toggleSoundMode(); break
		case 43: togglePictureMode(); break
		case 44: setPictureMode("Dynamic"); break
		default:
			logDebug("push: Invalid Button Number!")
			break
	}
}

