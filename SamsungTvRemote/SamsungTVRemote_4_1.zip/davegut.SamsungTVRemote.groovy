/*	===== HUBITAT INTEGRATION VERSION =====================================================
Hubitat - Samsung TV Remote Driver
		Copyright 2022 Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== 2022 Version 4.1 ====================================================================
Version 4.1
a.	Moved websocket and tv application methods into shared libaries for maintainability.
b.	Fix websocket status to add close function.  Allows user to update status if the
	function fails.

Known issues:
a.	2022 Frame TVs without connectST enabled: when placed in art mode and motion 
	detection/light detection enabled on the TV, the TV may drop out of artMode status.
b.	Volume reporting zero.  Checks of several issues shows that this value is coming 
	from SmartThings.

===========================================================================================*/
def driverVer() { return "4.1-1" }
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

metadata {
	definition (name: "Samsung TV Remote",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungTvRemote/SamsungTVRemote.groovy"
			   ){
		capability "Refresh"
		capability "Configuration"
		capability "SamsungTV"
		command "showMessage", [[name: "Not Implemented"]]
		capability "Switch"
		command "close"
		attribute "wsStatus", "string"
		
		//	Currently under test/validation (in main code)
		command "artMode"
		attribute "artModeStatus", "string"
		command "ambientMode"
		command "appOpenByName", ["string"]
		command "appOpenByCode", ["string"]
		command "appClose"
		//	Remote Control Keys (samsungTV-Keys)
		command "pause"
		command "play"
		command "stop"
		command "sendKey", ["string"]
		//	Cursor and Entry Control
		command "arrowLeft"
		command "arrowRight"
		command "arrowUp"
		command "arrowDown"
		command "enter"
		command "numericKeyPad"
		//	Menu Access
		command "home"
		command "menu"
		command "guide"
		command "info"
		//	Source Commands
		command "source"
		command "hdmi"
		//	TV Channel
		command "channelList"
		command "channelUp"
		command "channelDown"
		command "previousChannel"
		//	Playing Navigation Commands
		command "exit"
		command "Return"
		command "fastBack"
		command "fastForward"
		command "nextTrack", [[name: "Sets Channel Up"]]
		command "previousTrack", [[name: "Sets Channel Down"]]
		
		//	SmartThings Functions (library samsungTV=ST)
		command "toggleInputSource", [[name: "SmartThings Function"]]
		command "toggleSoundMode", [[name: "SmartThings Function"]]
		command "togglePictureMode", [[name: "SmartThings Function"]]
		command "setTvChannel", ["SmartThings Function"]
		attribute "tvChannel", "string"
		attribute "tvChannelName", "string"
		command "setInputSource", ["SmartThings Function"]
		attribute "inputSource", "string"
		command "setVolume", ["SmartThings Function"]
		command "setPictureMode", ["SmartThings Function"]
		command "setSoundMode", ["SmartThings Function"]
		command "setLevel", ["SmartThings Function"]
		
		//	Smart App Control (library samsungTV-apps)
		attribute "currentApp", "string"
		command "appRunBrowser"
		command "appRunYouTube"
		command "appRunNetflix"
		command "appRunPrimeVideo"
		command "appRunYouTubeTV"
		command "appRunHulu"
		attribute "transportStatus", "string"
		attribute "level", "NUMBER"
		attribute "trackDescription", "string"

		capability "PushableButton"
		capability "Variable"
	}
	preferences {
		input ("deviceIp", "text", title: "Samsung TV Ip", defaultValue: "")
		if (deviceIp) {
			input ("tvPwrOnMode", "enum", title: "TV Startup Display", 
				   options: ["ART_MODE", "Ambient", "none"], defaultValue: "none")
			input ("logEnable", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
			input ("infoLog", "bool", 
				   title: "Enable information logging " + helpLogo(),
				   defaultValue: true)
			input ("traceLog", "bool", title: "Enable trace logging as directed by developer", defaultValue: false)
			input ("connectST", "bool", title: "Connect to SmartThings for added functions", defaultValue: false)
		}
		def onPollOptions = ["local": "Local", "off": "DISABLE"]
		if (connectST) {
			onPollOptions = ["st": "SmartThings", "local": "Local", "off": "DISABLE"]
			input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
			if (stApiKey) {
				input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
			}
			input ("stPollInterval", "enum", title: "SmartThings Poll Interval (minutes)",
				   options: ["off", "1", "5", "15", "30"], defaultValue: "15")
			input ("stTestData", "bool", title: "Get ST data dump for developer", defaultValue: false)
		}
		input ("pollMethod", "enum", title: "Power Polling Method", defaultValue: "local",
			   options: onPollOptions)
//			   options: ["st": "SmartThings", "local": "Local", "off": "DISABLE"])
		input ("pollInterval","enum", title: "Power Polling Interval (seconds)",
			   options: ["off", "10", "15", "20", "30", "60"], defaultValue: "60")
		input ("findAppCodes", "bool", title: "Scan for App Codes (use rarely)", defaultValue: false)
		input ("resetAppCodes", "bool", title: "Delete and Rescan for App Codes (use rarely)", defaultValue: false)
	}
}

String helpLogo() { // library marker davegut.kasaCommon, line 11
	return """<a href="https://github.com/DaveGut/HubitatActive/blob/master/SamsungTvRemote/README.md">""" +
		"""<div style="position: absolute; top: 10px; right: 10px; height: 80px; font-size: 20px;">Samsung TV Remote Help</div></a>"""
}

//	===== Installation, setup and update =====
def installed() {
	state.token = "12345678"
	def tokenSupport = "false"
	sendEvent(name: "wsStatus", value: "closed")
	sendEvent(name: "wsStatus", value: "45")
	runIn(1, updated)
}

def updated() {
	unschedule()
	close()
	def updStatus = [:]
	if (!deviceIp) {
		logWarn("\n\n\t\t<b>Enter the deviceIp and Save Preferences</b>\n\n")
		updStatus << [status: "ERROR", data: "Device IP not set."]
	} else {
//		updStatus << [getDeviceData: configure()]
		if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
			updateDataValue("driverVersion", driverVer())
			updStatus << [driverVer: driverVer()]
		}
		if (logEnable) { runIn(1800, debugLogOff) }
		if (traceLog) { runIn(600, traceLogOff) }
		updStatus << [logEnable: logEnable, infoLog: infoLog, traceLog: traceLog]
		updStatus << [setOnPollInterval: setOnPollInterval()]
		if (!pollMethod) {
			pollMethod = "local"
			device.updateSetting("pollMethod", [type:"enum", value: "local"])
		}
		updStatus << [pollMethod: newPollMethod]
/*		def newPollMethod = pollMethod
		if (newPollMethod == null) {
			
		if (!pollMethod && connectST) {
			newPollMethod = "st"
		} else if (pollMethod == "st" && !connectST) {
			newPollMethod = "local"
		} else {
			newPollMethod = pollMethod
		}
		device.updateSetting("pollMethod", [type:"enum", value: newPollMethod])
		updStatus << [pollMethod: newPollMethod]*/
		if (resetAppCodes) {
			state.appData = [:]
			runIn(1, updateAppCodes)
		} else if (findAppCodes) {
			runIn(1, updateAppCodes)
		}
		runIn(1, configure)
	}
	sendEvent(name: "numberOfButtons", value: 45)
	sendEvent(name: "wsStatus", value: "closed")
	state.standbyTest = false
	logInfo("updated: ${updStatus}")

//	runIn(1, configure)
	listAttributes(true)
	logTrace("updated: onPollCount = $state.onPollCount")
	state.onPollCount = 0
}

def setOnPollInterval() {
	if (pollMethod == "off") {
		pollInterval = "DISABLED"
		device.updateSetting("pollInterval", [type:"enum", value: "off"])
	} else {
		if (pollInterval == null) {
			pollInterval = "60"
			device.updateSetting("pollInterval", [type:"enum", value: "60"])
		}
		if (pollInterval == "60") {
			runEvery1Minute(onPoll)
		} else if (pollInterval != "off") {
			schedule("0/${pollInterval} * * * * ?",  onPoll)
		}
	}
	return pollInterval
}




def configure() {
	def respData = [:]
	def tvData = [:]
	try{
		httpGet([uri: "http://${deviceIp}:8001/api/v2/", timeout: 5]) { resp ->
			tvData = resp.data
			runIn(1, getArtModeStatus)
		}
	} catch (error) {
		tvData << [status: "error", data: error]
		logError("configure: TV Off during setup or Invalid IP address.\n\t\tTurn TV On and Run CONFIGURE or Save Preferences!")

	}
	if (!tvData.status) {
		def wifiMac = tvData.device.wifiMac
		updateDataValue("deviceMac", wifiMac)
		def alternateWolMac = wifiMac.replaceAll(":", "").toUpperCase()
		updateDataValue("alternateWolMac", alternateWolMac)
		device.setDeviceNetworkId(alternateWolMac)
		def modelYear = "20" + tvData.device.model[0..1]
		updateDataValue("modelYear", modelYear)
		def frameTv = "false"
		if (tvData.device.FrameTVSupport) {
			frameTv = tvData.device.FrameTVSupport
		}
		updateDataValue("frameTv", frameTv)
		if (tvData.device.TokenAuthSupport) {
			tokenSupport = tvData.device.TokenAuthSupport
			updateDataValue("tokenSupport", tokenSupport)
		}
		def uuid = tvData.device.duid.substring(5)
		updateDataValue("uuid", uuid)
		respData << [status: "OK", dni: alternateWolMac, modelYear: modelYear,
					 frameTv: frameTv, tokenSupport: tokenSupport]
		sendEvent(name: "artModeStatus", value: "none")
		def data = [request:"get_artmode_status",
					id: "${getDataValue("uuid")}"]
		data = JsonOutput.toJson(data)
		artModeCmd(data)
		state.configured = true
	} else {
		respData << tvData
	}
	runIn(1, stUpdate)
	logInfo("configure: ${respData}")
	return respData
}

def stUpdate() {
	def stData = [:]
	if (connectST) {
		stData << [connectST: "true"]
		stData << [connectST: connectST]
		if (!stApiKey || stApiKey == "") {
			logWarn("\n\n\t\t<b>Enter the ST API Key and Save Preferences</b>\n\n")
			stData << [status: "ERROR", date: "no stApiKey"]
		} else if (!stDeviceId || stDeviceId == "") {
			getDeviceList()
			logWarn("\n\n\t\t<b>Enter the deviceId from the Log List and Save Preferences</b>\n\n")
			stData << [status: "ERROR", date: "no stDeviceId"]
		} else {
			if (device.currentValue("volume") == null) {
//				sendEvent(name: "volume", value: 0)
//				sendEvent(name: "level", value: 0)
			}
			def stPollInterval = stPollInterval
			if (stPollInterval == null) { 
				stPollInterval = "15"
				device.updateSetting("stPollInterval", [type:"enum", value: "15"])
			}
			switch(stPollInterval) {
				case "1" : runEvery1Minute(refresh); break
				case "5" : runEvery5Minutes(refresh); break
				case "15" : runEvery15Minutes(refresh); break
				case "30" : runEvery30Minutes(refresh); break
				default: unschedule("refresh")
			}
			deviceSetup()
			stData << [stPollInterval: stPollInterval]
		}
	} else {
		stData << [connectST: "false"]
	}
	logInfo("stUpdate: ${stData}")
}




//	===== Polling/Refresh Capability =====
def onPoll() {
	if (traceLog) { state.onPollCount += 1 }
	if (pollMethod == "st") {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "stPollParse"
			]
		asyncGet(sendData, "stPollParse")
	} else if (pollMethod == "local") {
		def sendCmdParams = [
			uri: "http://${deviceIp}:8001/api/v2/",
			timeout: 6
		]
		asynchttpGet("onPollParse", sendCmdParams)
	} else {
		logWarn("onPoll: Polling is disabled")
	}
	if (getDataValue("driverVersion") != driverVer()) {
		logInfo("Auto Configuring changes to this TV.")
		updated()
		pauseExecution(3000)
	}
}




def stPollParse(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			def onOff = respData.components.main.switch.switch.value
			if (device.currentValue("switch") != onOff) {
				logInfo("stPollParse: [switch: ${onOff}]")
				sendEvent(name: "switch", value: onOff)
				if (onOff == "on") {
					runIn(3, setPowerOnMode)
				} else {
					close()
				}
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("stPollParse: ${respLog}")
	}
}




def onPollParse(resp, data) {
	def powerState
	if (resp.status == 200) {
		def tempPower = new JsonSlurper().parseText(resp.data).device.PowerState
		if (tempPower == null) {
			powerState = "on"
		} else { 
			powerState = tempPower
		}
	} else {
		logTrace("onPollParse: [state: error, status: $resp.status]")
		powerState = "NC"
	}
	def onOff = "on"
	if (powerState == "on") {
		state.standbyTest = false
		onOff = "on"
	} else {
		if (device.currentValue("switch") == "on") {
			//	If currently on, will need two non-"on" values to set switch off
			if (!state.standbyTest) {
				state.standbyTest = true
				runIn(5, onPoll)
			} else {
				state.standbyTest = false
				onOff = "off"
			}
		} else {
			//	If powerState goes to standby, this indicates tv screen is off
			//	as the tv powers down (takes 0.5 to 2 minutes to disconnect).
			onOff = "off"
		}
		logTrace("onPollParse: [switch: ${device.currentValue("switch")}, onOff: ${onOff}, powerState: $powerState, stbyTest: $state.standbyTest]")
	}
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff)
		if (onOff == "on") {
			runIn(5, setPowerOnMode)
			refresh()
		} else {
			close()
			refresh()
		}
		logInfo("onPollParse: [switch: ${onOff}, powerState: ${powerState}]")
	}
}




//	===== Capability Switch =====




def on() {
	logInfo("on: [frameTv: ${getDataValue("frameTv")}]")
//	unschedule("onPoll")
//	runIn(60, setOnPollInterval)
	def wolMac = getDataValue("alternateWolMac")
	def cmd = "FFFFFFFFFFFF$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac"
	wol = new hubitat.device.HubAction(
		cmd,
		hubitat.device.Protocol.LAN,
		[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
		 destinationAddress: "255.255.255.255:7",
		 encoding: hubitat.device.HubAction.Encoding.HEX_STRING])
	sendHubCommand(wol)
//	added
	runIn(5, onPoll)
//	sendEvent(name: "switch", value: "on")
//	runIn(2, getArtModeStatus)
//	runIn(5, setPowerOnMode)
}




def setPowerOnMode() {
	logInfo("setPowerOnMode: [tvPwrOnMode: ${tvPwrOnMode}]")
	if(tvPwrOnMode == "ART_MODE") {
		getArtModeStatus()
		pauseExecution(1000)
		artMode()
	} else if (tvPwrOnMode == "Ambient") {
		ambientMode()
	}
	refresh()
}




def off() {
	logInfo("off: [frameTv: ${getDataValue("frameTv")}]")
//	unschedule("onPoll")
//	runIn(60, setOnPollInterval)
	if (getDataValue("frameTv") == "true") {
		sendKey("POWER", "Press")
		pauseExecution(4000)
		sendKey("POWER", "Release")
	} else {
		sendKey("POWER")
	}
//	added
	runIn(5, onPoll)
//	sendEvent(name: "switch", value: "off")
}




//	===== SMART THINGS INTERFACE =====
//	ST Device Setup
def deviceSetup() {
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "deviceSetup")
	}
}

def getDeviceList() {
	def sendData = [
		path: "/devices",
		parse: "getDeviceListParse"
		]
	asyncGet(sendData)
}

def getDeviceListParse(resp, data) {
	def respData
	if (resp.status != 200) {
		respData = [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	} else {
		try {
			respData = new JsonSlurper().parseText(resp.data)
		} catch (err) {
			respData = [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	}
	if (respData.status == "ERROR") {
		logWarn("getDeviceListParse: ${respData}")
	} else {
		log.info ""
		respData.items.each {
			log.trace "${it.label}:   ${it.deviceId}"
		}
		log.trace "<b>Copy your device's deviceId value and enter into the device Preferences.</b>"
	}
}

def deviceSetupParse(mainData) {
	def setupData = [:]
	def supportedInputs =  mainData.mediaInputSource.supportedInputSources.value
	state.supportedInputs = supportedInputs
	setupData << [supportedInputs: supportedInputs]
	
	def pictureModes = mainData["custom.picturemode"].supportedPictureModes.value
	state.pictureModes = pictureModes
	setupData << [pictureModes: pictureModes]
	
	def soundModes =  mainData["custom.soundmode"].supportedSoundModes.value
	state.soundModes = soundModes
	setupData << [soundModes: soundModes]
	
	logInfo("deviceSetupParse: ${setupData}")
}

//	== ST Commands
def deviceRefresh() { refresh() }

def refresh() {
	if (connectST && stApiKey!= null) {
		def cmdData = [
			component: "main",
			capability: "refresh",
			command: "refresh",
			arguments: []]
		deviceCommand(cmdData)
	}
}

def poll() {
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData = "[status: FAILED, data: no stDeviceId]"
		logWarn("poll: [status: ERROR, errorMsg: no stDeviceId]")
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "distResp"
			]
		asyncGet(sendData, "statusParse")
	}
}

def setLevel(level) { setVolume(level) }

def setVolume(volume) {
	def cmdData = [
		component: "main",
		capability: "audioVolume",
		command: "setVolume",
		arguments: [volume.toInteger()]]
	deviceCommand(cmdData)
}

def togglePictureMode() {
	//	requires state.pictureModes
	def pictureModes = state.pictureModes
	def totalModes = pictureModes.size()
	def currentMode = device.currentValue("pictureMode")
	def modeNo = pictureModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def newPictureMode = pictureModes[newModeNo]
	setPictureMode(newPictureMode)
}

def setPictureMode(pictureMode) {
	def cmdData = [
		component: "main",
		capability: "custom.picturemode",
		command: "setPictureMode",
		arguments: [pictureMode]]
	deviceCommand(cmdData)
}

def toggleSoundMode() {
	def soundModes = state.soundModes
	def totalModes = soundModes.size()
	def currentMode = device.currentValue("soundMode")
	def modeNo = soundModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def soundMode = soundModes[newModeNo]
	setSoundMode(soundMode)
}

def setSoundMode(soundMode) { 
	def cmdData = [
		component: "main",
		capability: "custom.soundmode",
		command: "setSoundMode",
		arguments: [soundMode]]
	deviceCommand(cmdData)
}

def toggleInputSource() {
	def inputSources = state.supportedInputs
	def totalSources = inputSources.size()
	def currentSource = device.currentValue("mediaInputSource")
	def sourceNo = inputSources.indexOf(currentSource)
	def newSourceNo = sourceNo + 1
	if (newSourceNo == totalSources) { newSourceNo = 0 }
	def inputSource = inputSources[newSourceNo]
	setInputSource(inputSource)
}

def setInputSource(inputSource) {
	def cmdData = [
		component: "main",
		capability: "mediaInputSource",
		command: "setInputSource",
		arguments: [inputSource]]
	deviceCommand(cmdData)
}

def setTvChannel(newChannel) {
	def cmdData = [
		component: "main",
		capability: "tvChannel",
		command: "setTvChannel",
		arguments: [newChannel]]
	deviceCommand(cmdData)
}

def deviceCommand(cmdData) {
	logTrace("deviceCommand: $cmdData")
	def respData = [:]
	if (!stDeviceId || stDeviceId.trim() == "") {
		respData << [status: "FAILED", data: "no stDeviceId"]
	} else {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/commands",
			cmdData: cmdData
		]
		respData = syncPost(sendData)
	}
	if (respData.status == "OK") {
		if (respData.results[0].status == "COMPLETED") {
			if (cmdData.capability && cmdData.capability != "refresh") {
				refresh()
			} else {
				poll()
			}
		}
	}else {
		logWarn("deviceCommand: [status: ${respData.status}, data: ${respData}]")
	}
}




def statusParse(mainData) {
	if (stTestData) {
		device.updateSetting("stTestData", [type:"bool", value: false])
		log.warn mainData
	}
	def stData = [:]
	if (logEnable || traceLog) {
		def quickLog = [:]
		try {
			quickLog << [
				switch: [device.currentValue("switch"), mainData.switch.switch.value],
				volume: [device.currentValue("volume"), mainData.audioVolume.volume.value.toInteger()],
				mute: [device.currentValue("mute"), mainData.audioMute.mute.value],
				input: [device.currentValue("inputSource"), mainData.mediaInputSource.inputSource.value],
				channel: [device.currentValue("tvChannel"), mainData.tvChannel.tvChannel.value.toString()],
				channelName: [device.currentValue("tvChannelName"), mainData.tvChannel.tvChannelName.value],
				pictureMode: [device.currentValue("pictureMode"), mainData["custom.picturemode"].pictureMode.value],
				soundMode: [device.currentValue("soundMode"), mainData["custom.soundmode"].soundMode.value],
				transportStatus: [device.currentValue("transportStatus"), mainData.mediaPlayback.playbackStatus.value]]
		} catch (err) {
			quickLog << [error: ${err}, data: mainData]
		}
		logDebug("statusParse: [quickLog: ${quickLog}]")
		logTrace("statusParse: [quickLog: ${quickLog}]")
	}

	if (device.currentValue("switch") == "on") {
		Integer volume = mainData.audioVolume.volume.value.toInteger()
		if (device.currentValue("volume") != volume) {
			sendEvent(name: "volume", value: volume)
			sendEvent(name: "level", value: volume)
			stData << [volume: volume]
		}

		String mute = mainData.audioMute.mute.value
		if (device.currentValue("mute") != mute) {
			sendEvent(name: "mute", value: mute)
			stData << [mute: mute]
		}

		String inputSource = mainData.mediaInputSource.inputSource.value
		if (device.currentValue("inputSource") != inputSource) {
			sendEvent(name: "inputSource", value: inputSource)		
			stData << [inputSource: inputSource]
		}

		String tvChannel = mainData.tvChannel.tvChannel.value.toString()
		if (tvChannel == "" || tvChannel == null) {
			tvChannel = " "
		}
		String tvChannelName = mainData.tvChannel.tvChannelName.value
		if (tvChannelName == "") {
			tvChannelName = " "
		}
		if (device.currentValue("tvChannelName") != tvChannelName) {
			sendEvent(name: "tvChannel", value: tvChannel)
			sendEvent(name: "tvChannelName", value: tvChannelName)
			if (tvChannelName.contains(".")) {
				getAppData(tvChannelName)
			} else {
				sendEvent(name: "currentApp", value: " ")
			}
			stData << [tvChannel: tvChannel, tvChannelName: tvChannelName]
			if (getDataValue("frameTv") == "true" && !state.artModeWs) {
				String artMode = "off"
				if (tvChannelName == "art") { artMode = "on" }
				sendEvent(name: "artModeStatus", value: artMode)
			}
		}

		String trackDesc = inputSource
		if (tvChannelName != " ") { trackDesc = tvChannelName }
		if (device.currentValue("trackDescription") != trackDesc) {
			sendEvent(name: "trackDescription", value:trackDesc)
			stData << [trackDescription: trackDesc]
		}

		String pictureMode = mainData["custom.picturemode"].pictureMode.value
		if (device.currentValue("pictureMode") != pictureMode) {
			sendEvent(name: "pictureMode",value: pictureMode)
			stData << [pictureMode: pictureMode]
		}

		String soundMode = mainData["custom.soundmode"].soundMode.value
		if (device.currentValue("soundMode") != soundMode) {
			sendEvent(name: "soundMode",value: soundMode)
			stData << [soundMode: soundMode]
		}

		String transportStatus = mainData.mediaPlayback.playbackStatus.value
		if (transportStatus == null || transportStatus == "") {
			transportStatus = "n/a"
		}
		if (device.currentValue("transportStatus") != transportStatus) {
			sendEvent(name: "transportStatus", value: transportStatus)
			stData << [transportStatus: transportStatus]
		}
	}
	
	if (stData != [:]) {
		logInfo("statusParse: ${stData}")
	}
}




//	== ST Communications
private asyncGet(sendData, passData = "none") {
	if (!stApiKey || stApiKey.trim() == "") {
		logWarn("asyncGet: [status: ERROR, errorMsg: no stApiKey]")
	} else {
		logDebug("asyncGet: ${sendData}, ${passData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]]
		try {
			asynchttpGet(sendData.parse, sendCmdParams, [reason: passData])
		} catch (error) {
			logWarn("asyncGet: [status: FAILED, errorMsg: ${error}]")
		}
	}
}

private syncGet(path){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncGet: ${sendData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]
		]
		try {
			httpGet(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 errorMsg: error]
		}
	}
	return respData
}

private syncPost(sendData){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncPost: ${sendData}")
		def cmdBody = [commands: [sendData.cmdData]]
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()],
			body : new groovy.json.JsonBuilder(cmdBody).toString()
		]
		try {
			httpPost(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data.results]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 errorMsg: error]
		}
	}
	return respData
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
				runIn(1, statusParse, [data: respData.components.main])
			} else {
				statusParse(respData.components.main)
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

//	===== BUTTON INTERFACE =====
def setVariable(appName) {
	sendEvent(name: "variable", value: appName)
	appOpenByName(appName)
}

def push(pushed) {
	logDebug("push: button = ${pushed}, trigger = ${state.triggered}")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	pushed = pushed.toInteger()
	switch(pushed) {
		//	===== Physical Remote Commands =====
		case 2 : mute(); break
		case 3 : numericKeyPad(); break
		case 4 : Return(); break
		case 6 : artMode(); break
		case 7 : ambientMode(); break
		case 45: ambientmodeExit(); break
		case 8 : arrowLeft(); break
		case 9 : arrowRight(); break
		case 10: arrowUp(); break
		case 11: arrowDown(); break
		case 12: enter(); break
		case 13: exit(); break
		case 14: home(); break
		case 18: channelUp(); break
		case 19: channelDown(); break
		case 20: guide(); break
		case 21: volumeUp(); break
		case 22: volumeDown(); break
		//	===== Direct Access Functions
		case 23: menu(); break
		case 24: source(); break
		case 25: info(); break
		case 26: channelList(); break
		//	===== Other Commands =====
		case 34: previousChannel(); break
		case 35: hdmi(); break
		case 36: fastBack(); break
		case 37: fastForward(); break
		//	===== Application Interface =====
		case 38: appOpenByName("Browser"); break
		case 39: appOpenByName("YouTube"); break
		case 40: appOpenByName("RunNetflix"); break
		case 41: close()
		case 42: toggleSoundMode(); break
		case 43: togglePictureMode(); break
		case 44: appOpenByName(device.currentValue("variable")); break
		default:
			logDebug("push: Invalid Button Number!")
			break
	}
}

def parse(resp) {
	if (resp.toString().contains("mac:")) {
		upnpParse(resp)
	} else {
		parseWs(resp)
	}
}

//	===== Libraries =====
#include davegut.samsungTvWebsocket
#include davegut.samsungTvApps
#include davegut.Logging
