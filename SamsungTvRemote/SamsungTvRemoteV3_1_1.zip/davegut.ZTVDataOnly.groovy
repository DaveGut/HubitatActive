metadata {
	definition (name: "Z TV Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

/*
denTv: [
	components:[
		main:[
			mediaPlayback:[
				supportedPlaybackCommands:[value:[play, pause, stop, fastForward, rewind], timestamp:2021-11-16T15:34:13.967Z], 
				playbackStatus:[value:null]], 
			samsungvd.supportsPowerOnByOcf:[supportsPowerOnByOcf:[value:true, timestamp:2022-04-08T21:18:29.927Z]], 
			mediaInputSource:[
				supportedInputSources:[value:[digitalTv, HDMI2], timestamp:2022-06-01T01:29:36.930Z],
				inputSource:[value:HDMI2, timestamp:2022-08-04T21:24:18.167Z]], 
			switch:[switch:[value:off, timestamp:2022-08-05T02:42:09.780Z]], 
			ocf:[
				st:[value:2022-05-31T15:35:14Z, timestamp:2022-06-01T01:29:33.530Z], 
				mndt:[value:2020-01-01, timestamp:2021-11-16T15:34:13.933Z], 
				mnfv:[value:T-NKLAKUC-2303.1, timestamp:2022-07-28T13:16:50.014Z], 
				mnhw:[value:, timestamp:2021-11-16T15:34:13.933Z], 
				di:[value:7e19491f-48f0-5e57-a973-8d63d28bd311, timestamp:2021-11-16T15:34:13.933Z], 
				mnsl:[value:, timestamp:2021-11-16T15:34:13.933Z], 
				dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2021-11-16T15:34:13.933Z], 
				n:[value:DenTV, timestamp:2022-06-14T20:32:10.357Z], 
				mnmo:[value:UN55TU8000FXZA, timestamp:2021-11-16T15:34:13.933Z], 
				vid:[value:VD-STV_2018_K, timestamp:2021-11-16T15:34:13.933Z], 
				mnmn:[value:Samsung Electronics, timestamp:2021-11-16T15:34:13.933Z], 
				mnml:[value:, timestamp:2021-11-16T15:34:13.933Z], 
				mnpv:[value:5.5, timestamp:2021-11-16T15:34:13.933Z], 
				mnos:[value:Tizen, timestamp:2021-11-16T15:34:13.933Z], 
				pi:[value:7e19491f-48f0-5e57-a973-8d63d28bd311, timestamp:2021-11-16T15:34:13.933Z], 
				icv:[value:core.1.1.0, timestamp:2021-11-16T15:34:13.933Z]], 
			custom.accessibility:[:], 
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[samsungvd.ambientContent, sec.diagnosticsInformation], timestamp:2022-06-28T15:12:25.285Z]], 
			samsungvd.remoteControl:[:], 
			sec.diagnosticsInformation:[
				logType:[value:null], endpoint:[value:null], minVersion:[value:null], setupId:[value:null], 
				protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], 
			custom.launchapp:[:], 
			samsungvd.firmwareVersion:[firmwareVersion:[value:3.4.0, timestamp:2021-11-16T15:34:15.778Z]], 
			audioVolume:[volume:[value:36, unit:%, timestamp:2022-08-05T02:10:32.272Z]], 
			samsungvd.mediaInputSource:[
				supportedInputSourcesMap:[value:[
					[id:dtv, name:TV], 
					[id:HDMI2, name:Amazon Fire TV Cube]], timestamp:2021-11-16T15:34:15.521Z], 
				inputSource:[value:HDMI2, timestamp:2022-08-04T21:24:18.167Z]], 
			custom.tvsearch:[:], 
			samsungvd.ambient:[:], 
			refresh:[:], 
			custom.error:[error:[value:null]], 
			execute:[data:[value:null]], 
			tvChannel:[
				tvChannel:[value:, timestamp:2022-08-04T21:24:32.443Z],
				tvChannelName:[value:, timestamp:2022-08-04T21:24:32.443Z]], 
			custom.picturemode:[
				pictureMode:[value:Dynamic, timestamp:2022-07-27T23:02:41.680Z], 
				supportedPictureModes:[value:[Dynamic, FILMMAKER MODE, Movie, Natural, Standard], timestamp:2022-04-11T18:58:10.403Z], 
				supportedPictureModesMap:[value:[
					[id:modeDynamic, name:Dynamic], [id:modeFilmmakerMode, name:FILMMAKER MODE], [id:modeMovie, name:Movie], 
					[id:modeNatural, name:Natural], [id:modeStandard, name:Standard]], timestamp:2022-08-03T02:27:33.628Z]], 
			samsungvd.ambientContent:[supportedAmbientApps:[value:[], timestamp:2021-11-16T15:34:13.967Z]], 
			custom.recording:[:], 
			samsungvd.ambient18:[:], 
			custom.soundmode:[
				supportedSoundModesMap:[value:
										[[id:modeAdaptive, name:Adaptive Sound], [id:modeAmplify, name:Amplify], 
										 [id:modeStandard, name:Standard]], timestamp:2021-11-16T15:34:15.444Z], 
				soundMode:[value:Amplify, timestamp:2022-08-01T01:54:34.187Z], 
				supportedSoundModes:[value:[Adaptive Sound, Amplify, Standard], timestamp:2021-11-16T15:34:15.444Z]], 
			audioMute:[mute:[value:unmuted, timestamp:2022-08-04T21:03:32.926Z]], 
			mediaTrackControl:[supportedTrackControlCommands:[value:null]]]]]

devDescription: [
	deviceId:7e19491f-48f0-5e57-a973-8d63d28bd311, 
	name:[TV] DenTV, 
	label:DenTV, 
	manufacturerName:Samsung Electronics, 
	presentationId:VD-STV_2018_K, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:3194e04d-4739-44dc-b21b-fa4094c7945c, 
	ownerId:8e3c430a-9e98-4730-96e4-eb63f59720da, 
	roomId:9ed45669-5439-4619-af16-19befaaa8049, 
	deviceTypeName:Samsung OCF TV, 
	components:[
		[
			id:main, 
			label:main, 
			capabilities:[
				[id:ocf, version:1], 
				[id:switch, version:1], 
				[id:audioVolume, version:1], 
				[id:audioMute, version:1], 
				[id:tvChannel, version:1], 
				[id:mediaInputSource, version:1], 
				[id:mediaPlayback, version:1], 
				[id:mediaTrackControl, version:1], 
				[id:custom.error, version:1], 
				[id:custom.picturemode, version:1], 
				[id:custom.soundmode, version:1], 
				[id:custom.accessibility, version:1], 
				[id:custom.launchapp, version:1], 
				[id:custom.recording, version:1], 
				[id:custom.tvsearch, version:1], 
				[id:custom.disabledCapabilities, version:1], 
				[id:samsungvd.ambient, version:1], 
				[id:samsungvd.ambientContent, version:1], 
				[id:samsungvd.ambient18, version:1], 
				[id:samsungvd.mediaInputSource, version:1], 
				[id:refresh, version:1], [id:execute, version:1], 
				[id:samsungvd.firmwareVersion, version:1], 
				[id:samsungvd.supportsPowerOnByOcf, version:1], 
				[id:sec.diagnosticsInformation, version:1]], 
			categories:[[name:Television, categoryType:manufacturer]]]], 
	createTime:2021-11-16T15:34:13.716Z, 
	profile:[id:f61f6245-d29d-3e7d-bbfa-9273fd068a61], 
	ocf:[
		ocfDeviceType:oic.d.tv, 
		name:[TV] DenTV, 
		specVersion:core.1.1.0, 
		verticalDomainSpecVersion:res.1.1.0,sh.1.1.0,
		manufacturerName:Samsung Electronics, 
		modelNumber:UN55TU8000FXZA, 
		platformVersion:5.5, 
		platformOS:Tizen, 
		hwVersion:,
		firmwareVersion:T-NKLAKUC-2201.0, 
		vendorId:VD-STV_2018_K, 
		vendorResourceClientServerVersion:2.3.23, 
		locale:en_US, 
		lastSignupTime:2021-11-16T15:34:08.796235Z],
	type:OCF,
	restrictionTier:0,
	allowed:[]]]



*/