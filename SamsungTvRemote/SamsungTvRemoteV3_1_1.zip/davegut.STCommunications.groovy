library (
	name: "ST-Communications",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "ST Communications Methods",
	category: "utilities",
	documentationLink: ""
)
import groovy.json.JsonSlurper

private asyncGet(sendData, passData = "none") {
	if (!stApiKey || stApiKey.trim() == "") {
		logWarn("asyncGet: [status: ERROR, errorMsg: no stApiKey]")
	} else {
		logDebug("asyncGet: ${sendData}, ${passData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]]
		try {
			asynchttpGet(sendData.parse, sendCmdParams, [reason: passData])
		} catch (error) {
			logWarn("asyncGet: [status: FAILED, errorMsg: ${error}]")
		}
	}
}

private syncGet(path){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncGet: ${sendData}")
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()]
		]
		try {
			httpGet(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 httpCode: "Timeout",
						 errorMsg: error]
		}
	}
	return respData
}

private syncPost(sendData){
	def respData = [:]
	if (!stApiKey || stApiKey.trim() == "") {
		respData << [status: "FAILED",
					 errorMsg: "No stApiKey"]
	} else {
		logDebug("syncPost: ${sendData}")

		def cmdBody = [commands: [sendData.cmdData]]
		def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: sendData.path,
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()],
			body : new groovy.json.JsonBuilder(cmdBody).toString()
		]
		try {
			httpPost(sendCmdParams) {resp ->
				if (resp.status == 200 && resp.data != null) {
					respData << [status: "OK", results: resp.data.results]
				} else {
					respData << [status: "FAILED",
								 httpCode: resp.status,
								 errorMsg: resp.errorMessage]
				}
			}
		} catch (error) {
			respData << [status: "FAILED",
						 httpCode: "Timeout",
						 errorMsg: error]
		}
	}
	return respData
}
