/*	===== HUBITAT INTEGRATION VERSION =====================================================
Hubitat - Samsung TV Remote Driver
		Copyright 2022 Dave Gutheinz
Licensed under the Apache License, Version 2.0 (the "License"); you may not use this  file
except in compliance with the License. You may obtain a copy of the License at:
		http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software distributed under the
License is distributed on an  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
either express or implied. See the License for the specific language governing permissions
and limitations under the  License.
===== DISCLAIMERS =========================================================================
	THE AUTHOR OF THIS INTEGRATION IS NOT ASSOCIATED WITH SAMSUNG. THIS CODE USES
	TECHNICAL DATA DERIVED FROM GITHUB SOURCES AND AS PERSONAL INVESTIGATION.
===== APPRECIATION ========================================================================
	Hubitat user Cal for technical, test, and emotional support.
	GitHub user Toxblh for exlempary code for numerous commands
	Hubitat users who supported validation of 2016 - 2020 models.
===== 2022 Version 3.1 ====================================================================
Preferences
a.	Added preference wolMethod to allow user to select on method between three WOL formats
	or using the SmartThing ON command.  ST ON will only work is ST is enabled.
b.	Removed Refresh Interval as no longer necessary (superceded by poll).
Methods:
a.	onPoll: Modified as follows:
	1.	If ST enabled, will use the ST poll command.
	2.	If ST not enabled, modifies previous method to update switch attribute for
		off detection to require three detections prior to setting switch attribute.
Known Issue:	for newer TV's, Samsung has removed the remote Key to control artMode.
				Expect art mode functions to be intermittent until I find a true fix.
===========================================================================================*/
def driverVer() { return "3.1.1" }
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

metadata {
	definition (name: "Samsung TV Remote",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungTvRemote/SamsungTVRemote.groovy"
			   ){
		capability "SamsungTV"			//	cmds: on/off, volume, mute. attrs: switch, volume, mute
		command "showMessage", [[name: "NOT IMPLEMENTED"]]
		command "setVolume", ["SmartThings Function"]	//	SmartThings
		command "setPictureMode", ["SmartThings Function"]	//	SmartThings
		command "setSoundMode", ["SmartThings Function"]	//	SmartThings
		capability "Switch"
		//	===== UPnP Augmentation =====
		command "pause"				//	Only work on TV Players
		command "play"					//	Only work on TV Players
		command "stop"					//	Only work on TV Players
		//	===== Remote Control Interface =====
		command "sendKey", ["string"]	//	Send entered key. eg: HDMI
		command "artMode"				//	Toggles artModeStatus
		attribute "artModeStatus", "string"	//	on/off/notFrame
		command "ambientMode"			//	non-Frame TVs
		//	Cursor and Entry Control
		command "arrowLeft"
		command "arrowRight"
		command "arrowUp"
		command "arrowDown"
		command "enter"
		command "numericKeyPad"
		//	Menu Access
		command "home"
		command "menu"
		command "guide"
		command "info"					//	Pops up Info banner
		//	Source Commands
		command "source"				//	Pops up source window
		command "hdmi"					//	Direct progression through available sources
		command "setInputSource", ["SmartThings Function"]	//	SmartThings
		attribute "inputSource", "string"					//	SmartThings
		attribute "inputSources", "string"					//	SmartThings
		//	TV Channel
		command "channelList"
		command "channelUp"
		command "channelDown"
		command "previousChannel"
		command "nextChannel"
		command "setTvChannel", ["SmartThings Function"]	//	SmartThings
		attribute "tvChannel", "string"						//	SmartThings
		attribute "tvChannelName", "string"					//	SmartThings
		//	Playing Navigation Commands
		command "exit"
		command "Return"
		command "fastBack"
		command "fastForward"
		
		command "toggleInputSource", [[name: "SmartThings Function"]]	//	SmartThings
		command "toggleSoundMode", [[name: "SmartThings Function"]]	//	SmartThings
		command "togglePictureMode", [[name: "SmartThings Function"]]	//	SmartThings
		
		//	Application Access/Control
		command "appOpenByName", ["string"]
		command "appCloseNamedApp"
		command "appInstallByCode", ["string"]
		command "appOpenByCode", ["string"]
		command "appRunBrowser"
		command "appRunYouTube"
		command "appRunNetflix"
		command "appRunPrimeVideo"
		command "appRunYouTubeTV"
		command "appRunHulu"
		//	===== Button Interface =====
		capability "PushableButton"
		//	for media player tile
		command "setLevel", ["SmartThings Function"]	//	SmartThings
		attribute "transportStatus", "string"
		attribute "level", "NUMBER"
		attribute "trackDescription", "string"
		command "nextTrack", [[name: "Sets Channel Up"]]
		command "previousTrack", [[name: "Sets Channel Down"]]
	}
	preferences {
		input ("deviceIp", "text", title: "Samsung TV Ip", defaultValue: "")
		if (deviceIp) {
			input ("tvPwrOnMode", "enum", title: "TV Startup Display", 
				   options: ["ART_MODE", "Ambient", "none"], defaultValue: "none")
			input ("debugLog", "bool",  title: "Enable debug logging for 30 minutes", defaultValue: false)
			input ("infoLog", "bool", 
				   title: "Enable information logging " + helpLogo(),
				   defaultValue: true)
			input ("connectST", "bool", title: "Connect to SmartThings for added functions", defaultValue: false)
		}
		if (connectST) {
			input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
			if (stApiKey) {
				input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
			}
			input ("wolMethod", "enum", title: "Wol (ON) Method", 
				   options: ["1": "Hubitat Magic Packet", "2": "UDP Message", 
							 "3": "Use Alternate Wol MAC", "4": "Use Smart Things"], defaultValue: "2")
			input ("stPowerPoll", "bool", title: "Use SmartThings for Power Polling", defaultValue: false)
		} else {
			input ("wolMethod", "enum", title: "Wol (ON) Method", 
				   options: ["1": "Hubitat Magic Packet", "2": "UDP Message", 
							 "3": "Use Alternate Wol MAC"], defaultValue: "2")
		}
		if (connectST && stPowerPoll) {
			input ("pollInterval","enum", title: "Power Polling Interval (seconds)",
				   options: ["10", "15", "20", "30", "60"], defaultValue: "60")
		} else {
			input ("pollInterval","enum", title: "Power Polling Interval (seconds)",
				   options: ["5", "10", "15", "20", "30", "60"], defaultValue: "60")
		}
	}
}

String helpLogo() { // library marker davegut.kasaCommon, line 11
	return """<a href="https://github.com/DaveGut/HubitatActive/blob/master/SamsungTvRemote/README.md">""" +
		"""<div style="position: absolute; top: 10px; right: 10px; height: 80px; font-size: 20px;">Samsung TV Remote Help</div></a>"""
}

//	===== Installation, setup and update =====
def installed() {
	state.token = "12345678"
	def tokenSupport = "false"
	runIn(1, updated)
}

def updated() {
	unschedule()
	def updStatus = [:]
	if (!deviceIp) {
		logWarn("\n\n\t\t<b>Enter the deviceIp and Save Preferences</b>\n\n")
		updStatus << [status: "ERROR", data: "Device IP not set."]
	} else {
		updStatus << [getDeviceData: getDeviceData()]
		if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
			updateDataValue("driverVersion", driverVer())
			updStatus << [driverVer: driverVer()]
		}
		state.offCount = 0
		if (debugLog) { runIn(1800, debugLogOff) }
		updStatus << [debugLog: debugLog, infoLog: infoLog]
		def interval = pollInterval
		if (interval == "60" || interval == "off" || interval == null) {
			runEvery1Minute(onPoll)
		} else {
			if (connectST && stPowerPoll && interval == "5") {
				interval = "10"
				device.updateSetting("pollInterval", [type:"enum", value: "10"])
			}		
			schedule("0/${interval} * * * * ?",  onPoll)
		}
		updStatus << [pollInterval: interval]
		if (getDataValue("frameTv") == "true" && getDataValue("modelYear").toInteger() >= 2022) {
			state.___2022_Model_Note___ = "artMode keys and functions may not work on this device. Changes in Tizen OS."
			updStatus << [artMode: "May not work"]
		} else {
			state.remove("___2022_Model_Note___")
		}
		updStatus << [stUpdate: stUpdate()]
	}

	if (updStatus.toString().contains("ERROR")) {
		logWarn("updated: ${updStatus}")
	} else {
		logInfo("updated: ${updStatus}")
	}
}

def getDeviceData() {
	def respData = [:]
	if (getDataValue("uuid")) {
		respData << [status: "already run"]
	} else {
		try{
			httpGet([uri: "http://${deviceIp}:8001/api/v2/", timeout: 5]) { resp ->
				def wifiMac = resp.data.device.wifiMac
				updateDataValue("deviceMac", wifiMac)
				def alternateWolMac = wifiMac.replaceAll(":", "").toUpperCase()
				updateDataValue("alternateWolMac", alternateWolMac)
				device.setDeviceNetworkId(alternateWolMac)
				
				def modelYear = "20" + resp.data.device.model[0..1]
				updateDataValue("modelYear", modelYear)
				def frameTv = "false"
				if (resp.data.device.FrameTVSupport) {
					frameTv = resp.data.device.FrameTVSupport
					sendEvent(name: "artModeStatus", value: "notFrameTV")
					respData << [artModeStatus: "notFrameTV"]
				}
				updateDataValue("frameTv", frameTv)
				if (resp.data.device.TokenAuthSupport) {
					tokenSupport = resp.data.device.TokenAuthSupport
					updateDataValue("tokenSupport", tokenSupport)
				}
				def uuid = resp.data.device.duid.substring(5)
				updateDataValue("uuid", uuid)
				respData << [status: "OK", dni: alternateWolMac, modelYear: modelYear,
							 frameTv: frameTv, tokenSupport: tokenSupport]
			}
		} catch (error) {
			respData << [status: "ERROR", reason: error]
		}
	}
	return respData
}

def stUpdate() {
	def stData = [:]
	if (!connectST) {
		stData << [status: "Preference connectST not true"]
	} else if (!stApiKey || stApiKey == "") {
		logWarn("\n\n\t\t<b>Enter the ST API Key and Save Preferences</b>\n\n")
		stData << [status: "ERROR", date: "no stApiKey"]
	} else if (!stDeviceId || stDeviceId == "") {
		getDeviceList()
		logWarn("\n\n\t\t<b>Enter the deviceId from the Log List and Save Preferences</b>\n\n")
		stData << [status: "ERROR", date: "no stDeviceId"]
	} else {
		if (!stPowerPoll) {
			runEvery1Minute(stRefresh)
		}
		if (device.currentValue("volume") == null) {
			sendEvent(name: "volume", value: 0)
		}
		runIn(5, stRefresh)
		stData << [stRefreshInterval: "1 minute"]
	}
	return stData
}

def stRefresh() {
	if (connectST && device.currentValue("switch") == "on") {
		refresh()
	}
}


//	===== Polling/Refresh Capability =====
def onPoll(forceLocal = false) {
	if (!forceLocal && connectST && stPowerPoll) {
		def sendData = [
			path: "/devices/${stDeviceId.trim()}/status",
			parse: "stOnParse"
		]
		asyncGet(sendData, "onOffPoll")
	} else {
		def sendCmdParams = [
			uri: "http://${deviceIp}:8001/api/v2/",
			timeout: 10]
		asynchttpGet("onParse", sendCmdParams, [reason: "none"])
	}
}

def stOnParse(resp, data) {
	if (resp.status == 200) {
		def respData = new JsonSlurper().parseText(resp.data)
		statusParse(respData.components.main)
	} else {
		def respError = [status: "ERROR",
						 httpCode: resp.status,
						 errorMsg: resp.errorMessage]
		logWarn("stOnParse: ${respError}. Running onPoll with forceLocal = true.")
		onPoll(true)
	}
}

def onParse(resp, data) {
	if (resp.status == 200) {
		state.offCount = 0
		if (device.currentValue("switch") != "on") {
			sendEvent(name: "switch", value: "on")
			logInfo("onParse: [switch: on]")
			setPowerOnMode()
		}
		if (data == "onOffPoll") {
			distResp(resp, data)
		}
	} else {
		if (state.offCount > 2) {
			if (device.currentValue("switch") != "off") {
				sendEvent(name: "switch", value: "off")
				logInfo("onParse: [switch: off]")
			}
		} else {
			state.offCount += 1
			runIn(1, onPoll, [data: true])
		}
	}
}

def setPowerOnMode() {
	if(tvPwrOnMode == "ART_MODE" && getDataValue("frameTv") == "true") {
		artMode("on")
	} else if (tvPwrOnMode == "Ambient") {
		ambientMode()
	}
	connect("remote")
}		

def on() {
	logDebug("on: [dni: ${device.deviceNetworkId}, wolMethod: ${wolMethod}]")
	def wol
	if (wolMethod == "2") {
		def wolMac = getDataValue("alternateWolMac")
		def cmd = "FFFFFFFFFFFF$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac"
		wol = new hubitat.device.HubAction(cmd,
											   hubitat.device.Protocol.LAN,
											   [type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
												destinationAddress: "255.255.255.255:7",
												encoding: hubitat.device.HubAction.Encoding.HEX_STRING])
		sendHubCommand(wol)
	} else if (wolMethod == "3") {
		wol = new hubitat.device.HubAction("wake on lan ${getDataValue("alternateWolMac")}",
											   hubitat.device.Protocol.LAN,
											   null)
		sendHubCommand(wol)
	} else if (wolMethod == "4") {
		setSwitch("on")
	} else {
		wol = new hubitat.device.HubAction("wake on lan ${device.deviceNetworkId}",
											   hubitat.device.Protocol.LAN,
											   null)
		sendHubCommand(wol)
	}
	if (pollInterval.toInteger() > 10) {
		runIn(5, onPoll)
	}
}

def off() {
	logDebug("off: frameTv = ${getDataValue("frameTV")}")
	if (getDataValue("frameTv") == "false") { sendKey("POWER") }
	else {
		sendKey("POWER", "Press")
		pauseExecution(3000)
		sendKey("POWER", "Release")
	}
	sendEvent(name: "switch", value: "off")
}



def showMessage() { logWarn("showMessage: not implemented") }

//	===== LAN Websocket Interface =====
def mute() {
	sendKey("MUTE")
	runIn(5, stRefresh)
}
def unmute() {
	sendKey("MUTE")
	runIn(5, stRefresh)
}
def volumeUp() { 
	sendKey("VOLUP") 
	runIn(5, stRefresh)
}
def volumeDown() { 
	sendKey("VOLDOWN")
	runIn(5, stRefresh)
}

def play() { sendKey("PLAY") }
def pause() { sendKey("PAUSE") }
def stop() { sendKey("STOP") }
def exit() { sendKey("EXIT") }
def Return() { sendKey("RETURN") }
def fastBack() {
	sendKey("LEFT", "Press")
	pauseExecution(1000)
	sendKey("LEFT", "Release")
}
def fastForward() {
	sendKey("RIGHT", "Press")
	pauseExecution(1000)
	sendKey("RIGHT", "Release")
}

def arrowLeft() { sendKey("LEFT") }
def arrowRight() { sendKey("RIGHT") }
def arrowUp() { sendKey("UP") }
def arrowDown() { sendKey("DOWN") }
def enter() { sendKey("ENTER") }
def numericKeyPad() { sendKey("MORE") }

def home() { sendKey("HOME") }
def menu() { sendKey("MENU") }
def guide() { sendKey("GUIDE") }
def info() { sendKey("INFO") }

def source() { 
	sendKey("SOURCE")
	runIn(5, stRefresh)
}
def hdmi() {
	sendKey("HDMI")
	runIn(5, stRefresh)
}

def channelList() { sendKey("CH_LIST") }
def channelUp() { 
	sendKey("CHUP") 
	runIn(5, stRefresh)
}
def nextTrack() { channelUp() }
def channelDown() { 
	sendKey("CHDOWN") 
	runIn(5, stRefresh)
}
def previousTrack() { channelDown() }
def previousChannel() { 
	sendKey("PRECH") 
	runIn(5, stRefresh)
}

def artMode() {
	if (getDataValue("modelYear").toInteger() >= 2022) {
		logWarn("artMode: Art Mode may not work on 2022 and later model years")
	}
	if (getDataValue("frameTv") == "false") {
		logInfo("artMode: Command not executed. Not a frameTv.")
		return
	}
	getArtModeStatus()
	def onOff = "on"
	if (device.currentValue("artModeStatus") == "on") {
		onOff = "off"
	}
	logDebug("artMode: setting artMode to ${onOff}.")
	def data = [value:"${onOff}",
				request:"set_artmode_status",
				id: "${getDataValue("uuid")}"]
	data = JsonOutput.toJson(data)
	artModeCmd(data)
}
def getArtModeStatus() {
	def data = [request:"get_artmode_status",
				id: "${getDataValue("uuid")}"]
	data = JsonOutput.toJson(data)
	artModeCmd(data)
}
def artModeCmd(data) {
	def cmdData = [method:"ms.channel.emit",
				   params:[data:"${data}",
						   to:"host",
						   event:"art_app_request"]]
	cmdData = JsonOutput.toJson(cmdData)
	sendMessage("frameArt", cmdData)	//	send command, connect is automatic.
}
def ambientMode() {
	if (getDataValue("modelYear").toInteger() >= 2022) {
		logWarn("artMode: Ambient Mode may not work on 2022 and later model years")
	}
	logDebug("ambientMode: frameTv = ${getDataValue("frameTv")}")
	if (getDataValue("frameTv") == "true") { return }
	sendKey("AMBIENT")
}

def sendKey(key, cmd = "Click") {
	key = "KEY_${key.toUpperCase()}"
	def data = [method:"ms.remote.control",
				params:[Cmd:"${cmd}",
						DataOfCmd:"${key}",
						TypeOfRemote:"SendRemoteKey"]]
	sendMessage("remote", JsonOutput.toJson(data) )
}

def connect(funct) {
	logDebug("connect: function = ${funct}")
	def url
	def name = "SHViaXRhdCBTYW1zdW5nIFJlbW90ZQ=="
	if (getDataValue("tokenSupport") == "true") {
		if (funct == "remote") {
			url = "wss://${deviceIp}:8002/api/v2/channels/samsung.remote.control?name=${name}&token=${state.token}"
		} else if (funct == "frameArt") {
			url = "wss://${deviceIp}:8002/api/v2/channels/com.samsung.art-app?name=${name}&token=${state.token}"
		} else if (funct == "application") {
			url = "ws://${deviceIp}:8001/api/v2/applications?name=${name}"
		} else {
			logWarn("sendMessage: Invalid Function = ${funct}, tokenSupport = true")
		}
	} else {
		if (funct == "remote") {
			url = "ws://${deviceIp}:8001/api/v2/channels/samsung.remote.control?name=${name}"
		} else if (funct == "frameArt") {
			url = "ws://${deviceIp}:8001/api/v2/channels/com.samsung.art-app?name=${name}"
		} else if (funct == "application") {
			url = "ws://${deviceIp}:8001/api/v2?name=${name}"
		} else {
			logWarn("sendMessage: Invalid Function = ${funct}, tokenSupport = false")
		}
	}
	state.currentFunction = funct
	interfaces.webSocket.connect(url, ignoreSSLIssues: true)
}

def sendMessage(funct, data) {
	logDebug("sendMessage: function = ${funct} | data = ${data} | connectType = ${state.currentFunction}")
	if (state.wsDeviceStatus != "open" || state.currentFunction != funct) {
		connect(funct)
		pauseExecution(300)
	}
	interfaces.webSocket.sendMessage(data)
}

def webSocketStatus(message) {
	if (message == "status: open") {
		state.wsDeviceStatus = "open"
		logDebug("webSocketStatus: wsDeviceStatus = open")
	} else if (message == "status: closing") {
		state.wsDeviceStatus = "closed"
		state.currentFunction = "close"
		logDebug("webSocketStatus: wsDeviceStatus = closed")
	} else if (message.substring(0,7) == "failure") {
		logDebug("webSocketStatus: Failure.  Closing Socket.")
		state.wsDeviceStatus = "closed"
		state.currentFunction = "close"
		interfaces.webSocket.close()
	}
}

def parse(resp) {
	try {
		resp = parseJson(resp)
	} catch (e) {
		logWarn("parse: Unhandled websocket return. resp =\n${resp}")
	}
	logDebug("parse: ${resp}")
	def event = resp.event
	def logMsg = "parse: event = ${event}"
	if (event == "ms.channel.connect") {
		logMsg += ", webSocket open"
		def newToken = resp.data.token
		if (newToken != null && newToken != state.token) {
			logMsg += ", token updated to ${newToken}"
			state.token = newToken
		}
	} else if (event == "d2d_service_message") {
		def data = parseJson(resp.data)
		if (data.event == "artmode_status" ||
			data.event == "art_mode_changed") {
			def status = data.value
			if (status == null) { status = data.status }
			sendEvent(name: "artModeStatus", value: status)
			logMsg += ", artMode status = ${data.value}"
		}
	} else if (event == "ms.channel.ready") {
		logMsg += ", webSocket connected"
	} else if (event == "ms.error") {
		logMsg += "Error Event.  Closing webSocket"
		close{}
	} else {
		logMsg += ", message = ${resp}"
	}
	logDebug(logMsg)
}



//	===== LAN HTTP Implementation =====
def appRunBrowser() { appOpenByCode("org.tizen.browser") }
def appRunYouTube() { appOpenByName("YouTube") }
def appRunNetflix() { appOpenByName("Netflix") }
def appRunPrimeVideo() { appOpenByName("AmazonInstantVideo") }
def appRunYouTubeTV() { appOpenByName("YouTubeTV") }
def appRunHulu() { appOpenByCode("3201601007625") }
def appOpenByName(appName) {
	def url = "http://${deviceIp}:8080/ws/apps/${appName}"
	try {
		httpPost(url, "") { resp ->
			logDebug("appOpenByName: [name: ${appName}, status: ${resp.status}, data: ${resp.data}]")
		}
	} catch (e) {
		logWarn("appOpenByName: [name: ${appName}, status: FAILED, data: ${e}]")
	}
}
def appOpenByCode(appId) {
	def uri = "http://${deviceIp}:8001/api/v2/applications/${appId}"
	try {
		httpPost(uri, body) { resp ->
			logDebug("appOpenByCode: [code: ${appId}, status: ${resp.status}, data: ${resp.data}]")
		}
		runIn(5, appGetData, [data: appId]) 
	} catch (e) {
		logWarn("appOpenByCode: [code: ${appId}, status: FAILED, data: ${e}]")
	}
}



//	===== CLOUD SmartThings Implementation =====
def setSwitch(onOff) {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: onOff,
		arguments: []]
	deviceCommand(cmdData)
}

def setLevel(level) { setVolume(level) }
def setVolume(volume) {
	def cmdData = [
		component: "main",
		capability: "audioVolume",
		command: "setVolume",
		arguments: [volume.toInteger()]]
	deviceCommand(cmdData)
}

def togglePictureMode() {
	//	requires state.pictureModes
	def pictureModes = state.pictureModes
	def totalModes = pictureModes.size()
	def currentMode = device.currentValue("pictureMode")
	def modeNo = pictureModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def newPictureMode = pictureModes[newModeNo]
	setPictureMode(newPictureMode)
}
def setPictureMode(pictureMode) {
	def cmdData = [
		component: "main",
		capability: "custom.picturemode",
		command: "setPictureMode",
		arguments: [pictureMode]]
	deviceCommand(cmdData)
}

def toggleSoundMode() {
	def soundModes = state.soundModes
	def totalModes = soundModes.size()
	def currentMode = device.currentValue("soundMode")
	def modeNo = soundModes.indexOf(currentMode)
	def newModeNo = modeNo + 1
	if (newModeNo == totalModes) { newModeNo = 0 }
	def soundMode = soundModes[newModeNo]
	setSoundMode(soundMode)
}
def setSoundMode(soundMode) { 
	def cmdData = [
		component: "main",
		capability: "custom.soundmode",
		command: "setSoundMode",
		arguments: [soundMode]]
	deviceCommand(cmdData)
}

def toggleInputSource() {
	def inputSources = state.supportedInputs
	def totalSources = inputSources.size()
	def currentSource = device.currentValue("mediaInputSource")
	def sourceNo = inputSources.indexOf(currentSource)
	def newSourceNo = sourceNo + 1
	if (newSourceNo == totalSources) { newSourceNo = 0 }
	def inputSource = inputSources[newSourceNo]
	setInputSource(inputSource)
}
def setInputSource(inputSource) {
	def cmdData = [
		component: "main",
		capability: "mediaInputSource",
		command: "setInputSource",
		arguments: [inputSource]]
	deviceCommand(cmdData)
}

def setTvChannel(newChannel) {
	def cmdData = [
		component: "main",
		capability: "tvChannel",
		command: "setTvChannel",
		arguments: [newChannel]]
	deviceCommand(cmdData)
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
			}
			statusParse(respData.components.main)
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(mainData) {
	def setupData = [:]
	def supportedInputs =  mainData.mediaInputSource.supportedInputSources.value
	sendEvent(name: "supportedInputs", value: supportedInputs)	
	state.supportedInputs = supportedInputs
	setupData << [supportedInputs: supportedInputs]
	
	def pictureModes = mainData["custom.picturemode"].supportedPictureModes.value
	sendEvent(name: "pictureModes",value: pictureModes)
	state.pictureModes = pictureModes
	setupData << [pictureModes: pictureModes]
	
	def soundModes =  mainData["custom.soundmode"].supportedSoundModes.value
	sendEvent(name: "soundModes",value: soundModes)
	state.soundModes = soundModes
	setupData << [soundModes: soundModes]
	
	logInfo("deviceSetupParse: ${setupData}")
}

def statusParse(mainData) {
	def stData = [:]
	
	def onOff = mainData.switch.switch.value
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff)
		stData << [switch: onOff]
		if (onOff == "on") {
			setPowerOnMode()
		}
	}
	
	if (onOff == "on") {
		def volume = mainData.audioVolume.volume.value.toInteger()
		if (device.currentValue("volume").toInteger() != volume) {
			sendEvent(name: "volume", value: volume)
			stData << [volume: volume]
		}
	
		def mute = mainData.audioMute.mute.value
		if (device.currentValue("mute") != mute) {
			sendEvent(name: "mute", value: mute)
			stData << [mute: mute]
		}
	
		def inputSource = mainData.mediaInputSource.inputSource.value
		if (device.currentValue("inputSource") != inputSource) {
			sendEvent(name: "inputSource", value: inputSource)		
			stData << [inputSource: inputSource]
		}
		
		def tvChannel = mainData.tvChannel.tvChannel.value
		if (tvChannel == "") { tvChannel = " " }
		def tvChannelName = mainData.tvChannel.tvChannelName.value
		if (tvChannelName == "") { tvChannelName = " " }
		if (device.currentValue("tvChannel") != tvChannel) {
			sendEvent(name: "tvChannel", value: tvChannel)
			sendEvent(name: "tvChannelName", value: tvChannelName)
			stData << [tvChannel: tvChannel, tvChannelName: tvChannelName]
		}
		
		def trackDesc = inputSource
		if (tvChannelName != " ") { trackDesc = tvChannelName }
		if (device.currentValue("trackDescription") != trackDesc) {
			sendEvent(name: "trackDescription", value:trackDesc)
			stData << [trackDescription: trackDesc]
		}
	
		def pictureMode = mainData["custom.picturemode"].pictureMode.value
		if (device.currentValue("pictureMode") != pictureMode) {
			sendEvent(name: "pictureMode",value: pictureMode)
			stData << [pictureMode: pictureMode]
		}
	
		def soundMode = mainData["custom.soundmode"].soundMode.value
		if (device.currentValue("soundMode") != soundMode) {
			sendEvent(name: "soundMode",value: soundMode)
			stData << [soundMode: soundMode]
		}
	
		def transportStatus = mainData.mediaPlayback.playbackStatus.value
		if (transportStatus == null || transportStatus == "") {
			transportStatus = "stopped"
		}
		if (device.currentValue("transportStatus") != transportStatus) {
			sendEvent(name: "transportStatus", value: transportStatus)
			stData << [transportStatus: transportStatus]
		}
	}
	
	if (stData != [:]) {
		logInfo("statusParse: ${stData}")
	}
//	listAttributes()
}


//	===== Button Interface (facilitates dashboard integration) =====
def push(pushed) {
	logDebug("push: button = ${pushed}, trigger = ${state.triggered}")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	pushed = pushed.toInteger()
	switch(pushed) {
		//	===== Physical Remote Commands =====
		case 2 : mute(); break
		case 3 : numericKeyPad(); break
		case 4 : Return(); break
		case 6 : artMode(); break			//	New command.  Toggles art mode
		case 7 : ambientMode(); break
		case 8 : arrowLeft(); break
		case 9 : arrowRight(); break
		case 10: arrowUp(); break
		case 11: arrowDown(); break
		case 12: enter(); break
		case 13: exit(); break
		case 14: home(); break
		case 18: channelUp(); break
		case 19: channelDown(); break
		case 20: guide(); break
		case 21: volumeUp(); break
		case 22: volumeDown(); break
		//	===== Direct Access Functions
		case 23: menu(); break			//	Main menu with access to system settings.
		case 24: source(); break		//	Pops up home with cursor at source.  Use left/right/enter to select.
		case 25: info(); break			//	Pops up upper display of currently playing channel
		case 26: channelList(); break	//	Pops up short channel-list.
		//	===== Other Commands =====
		case 34: previousChannel(); break
		case 35: hdmi(); break			//	Brings up next available source
		case 36: fastBack(); break		//	causes fast forward
		case 37: fastForward(); break	//	causes fast rewind
		case 38: appRunBrowser(); break		//	Direct to source 1 (ofour right of TV on menu)
		case 39: appRunYouTube(); break
		case 40: appRunNetflix(); break
		case 42: toggleSoundMode(); break
		case 43: togglePictureMode(); break
		case 44: setPictureMode("Dynamic"); break
		default:
			logDebug("push: Invalid Button Number!")
			break
	}
}

def simulate() { return false }


#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
