library (
	name: "samsungAudioNotify",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung Audio Notify Functions",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject

//	===== Voices.rss TTS Languages =====
def ttsLanguages() {
	def languages = [
		"en-au":"English (Australia)","en-ca":"English (Canada)",
		"en-gb":"English (Great Britain)","en-us":"English (United States)",
		"en-in":"English (India)","ca-es":"Catalan","zh-cn":"Chinese (China)", 
		"zh-hk":"Chinese (Hong Kong)","zh-tw":"Chinese (Taiwan)",
		"da-dk":"Danish", "nl-nl":"Dutch","fi-fi":"Finnish",
		"fr-ca":"French (Canada)","fr-fr":"French (France)","de-de":"German",
		"it-it":"Italian","ja-jp":"Japanese","ko-kr":"Korean",
		"nb-no":"Norwegian","pl-pl":"Polish","pt-br":"Portuguese (Brazil)",
		"pt-pt":"Portuguese (Portugal)","ru-ru":"Russian",
		"es-mx":"Spanish (Mexico)","es-es":"Spanish (Spain)",
		"sv-se":"Swedish (Sweden)"]
	return languages
}

//	===== Audio Notification / URL-URI Playback functions
def testAudioNotify() {
	logInfo("testAudioNotify: Testing audio notification interfaces")
	runIn(3, testTextNotify)
	playTrack("""http://s3.amazonaws.com/smartapp-media/sonos/dogs.mp3""", 8)
}
def testTextNotify() {
	playText("This is a test of the Text-to-speech function", 9)
}

def playText(text, volume = null) {
	createTextData(text, volume, true, "playText")
}

def playTextAndRestore(text, volume = null) {
	createTextData(text, volume, false, "playTextAndRestore")
}

def playTextAndResume(text, volume = null) {
	createTextData(text, volume, true, "playTextAndResume")
}

def createTextData(text, volume, resume, method) {
	if (volume == null) { volume = device.currentValue("volume") }
	def logData = [method: method, text: text, volume: volume, resume: resume]
	def trackUri
	def duration
	text = "<s>     <s>${text}."
	if (altTts) {
		if (ttsApiKey == null) {
			logWarn("convertToTrack: [FAILED: No ttsApiKey]")
		} else {
			def uriText = URLEncoder.encode(text, "UTF-8").replaceAll(/\+/, "%20")
			trackUri = "http://api.voicerss.org/?" +
				"key=${ttsApiKey.trim()}" +
				"&c=MP3" +
				"&hl=${ttsLang}" +
				"&src=${uriText}"
			duration = (2 + text.length() / 10).toInteger()
			track =  [uri: trackUri, duration: duration]
		}
	} else {
		def track = textToSpeech(text, voice)
		trackUri = track.uri
		duration = track.duration
	}
	logData << [trackUri: trackUri, duration: duration]
//	addToQueue(trackUri, duration, volume, resume)
	addToQueue(trackUri, duration, volume)
	logInfo("createTextData: ${logData}")
}

def playTrack(trackData, volume = null) {
	createPlayData(trackData, volume, true, "playTrack")
}

def playTrackAndRestore(trackData, volume=null) {
	createPlayData(trackData, volume, false, "playTrackAndRestore")
}

def playTrackAndResume(trackData, volume=null) {
	createPlayData(trackData, volume, true, "playTrackAndResume")
}

def createPlayData(trackData, volume, resume, method) {
	if (volume == null) { volume = device.currentValue("volume") }
	def logData = [method: method, trackData: text, volume: volume, resume: resume]
	def trackUri
	def duration
	if (trackData[0] == "[") {
		logData << [status: "aborted", reason: "trackData not formated as {uri: , duration: }"]
	} else {
		if (trackData[0] == "{") {
			trackData = new JSONObject(trackData)
			trackUri = trackData.uri
			duration = trackData.duration
		} else {
			trackUri = trackData
			duration = 15
		}
		logData << [status: "addToQueue", trackData: trackData, volume: volume, resume: resume]
//		addToQueue(trackUri, duration, volume, resume)
		addToQueue(trackUri, duration, volume)
	}
	logDebug("createPlayData: ${logData}")
}

//	========== Play Queue Execution ==========
def addToQueue(trackUri, duration, volume){
	if(device.currentValue("switch") == "on") {
		def logData = [:]
		duration = duration + 3
		playData = ["trackUri": trackUri, 
					"duration": duration,
					"requestVolume": volume]
		state.playQueue.add(playData)	
		logData << [addedToQueue: [uri: trackUri, duration: duration, volume: volume]]	

		if (state.playingNotification == false) {
			runInMillis(100, startPlayViaQueue)
		}
		logDebug("addToQueue: ${logData}")
	}
}

def startPlayViaQueue() {
	logDebug("startPlayViaQueue: [queueSize: ${state.playQueue.size()}]")
	if (state.playQueue.size() == 0) { return }
	state.recoveryVolume = device.currentValue("volume")
	state.recoverySource = device.currentValue("mediaInputSource")
	state.playingNotification = true
	playViaQueue()
}

def playViaQueue() {
	def logData = [:]
	if (state.playQueue.size() == 0) {
		resumePlayer()
		logData << [status: "resumingPlayer", reason: "Zero Queue"]
	} else {
		def playData = state.playQueue.get(0)
		state.playQueue.remove(0)

		runInMillis(100, setVolume, [data:playData.requestVolume])
	
		runInMillis(400, execPlay, [data: playData])
		runIn(playData.duration, resumePlayer)
		runIn(30, kickStartQueue)
		logData << [playData: playData, recoveryVolume: recVolume]
	}
	logDebug("playViaQueue: ${logData}")
}

def execPlay(data) {
	if (deviceIp) {
		sendUpnpCmd("SetAVTransportURI",
					 [InstanceID: 0,
					  CurrentURI: data.trackUri,
					  CurrentURIMetaData: ""])
		pauseExecution(300)
		sendUpnpCmd("Play",
					 ["InstanceID" :0,
					  "Speed": "1"])
	} else {
		sendCommand("playTrack", data.trackUri)
	}		
}

def resumePlayer() {
	//	should be able to recover data here.  At least, recover the current value of the inputSource
	def logData = [:]
	if (state.playQueue.size() > 0) {
		logData << [status: "aborted", reason: "playQueue not 0"]
		playViaQueue()
	} else {
		state.playingNotification = false
		setVolume(state.recoveryVolume)
		def source = state.recoverySource
		if (source != "n/a") {
			setInputSource(source)
		}
	}
	logDebug("resumePlayer: ${logData}")
}

def kickStartQueue() {
	logInfo("kickStartQueue: [size: ${state.playQueue.size()}]")
	if (state.playQueue.size() > 0) {
		resumePlayer()
	} else {
		state.playingNotification = false
	}
}

def clearQueue() {
	logDebug("clearQueue")
	state.playQueue = []
	state.playingNotification = false
}

private sendUpnpCmd(String action, Map body){
	logDebug("sendUpnpCmd: upnpAction = ${action}, upnpBody = ${body}")
	def host = "${deviceIp}:9197"
	def hubCmd = new hubitat.device.HubSoapAction(
		path:	"/upnp/control/AVTransport1",
		urn:	 "urn:schemas-upnp-org:service:AVTransport:1",
		action:  action,
		body:	body,
		headers: [Host: host,
				  CONNECTION: "close"]
	)
	sendHubCommand(hubCmd)
}

def upnpParse(resp) {
	resp = parseLanMessage(resp)
	if (resp.status != 200) {
		logWarn("upnpParse: [status: failed, data: ${resp}]")
	}
}

//	Send parse to appropriate method for UPNP or WS!
def parse(resp) {
	if (resp.toString().contains("mac:")) {
		upnpParse(resp)
	} else {
		parseWs(resp)
	}
}


/*	===== Sample Audio Notification URIs =====
[title: "Bell 1", uri: "http://s3.amazonaws.com/smartapp-media/sonos/bell1.mp3", duration: "10"]
[title: "Dogs Barking", uri: "http://s3.amazonaws.com/smartapp-media/sonos/dogs.mp3", duration: "10"]
[title: "Fire Alarm", uri: "http://s3.amazonaws.com/smartapp-media/sonos/alarm.mp3", duration: "17"]
[title: "The mail has arrived",uri: "http://s3.amazonaws.com/smartapp-media/sonos/the+mail+has+arrived.mp3", duration: "1"]
[title: "A door opened", uri: "http://s3.amazonaws.com/smartapp-media/sonos/a+door+opened.mp3", duration: "1"]
[title: "There is motion", uri: "http://s3.amazonaws.com/smartapp-media/sonos/there+is+motion.mp3", duration: "1"]
[title: "Someone is arriving", uri: "http://s3.amazonaws.com/smartapp-media/sonos/someone+is+arriving.mp3", duration: "1"]
=====	Some working Streaming Stations =====
[title:"Cafe del Mar", uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[title:"UT-KUTX", uri: "https://kut.streamguys1.com/kutx-web", duration: 0]
[title:"89.7 FM Perth", uri: "https://ice8.securenetsystems.net/897FM", duration: 0]
[title:"Euro1", uri:"https://streams.radio.co/se1a320b47/listen", duration: 0]
[title:"Easy Hits Florida", uri:"http://airspectrum.cdnstream1.com:8114/1648_128", duration: 0]
[title:"Austin Blues", uri:"http://158.69.131.71:8036/stream/1/", duration: 0]
*/

