library (
	name: "SmartThingsSimulator",
	namespace: "replica",
	author: "Dave Gutheinz",
	description: "ST Replica Dishwasher Simulator",
	category: "utilities",
	documentationLink: ""
)

def xxsimulateSmartDeviceDescription(String deviceId) {
	Map description = [
		name:"[dishwasher] Samsung", 
		label:"Dishwasher", 
		components:[
			[
				"id":"main","label":"main",
				"capabilities":[
					["id":"execute","version":1],
					["id":"ocf","version":1],
					["id":"powerConsumptionReport","version":1],
					["id":"refresh","version":1],
					["id":"remoteControlStatus","version":1],
					["id":"dishwasherOperatingState","version":1],
					["id":"custom.dishwasherOperatingProgress","version":1],
					["id":"samsungce.driverVersion","version":1]
				], 
				categories:[[name:"Dishwasher", categoryType:"manufacturer"]]
		]]]

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartDescriptionHandler(replicaDevice, description); }
	description = null
}

def xxsimulateSmartDeviceStatus(String deviceId) {
	Map status = [
	components:[
		main:[
			ocf:[:], 
			powerConsumptionReport:[powerConsumption:[value:null]],
			remoteControlStatus:[remoteControlEnabled:[value:true]],
			"samsungce.driverVersion":[versionNumber:[value:21012901]],
			refresh:[:],
			dishwasherOperatingState:[
				completionTime:[value:"2023-01-29T14:04:57Z"],
				machineState:[value:"stop"],
				supportedMachineStates:[value:null],
				dishwasherJobState:[value:"unknown",]],
			execute:[:],
			"custom.dishwasherOperatingProgress":[dishwasherOperatingProgress:[value:"none"]]]]]

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartStatusHandler(replicaDevice, deviceId, status); }
	status = null
}




def simulateSmartDeviceDescription(String deviceId) {
	Map description = [
		name:"[dishwasher] Samsung", 
		label:"Dishwasher", 
		components:[
			[
				id:"main", label:"main", capabilities:[
					[id:"execute", version:1], 
					[id:"ocf", version:1], 
					[id:"powerConsumptionReport", version:1], 
					[id:"refresh", version:1], 
					[id:"remoteControlStatus", version:1], 
					[id:"switch", version:1], 
					[id:"dishwasherOperatingState", version:1], 
					[id:"custom.disabledCapabilities", version:1], 
					[id:"custom.dishwasherOperatingProgress", version:1], 
					[id:"custom.dishwasherOperatingPercentage", version:1], 
					[id:"custom.dishwasherDelayStartTime", version:1], 
					[id:"custom.supportedOptions", version:1], 
					[id:"custom.waterFilter", version:1], 
					[id:"samsungce.deviceIdentification", version:1], 
					[id:"samsungce.dishwasherJobState", version:1], 
					[id:"samsungce.dishwasherWashingCourse", version:1], 
					[id:"samsungce.dishwasherWashingCourseDetails", version:1], 
					[id:"samsungce.dishwasherOperation", version:1], 
					[id:"samsungce.dishwasherWashingOptions", version:1], 
					[id:"samsungce.driverVersion", version:1], 
					[id:"samsungce.softwareUpdate", version:1], 
					[id:"samsungce.kidsLock", version:1], 
					[id:"sec.diagnosticsInformation", version:1]
				], 
				categories:[[name:Dishwasher, categoryType:manufacturer]]
		]]]
	getReplicaDevices(deviceId)?.each { replicaDevice -> smartDescriptionHandler(replicaDevice, description); }
	description = null
}

def simulateSmartDeviceStatus(String deviceId) {
	Map status = [
	components:[
		main:[
			"samsungce.dishwasherWashingCourse":[
				"washingCourse":[value:"auto"], 
				"supportedCourses":[value:["auto", "normal","selfClean"]]], 
			powerConsumptionReport:[:], 
			refresh:[:], 
			dishwasherOperatingState:[
				completionTime:[value:"2022-08-10T01:18:37Z"], 
				machineState:[value:"stop"], 
				supportedMachineStates:[value:null], 
				dishwasherJobState:[value:"unknown"]], 
			"samsungce.dishwasherWashingCourseDetails":[
				predefinedCourses:[value:[
					[courseName:"auto"],
					[courseName:"normal"],
					[courseName:"heavy"]]],
				waterUsageMax:[value:5],
				energyUsageMax:[value:5]], 
			"samsungce.dishwasherWashingOptions":[
				dryPlus:[value:null], 
				stormWash:[value:null], 
				hotAirDry:[value:null]], 
			execute:[:], 
			"samsungce.deviceIdentification":[:], 
			"custom.dishwasherOperatingProgress":[dishwasherOperatingProgress:[value:"none"]], 
			switch:[switch:[value:"off"]], 
			"custom.dishwasherOperatingPercentage":[dishwasherOperatingPercentage:[value:100]], 
			ocf:[:],
			remoteControlStatus:[remoteControlEnabled:[value:false]], 
			"custom.supportedOptions":[
				referenceTable:[value:null], 
				supportedCourses:[value:[82, 83, 84, 85, 86, 87, 88]]], 
			"custom.dishwasherDelayStartTime":[dishwasherDelayStartTime:[value:"00:00:00"]], 
			"custom.disabledCapabilities":[
				disabledCapabilities:[value:[
					"custom.dishwasherOperatingProgress",
					"custom.dishwasherOperatingPercentage",
					"custom.dishwasherDelayStartTime",
					"samsungce.dishwasherWashingCourse",
					"samsungce.dishwasherWashingCourseDetails",
					"samsungce.dishwasherWashingOptions",
					"dishwasherOperatingState",
					"remoteControlStatus",
					"sec.diagnosticsInformation",
					"custom.waterFilter"]]], 
			"samsungce.driverVersion":[:], 
			"samsungce.softwareUpdate":[:], 
			"sec.diagnosticsInformation":[:],
			"samsungce.dishwasherOperation":[
				supportedOperatingState:[value:null], 
				operatingState:[value:"ready"], 
				operationTime:[value:null], 
				remainingTime:[value:136.0, unit:"min"], 
				timeLeftToStart:[value:0.0, unit:"min"]], 
			"custom.waterFilter":[:],
			"samsungce.dishwasherJobState":[
				scheduledJobs:[
					value:[
						[jobName:washing, timeInSec:3530], 
						[jobName:rinsing, timeInSec:770], 
						[jobName:drying, timeInSec:1400]]], 
				dishwasherJobState:[value:"none"]], 
			"samsungce.kidsLock":[lockState:[value:"unlocked"]]]]]

	getReplicaDevices(deviceId)?.each { replicaDevice -> smartStatusHandler(replicaDevice, deviceId, status); }
	status = null
}

/*	===== HubiThings Replica App Changes =====
The below changes work with both live and development devices.
Issue Solved: Samsung appliances implement the capabilities based on model.
My method:	Appliance driver that is model independent using a superset of commands and attributes in the definition. 
1.	Replica Commands and Triggers.  Develop based on the superset of capabilities.
2.	Device Commands.  Normal except that where two capabilities handle the same function, design a single command for both with a priority for the samsungce.CAPABILITIES (these are the later ones for the more capable devices).
3.	Device attributes: For capabilities handling the same (essential) state, combine the attributes into a single attribute to absolutely avoid user confusion on similar states.
4.	deviceConfigure.  This new function will use the Description data and the Status data from the app to generate the deviceCapabilities list.
	1.	status.disabledCapabilities (if it esists) will filter out the description capabilities not used in the device.

//	===== new code =====
def developer() { return true }
//	Remove "//" from below.  library catches the # as live code.
//#include replica.SmartThingsSimulator
//	===== end new code =====

Map getSmartDeviceDescription(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceDescription(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceDescription($deviceId)'"
    	Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}", deviceId: deviceId, method: "getSmartDeviceDescription" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
		return response
//	===== new code =====
	}
//	===== end new code =====
}

Map getSmartDeviceStatus(String deviceId) {
//	===== new code =====
	if (developer() == true && getReplicaDevices(deviceId)[0].toString().contains("develop")) {
		simulateSmartDeviceStatus(deviceId)
	} else {
//	===== end new code =====
	    logDebug "${app.getLabel()} executing 'getSmartDeviceStatus($deviceId)'"
	    Map response = [statusCode:iHttpError]
		Map data = [ uri: sURI, path: "/devices/${deviceId}/status", deviceId: deviceId, method: "getSmartDeviceStatus" ]
		response.statusCode = asyncHttpGet("asyncHttpGetCallback", data).statusCode
	    return response
//	===== new code =====
	}
//	===== end new code =====
}

*/