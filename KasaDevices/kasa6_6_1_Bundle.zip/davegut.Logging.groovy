library (
	name: "Logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging Methods",
	category: "utilities",
	documentationLink: ""
)

//	Logging during development
def listAttributes(trace = false) {
	def attrs = device.getSupportedAttributes()
	def attrList = [:]
	attrs.each {
		def val = device.currentValue("${it}")
		attrList << ["${it}": val]
	}
	if (trace == true) {
		logTrace("Attributes: ${attrList}")
	} else {
		logDebug("Attributes: ${attrList}")
	}
}

def logTrace(msg){
	log.trace "${device.displayName} ${getDataValue("driverVersion")}: ${msg}"
}

def logInfo(msg) { 
	if (infoLog == true) {
		log.info "${device.displayName} ${getDataValue("driverVersion")}: ${msg}"
	}
}

def debugLogOff() {
	if (debug == true) {
		device.updateSetting("debug", [type:"bool", value: false])
	} else if (debugLog == true) {
		device.updateSetting("debugLog", [type:"bool", value: false])
	}
	logInfo("Debug logging is false.")
}

def logDebug(msg) {
	if (debug == true || debugLog == true) {
		log.debug "${device.displayName} ${getDataValue("driverVersion")}: ${msg}"
	}
}

def logWarn(msg) { log.warn "${device.displayName} ${getDataValue("driverVersion")}: ${msg}" }
