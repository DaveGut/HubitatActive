library (
	name: "lib_tpLink_parents",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to Parent Device Drivers",
	category: "utilities",
	documentationLink: ""
)

def setChildPoll() {
	if (childPollInt.contains("sec")) {
		def pollInterval = childPollInt.replace(" sec", "").toInteger()
		schedule("3/${pollInterval} * * * * ?", "pollChildren")
	} else if (childPollInt == "1 min") {
		runEvery1Minute(pollChildren)
	} else {
		runEvery5Minutes(pollChildren)
	}
	return childPollInt
}

def pollChildren() {
	Map cmdBody = [
		method: "get_child_device_list"
	]
	asyncPassthrough(cmdBody, "pollChildren", "childPollParse")
}
def childPollParse(resp, data) {
	def childData = parseData(resp).cmdResp.result.child_device_list
	def children = getChildDevices()
	children.each { child ->
		child.devicePollParse(childData)
	}
}

def distTriggerLog(resp, data) {
	def triggerData = parseData(resp)
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

def installChildDevices() {
	Map logData = [:]
	def respData = syncPassthrough([method: "get_child_device_list"])
	def children = respData.result.child_device_list
	children.each {
		String childDni = it.mac
		logData << [childDni: childDni]
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			logDebug("installChildDevices: [${alias}: device already installed]")
		} else {
			String model = it.model
			String category = it.category
			String driver = getDriverId(category, model)
			String deviceId = it.device_id
			Map instData = [model: model, category: category, driver: driver] 
			try {
				addChildDevice("davegut", driver, childDni, 
							   [label: alias, name: model, deviceId : deviceId])
				logInfo("installChildDevices: [${alias}: Installed, data: ${instData}]")
			} catch (e) {
				logWarn("installChildDevices: [${alias}: FAILED, data ${instData}, error: ${e}]")
			}
		}
	}
}





//command "TEST"
def xxTEST() {createPollList()}
def createPollList() {
	def children = getChildDevices()
	log.info children
	List requests = []
	children.each { child ->
		Map cmdBody = [
		method: "control_child",
		params: [
			device_id: child.getDataValue("deviceId"),
			requestData: [
				method: "get_device_info"
			]]]
//log.warn syncPassthrough(cmdBody)
		requests << cmdBody
	}
	log.debug createMultiCmd(requests)
//	asyncPassthrough(createMultiCmd(requests), "TEST", "testParse")
	log.trace syncPassthrough(createMultiCmd(requests))
}

def xyTEST() {
	def command = [
		method:"multipleRequest", 
		params:[
			requests:[
				[method:"control_child", 
				 params:[
					 device_id:"802E2AA5F05058477DAE4F4F76CF2D9020C234A6",
					 requestData:[method:"get_device_info"]]], 
				[method:"control_child", 
				 params:[
					 device_id:"802ECD75CFC5EF371DCB6CB117CD38E420C25A00", 
					 requestData:[method:get_device_info]]]]]]
	
	log.trace syncPassthrough(command)
}

def TEST() {
	def command = [
		method: "control_child",
//		method: "multipleRequests",
		params:[
			method: "multipleRequests",
//			method: "control_child",
			params: [requests: [
				[params:[device_id:"802E2AA5F05058477DAE4F4F76CF2D9020C234A6",
				 requestData:[method:"get_device_info"]]],
				[params:[device_id:"802ECD75CFC5EF371DCB6CB117CD38E420C25A00",
				 requestData:[method:"get_device_info"]]]]]]]
	
	log.trace syncPassthrough(command)
}





def testParse(resp, data) {
	log.warn parseData(resp)
}



def childDeviceInfo() {
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "play_alarm"]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "playAlarmConfig", "alarmParse")
	

	
	
	
	
/*	
	
		Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]

	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "play_alarm"]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "playAlarmConfig", "alarmParse")
	
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	
	
	
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_device_running_info"
//				method: "get_trigger_logs",
//				params: [page_size: 5,"start_id": 0]
			]
		]
*/	
}


