library (
	name: "lib_tpLink_parents",
	namespace: "davegut",
	author: "Compied by Dave Gutheinz",
	description: "Method common to Parent Device Drivers",
	category: "utilities",
	documentationLink: ""
)

def setChildPoll() {
	if (childPollInt.contains("sec")) {
		def pollInterval = childPollInt.replace(" sec", "").toInteger()
		schedule("3/${pollInterval} * * * * ?", "pollChildren")
	} else if (childPollInt == "1 min") {
		runEvery1Minute(pollChildren)
	} else {
		runEvery5Minutes(pollChildren)
	}
	return childPollInt
}

def pollChildren() {
	Map cmdBody = [
		method: "get_child_device_list"
	]
	asyncPassthrough(cmdBody, "pollChildren", "childPollParse")
}
def childPollParse(resp, data) {
	def childData = parseData(resp).cmdResp.result.child_device_list
	def children = getChildDevices()
	children.each { child ->
		child.devicePollParse(childData)
	}
}

def distTriggerLog(resp, data) {
	def triggerData = parseData(resp)
	def child = getChildDevice(data.data)
	child.parseTriggerLog(triggerData)
}

def installChildDevices() {
	Map logData = [:]
	def respData = syncPassthrough([method: "get_child_device_list"])
	def children = respData.result.child_device_list
	children.each {
		String childDni = it.mac
		logData << [childDni: childDni]
		def isChild = getChildDevice(childDni)
		byte[] plainBytes = it.nickname.decodeBase64()
		String alias = new String(plainBytes)
		if (isChild) {
			logDebug("installChildDevices: [${alias}: device already installed]")
		} else {
			String model = it.model
			String category = it.category
			String driver = getDriverId(category, model)
			String deviceId = it.device_id
			Map instData = [model: model, category: category, driver: driver] 
			try {
				addChildDevice("davegut", driver, childDni, 
							   [label: alias, name: model, deviceId : deviceId])
				logInfo("installChildDevices: [${alias}: Installed, data: ${instData}]")
			} catch (e) {
				logWarn("installChildDevices: [${alias}: FAILED, data ${instData}, error: ${e}]")
			}
		}
	}
}
