/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
//def type() { return "tpLink_plug_em" }
//def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def type() {return "kasaSmart_plug_em" }
def gitPath() { return "DaveGut/HubitatActive/master/KasaDevices/DeviceDrivers/" }

metadata {
	definition (name: "kasaSmart_plug_em", namespace: nameSpace(), author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		attribute "commsError", "string"
		capability "EnergyMeter"
		capability "PowerMeter"
		attribute "energyThisMonth", "number"
	}
	preferences {
		commonPreferences()
		plugSwitchPreferences()
		input ("powerProtect", "bool", title: "Enable Power Protection", defaultValue: false)
		input ("pwrProtectWatts", "NUMBER", title: "Power Protection Watts (Max 1660)", 
			   defaultValue: 1000)
		securityPreferences()
	}
}

def installed() { 
	runIn(5, updated)
}

def updated() { commonUpdated() }

def delayedUpdates() {
	Map logData = [setAutoOff: setAutoOff()]
	logData << [setDefaultState: setDefaultState()]
	logData << [setPowerProtect: setPowerProtect()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
}

def setPowerProtect() {
	Map logData = [:]
	if (pwrProtectWatts > 1660) {
		logWarn("setPowerProtect: entered watts exceed 1660.  Aborting Power Protect Setup.")
		device.updateSetting("pwrProtectWatts", [type: "number", value: 1000])
		logData << [FAILED: "Invalid User Entry"]
	} else {
		List requests = [[method: "set_protection_power",
						  params: [protection_power: pwrProtectWatts,
								   enabled: powerProtect]]]
		requests << [method: "get_protection_power"]
		def devData = syncPassthrough(createMultiCmd(requests))
		def data = devData.result.responses.find { it.method == "get_protection_power" }.result
		device.updateSetting("pwrProtectWatts", [type: "number", value: data.protection_power])
		device.updateSetting("powerProtect", [type: "bool", value: data.enabled])
		logData << [powerProtect: data.enabled, pwrProtectWatts: data.protection_power]
	}
	return logData
}

def deviceParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp.result
		if (devData.responses) {
			devData = devData.responses.find{it.method == "get_device_info"}.result
		}
		logDebug("deviceParse: ${devData}")
		def onOff = "off"
		if (devData.device_on == true) { onOff = "on" }
		updateAttr("switch", onOff)
	}
	runIn(5, energyPoll)
}

def energyPoll() {
	asyncPassthrough([method: "get_energy_usage"], "energyPoll", "parseEnergyPoll")
}
def parseEnergyPoll(resp, data=null) {
	def devData = parseData(resp)
	if(devData.status == "OK") {
		devData = devData.cmdResp.result
		logDebug("parseEnergyPoll: [devData: ${devData}, data: ${data}]")
		updateAttr("power", devData.current_power)
		updateAttr("energy", devData.today_energy/1000)
		updateAttr("energyThisMonth", (devData.month_energy/1000).toInteger())
	}
}

#include davegut.lib_tpLink_CapSwitch
#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.Logging
