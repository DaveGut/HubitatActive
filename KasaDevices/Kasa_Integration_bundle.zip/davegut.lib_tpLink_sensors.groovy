library (
	name: "lib_tpLink_sensors",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Tapo Sensor Methods",
	category: "utilities",
	documentationLink: ""
)

def getTriggerLog() {
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_trigger_logs",
				params: [page_size: 5,"start_id": 0]
			]
		]
	]
	parent.asyncPassthrough(cmdBody, device.getDeviceNetworkId(), "distTriggerLog")
}

command "getDeveloperData"
def getDeveloperData() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	Date date = new Date()
	Map devData = [
		currentTime: date.toString(),
		name: device.getName(),
		status: device.getStatus(),
		dataValues: device.getData(),
		attributes: attrs,
		devInfo: getDeviceInfo(),
		compList: getDeviceComponents()
	]
	logWarn("DEVELOPER DATA: ${devData}")
}

def getDeviceComponents() {
	Map logData = [:]
	Map cmdBody = [
		device_id: getDataValue("deviceId"),
		method: "get_child_device_component_list"
	]
	def compList = parent.syncPassthrough(cmdBody)
	if (compList == "ERROR") {
		logWarn("getDeviceComponents: [ERROR: Error in Sysn Comms]")
	}
	return compList
}

def getDeviceInfo() {
	logDebug("getChildDeviceInfo")
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "get_device_info"
			]
		]
	]
	def devInfo = parent.syncPassthrough(cmdBody)
	if (devInfo == "ERROR") {
		logWarn("getDeviceInfo: [ERROR: Error in Sysn Comms]")
	}
	return devInfo
}

def updateAttr(attr, value) {
	if (device.currentValue(attr) != value) {
		sendEvent(name: attr, value: value)
	}
}

/*	Currently disabled.  Future.
attribute "lowBattery", "string"
attribute "status", "string"
def deviceRefreshParse(childData, data=null) {
	try {
		def devData = childData.find {it.mac = device.getDeviceNetworkId()}
		logDebug("deviceInfoParse: ${devData}")
		updateAttr("lowBattery", devData.atLowBattery)
		updateAttr("status", status)
	} catch (error) {
		logWarn("deviceRefreshParse: Failed to capture deviceData from ChildData")
	}
}
def setReportInterval() {
	def repInt = sensorReportInt.toInteger()
	Map cmdBody = [
		method: "control_child",
		params: [
			device_id: getDataValue("deviceId"),
			requestData: [
				method: "multipleRequest",
				params: [
					requests: [
						[method: "set_device_info",
						 params: [report_interval: repInt]],
						[method: "get_device_info"]
					]]]]]
	def devInfo = parent.syncPassthrough(cmdBody)
	devInfo = devInfo.result.responseData.result.responses.find{it.method == "get_device_info"}.result
	updateAttr("reportInterval", devInfo.report_interval)
	return buttonReportInt
}
*/
