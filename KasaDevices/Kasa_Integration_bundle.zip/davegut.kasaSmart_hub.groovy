/*	TP-Link SMART API / PROTOCOL DRIVER SERIES for plugs, switches, bulbs, hubs and Hub-connected devices.
		Copyright Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
=================================================================================================*/
//def type() { return "tpLink_hub" }
//def gitPath() { return "DaveGut/tpLink_Hubitat/main/Drivers/" }
def type() {return "kasaSmart_hub" }
def gitPath() { return "DaveGut/HubitatActive/master/KasaDevices/DeviceDrivers/" }

metadata {
//	definition (name: "tpLink_hub", namespace: "davegut", author: "Dave Gutheinz", 
	definition (name: "kasaSmart_hub", namespace: "${nameSpace()}", author: "Dave Gutheinz", 
				importUrl: "https://raw.githubusercontent.com/${gitPath()}${type()}.groovy")
	{
		capability "Switch"		//	Turns on or off.  easier Alexa/google integration
		command "configureAlarm", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		command "playAlarmConfig", [
			[name: "Alarm Type", constraints: alarmTypes(), type: "ENUM"],
			[name: "Volume", constraints: ["low", "normal", "high"], type: "ENUM"],
			[name: "Duration", type: "NUMBER"]
		]
		attribute "alarmConfig", "JSON_OBJECT"
		attribute "commsError", "string"
	}
	preferences {
		input ("childPollInt", "enum", title: "CHILD DEVICE Poll interval (seconds)",
			   options: ["5 sec", "10 sec", "15 sec", "30 sec", "1 min", "5 min"], 
			   defaultValue: "30 sec")
		commonPreferences()
		securityPreferences()
	}
}

def installed() { 
	if (type().contains("kasaSmart")) {
		updateDataValue("deviceIp", getDataValue("deviceIP"))
		removeDataValue("deviceIP")
	}
	runIn(5, updated)
}

def updated() { commonUpdated() }
def delayedUpdates() {
	Map logData = [alarmConfig: getAlarmConfig()]
	logData << [childPoll: setChildPoll()]
	logData << [common: commonDelayedUpdates()]
	logInfo("delayedUpdates: ${logData}")
	runIn(5, installChildDevices)
}

def getAlarmConfig() {
	def cmdResp = syncPassthrough([method: "get_alarm_configure"])
	def alarmData = cmdResp.result
	updateAttr("alarmConfig", alarmData)
	return alarmData
}

def on() {
	logDebug("on: play default alarm configuraiton")
	List requests = [[method: "play_alarm"]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "on", "alarmParse")
}

def off() {
	logDebug("off: stop alarm")
	List requests =[[method: "stop_alarm"]]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "off", "deviceParse")
}

def configureAlarm(alarmType, volume, duration=30) {
	logDebug("configureAlarm: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "configureAlarm", "alarmParse")
}

def playAlarmConfig(alarmType, volume, duration=30) {
	logDebug("playAlarmConfig: [alarmType: ${alarmType}, volume: ${volume}, duration: ${duration}]")
	if (duration < 0) { duration = -duration }
	else if (duration == 0) { duration = 30 }
	List requests = [
		[method: "set_alarm_configure",
		 params: [custom: 0,
				  type: "${alarmType}",
				  volume: "${volume}",
				  duration: duration
				 ]]]
	requests << [method: "get_alarm_configure"]
	requests << [method: "play_alarm"]
	requests << [method: "get_device_info"]
	asyncPassthrough(createMultiCmd(requests), "playAlarmConfig", "alarmParse")
}

def alarmParse(resp, data) {
	def  devData = parseData(resp).cmdResp.result
	logDebug("alarmParse: ${devData}")
	if (devData && devData.responses) {
		def alarmData = devData.responses.find{it.method == "get_alarm_configure"}.result
		updateAttr("alarmConfig", alarmData)
		def devInfo = devData.responses.find{it.method == "get_device_info"}
		if (devInfo) {
			def inAlarm = devInfo.result.in_alarm
			def onOff = "off"
			if (inAlarm == true) {
				onOff = "on"
				runIn(alarmData.duration + 1, refresh)
			}
			updateAttr("switch", onOff)
		}
	} else {
		updateAttr("alarmConfig", devData)
	}
}

def alarmTypes() {
	 return [
		 "Doorbell Ring 1", "Doorbell Ring 2", "Doorbell Ring 3", "Doorbell Ring 4",
		 "Doorbell Ring 5", "Doorbell Ring 6", "Doorbell Ring 7", "Doorbell Ring 8",
		 "Doorbell Ring 9", "Doorbell Ring 10", "Phone Ring", "Alarm 1", "Alarm 2",
		 "Alarm 3", "Alarm 4", "Alarm 5", "Dripping Tap", "Connection 1", "Connection 2"
	 ] 
}

def deviceParse(resp, data=null) {
	def cmdResp = parseData(resp)
	if (cmdResp.status == "OK") {
		def devData = cmdResp.cmdResp.result
		if (devData.responses) {
			devData = devData.responses.find{it.method == "get_device_info"}.result
		}
		logDebug("deviceParse: ${devData}")
		def onOff = "off"
		if (devData.in_alarm == true) { 
			onOff = "on" 
			runIn(30, refresh)
		}
		updateAttr("switch", onOff)
	}
}

//	===== Install Methods Unique to Hub =====
def getDriverId(category, model) {
	def driver = "tapoHub-NewType"
	switch(category) {
		case "subg.trigger.contact-sensor":
			driver = "tpLink_hub_contact"
			break
		case "subg.trigger.motion-sensor":
			driver = "tpLink_hub_motion"
			break
		case "subg.trigger.button":
			if (model == "S200B") {
				driver = "tpLink_hub_button"
			}
			//	Note: Installing only sensor version for now.  Need data to install D version.
			break
		case "subg.trigger.temp-hmdt-sensor":
			driver = "tpLink_hub_tempHumidity"
			break
		case "subg.trigger":
		case "subg.trigger.water-leak-sensor":
		case "subg.plugswitch":
		case "subg.plugswitch.plug":
		case "subg.plugswitch.switch":
		case "subg.trv":
		default:
			driver = "tapoHub-NewType"
	}
	return driver
}

#include davegut.lib_tpLink_common
#include davegut.lib_tpLink_comms
#include davegut.lib_tpLink_security
#include davegut.lib_tpLink_parents
#include davegut.Logging
