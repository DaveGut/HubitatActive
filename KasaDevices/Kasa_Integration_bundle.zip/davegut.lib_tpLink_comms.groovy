library (
	name: "lib_tpLink_comms",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Tapo Communications",
	category: "utilities",
	documentationLink: ""
)
import org.json.JSONObject
import groovy.json.JsonOutput
import groovy.json.JsonBuilder
import groovy.json.JsonSlurper

def createMultiCmd(requests) {
	Map cmdBody = [
		method: "multipleRequest",
		params: [requests: requests]]
	return cmdBody
}

def asyncPassthrough(cmdBody, method, action) {
	if (devIp == null) { devIp = getDataValue("deviceIP") }	//	used for Kasa Compatibility
	Map cmdData = [cmdBody: cmdBody, method: method, action: action]
	state.lastCmd = cmdData
	logDebug("asyncPassthrough: ${cmdData}")
	def uri = "http://${getDataValue("deviceIP")}/app?token=${getDataValue("deviceToken")}"
	Map reqBody = createReqBody(cmdBody)
	asyncPost(uri, reqBody, action, getDataValue("deviceCookie"), method)
}

def syncPassthrough(cmdBody) {
	if (devIp == null) { devIp = getDataValue("deviceIP") }	//	used for Kasa Compatibility
	Map logData = [cmdBody: cmdBody]
	def uri = "http://${getDataValue("deviceIP")}/app?token=${getDataValue("deviceToken")}"
	Map reqBody = createReqBody(cmdBody)
	def resp = syncPost(uri, reqBody, getDataValue("deviceCookie"))
	def cmdResp = "ERROR"
	if (resp.status == "OK") {
		try {
			cmdResp = new JsonSlurper().parseText(decrypt(resp.resp.data.result.response))
			logData << [status: "OK"]
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
	} else {
		logData << [status: "postJsonError", postJsonData: resp]
	}
	if (logData.status == "OK") {
		logDebug("syncPassthrough: ${logData}")
	} else {
		logWarn("syncPassthrough: ${logData}")
	}
	return cmdResp
}

def createReqBody(cmdBody) {
	def cmdStr = JsonOutput.toJson(cmdBody).toString()
	Map reqBody = [method: "securePassthrough",
				   params: [request: encrypt(cmdStr)]]
	return reqBody
}

//	===== Sync comms for device update =====
def syncPost(uri, reqBody, cookie=null) {
	def reqParams = [
		uri: uri,
		headers: [
			Cookie: cookie
		],
		body : new JsonBuilder(reqBody).toString()
	]
	logDebug("syncPost: [cmdParams: ${reqParams}]")
	Map respData = [:]
	try {
		httpPostJson(reqParams) {resp ->
			if (resp.status == 200 && resp.data.error_code == 0) {
				respData << [status: "OK", resp: resp]
			} else {
				respData << [status: "lanDataError", respStatus: resp.status, 
					errorCode: resp.data.error_code]
			}
		}
	} catch (err) {
		respData << [status: "HTTP Failed", data: err]
	}
	return respData
}

def asyncPost(uri, reqBody, parseMethod, cookie=null, reqData=null) {
	Map logData = [:]
	def reqParams = [
		uri: uri,
		requestContentType: 'application/json',
		contentType: 'application/json',
		headers: [
			Cookie: cookie
		],
		timeout: 4,
		body : new groovy.json.JsonBuilder(reqBody).toString()
	]
	try {
		asynchttpPost(parseMethod, reqParams, [data: reqData])
		logData << [status: "OK"]
	} catch (e) {
		logData << [status: e, reqParams: reqParams]
	}
	if (logData.status == "OK") {
		logDebug("asyncPost: ${logData}")
	} else {
		logWarn("asyncPost: ${logData}")
		handleCommsError()
	}
}

def parseData(resp) {
	def logData = [:]
	if (resp.status == 200 && resp.json.error_code == 0) {
		def cmdResp
		try {
			cmdResp = new JsonSlurper().parseText(decrypt(resp.json.result.response))
			setCommsError(false)
		} catch (err) {
			logData << [status: "cryptoError", error: "Error decrypting response", data: err]
		}
		if (cmdResp != null && cmdResp.error_code == 0) {
			logData << [status: "OK", cmdResp: cmdResp]
		} else {
			logData << [status: "deviceDataError", cmdResp: cmdResp]
		}
	} else {
		logData << [status: "lanDataError"]
	}
	if (logData.status == "OK") {
		logDebug("parseData: ${logData}")
	} else {
		logWarn("parseData: ${logData}")
		handleCommsError()
	}
	return logData
}

def handleCommsError() {
	Map logData = [:]
	if (state.lastCommand != "") {
		def count = state.errorCount + 1
		state.errorCount = count
		def cmdData = new JSONObject(state.lastCmd)
		def cmdBody = parseJson(cmdData.cmdBody.toString())
		logData << [count: count, command: cmdData]
		switch (count) {
			case 1:
				asyncPassthrough(cmdBody, cmdData.method, cmdData.action)
				logData << [status: "commandRetry"]
				logDebug("handleCommsError: ${logData}")
				break
			case 2:
				logData << [deviceLogin: deviceLogin()]
				Map data = [cmdBody: cmdBody, method: cmdData.method, action:cmdData.action]
				runIn(2, delayedPassThrough, [data:data])
				logData << [status: "newLogin and commandRetry"]
				logWarn("handleCommsError: ${logData}")
				break
			case 3:
				logData << [setCommsError: setCommsError(true), status: "retriesDisabled"]
				logError("handleCommsError: ${logData}")
				break
			default:
				break
		}
	}
}

def delayedPassThrough(data) {
	asyncPassthrough(data.cmdBody, data.method, data.action)
}

def setCommsError(status) {
	if (!status) {
		updateAttr("commsError", false)
		state.errorCount = 0
	} else {
		updateAttr("commsError", true)
		return "commsErrorSet"
	}
}
