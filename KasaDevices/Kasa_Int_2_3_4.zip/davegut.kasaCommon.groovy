library (
	name: "kasaCommon",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Kasa Device Common Methods",
	category: "utilities",
	documentationLink: ""
)

def nameSpace() { return "davegut" }

def installCommon() {
	pauseExecution(3000)
	def instStatus = [:]
	if (getDataValue("deviceIP") == "CLOUD") {
		sendEvent(name: "connection", value: "CLOUD")
		device.updateSetting("useCloud", [type:"bool", value: true])
		instStatus << [useCloud: true, connection: "CLOUD"]
	} else {
		sendEvent(name: "connection", value: "LAN")
		device.updateSetting("useCloud", [type:"bool", value: false])
		instStatus << [useCloud: false, connection: "LAN"]
	}

	sendEvent(name: "commsError", value: "false")
	state.errorCount = 0
	state.pollInterval = "30 minutes"
	runIn(1, updated)
	return instStatus
}

def updateCommon() {
	def updStatus = [:]
	if (rebootDev) {
		updStatus << [rebootDev: rebootDevice()]
		return updStatus
	}
	unschedule()
	updStatus << [bind: bindUnbind()]
	if (nameSync != "none") {
		updStatus << [nameSync: syncName()]
	}
	if (logEnable) { runIn(1800, debugLogOff) }
	updStatus << [textEnable: textEnable, logEnable: logEnable]
	state.errorCount = 0
	sendEvent(name: "commsError", value: "false")
	def pollInterval = state.pollInterval
	if (pollInterval == null) { pollInterval = "30 minutes" }
	updStatus << [pollInterval: setPollInterval(pollInterval)]
	state.remove("UPDATE_AVAILABLE")
	state.remove("releaseNotes")
	removeDataValue("driverVersion")
	if (emFunction) {
		schedule("10 0 0 * * ?", getEnergyThisMonth)
		schedule("15 2 0 1 * ?", getEnergyLastMonth)
		state.getEnergy = "This Month"
		updStatus << [emFunction: "scheduled"]
	}
	runIn(5, listAttributes)
	return updStatus
}

def configure() {
	if (parent == null) {
		logWarn("configure: No Parent Detected.  Configure function ABORTED.  Use Save Preferences instead.")
	} else {
		def confStatus = parent.updateConfigurations()
		logInfo("configure: ${confStatus}")
	}
}

def refresh() { poll() }

def poll() { getSysinfo() }

def setPollInterval(interval = state.pollInterval) {
	if (interval == "default" || interval == "off" || interval == null) {
		interval = "30 minutes"
	} else if (useCloud || altLan || getDataValue("altComms") == "true") {
		if (interval.contains("sec")) {
			interval = "1 minute"
			logWarn("setPollInterval: Device using Cloud or rawSocket.  Poll interval reset to minimum value of 1 minute.")
		}
	}
	state.pollInterval = interval
	def pollInterval = interval.substring(0,2).toInteger()
	if (interval.contains("sec")) {
		def start = Math.round((pollInterval-1) * Math.random()).toInteger()
		schedule("${start}/${pollInterval} * * * * ?", "poll")
		logWarn("setPollInterval: Polling intervals of less than one minute " +
				"can take high resources and may impact hub performance.")
	} else {
		def start = Math.round(59 * Math.random()).toInteger()
		schedule("${start} */${pollInterval} * * * ?", "poll")
	}
	logDebug("setPollInterval: interval = ${interval}.")
	return interval
}

def rebootDevice() {
	device.updateSetting("rebootDev", [type:"bool", value: false])
	reboot()
	pauseExecution(10000)
	return "REBOOTING DEVICE"
}

def bindUnbind() {
	def message
	if (getDataValue("deviceIP") == "CLOUD") {
		device.updateSetting("bind", [type:"bool", value: true])
		device.updateSetting("useCloud", [type:"bool", value: true])
		message = "No deviceIp.  Bind not modified."
	} else if (bind == null ||  getDataValue("feature") == "lightStrip") {
		message = "Getting current bind state"
		getBind()
	} else if (bind == true) {
		if (!parent.kasaToken || parent.userName == null || parent.userPassword == null) {
			message = "Username/pwd not set."
			getBind()
		} else {
			message = "Binding device to the Kasa Cloud."
			setBind(parent.userName, parent.userPassword)
		}
	} else if (bind == false) {
		message = "Unbinding device from the Kasa Cloud."
		setUnbind()
	}
	pauseExecution(5000)
	return message
}

def setBindUnbind(cmdResp) {
	def bindState = true
	if (cmdResp.get_info) {
		if (cmdResp.get_info.binded == 0) { bindState = false }
		logInfo("setBindUnbind: Bind status set to ${bindState}")
		setCommsType(bindState)
	} else if (cmdResp.bind.err_code == 0){
		getBind()
	} else {
		logWarn("setBindUnbind: Unhandled response: ${cmdResp}")
	}
}

def setCommsType(bindState) {
	def commsType = "LAN"
	def cloudCtrl = false
	if (bindState == false && useCloud == true) {
		logWarn("setCommsType: Can not use cloud.  Device is not bound to Kasa cloud.")
	} else if (bindState == true && useCloud == true && parent.kasaToken) {
		commsType = "CLOUD"
		cloudCtrl = true
	} else if (altLan == true) {
		commsType = "AltLAN"
		state.response = ""
	}
	def commsSettings = [bind: bindState, useCloud: cloudCtrl, commsType: commsType]
	device.updateSetting("bind", [type:"bool", value: bindState])
	device.updateSetting("useCloud", [type:"bool", value: cloudCtrl])
	sendEvent(name: "connection", value: "${commsType}")
	logInfo("setCommsType: ${commsSettings}")
	if (getDataValue("plugNo") != null) {
		def coordData = [:]
		coordData << [bind: bindState]
		coordData << [useCloud: cloudCtrl]
		coordData << [connection: commsType]
		coordData << [altLan: altLan]
		parent.coordinate("commsData", coordData, getDataValue("deviceId"), getDataValue("plugNo"))
	}
	pauseExecution(1000)
}

def syncName() {
	def message
	if (nameSync == "Hubitat") {
		message = "Hubitat Label Sync"
		setDeviceAlias(device.getLabel())
	} else if (nameSync == "device") {
		message = "Device Alias Sync"
	} else {
		message = "Not Syncing"
	}
	return message
}

def updateName(response) {
	device.updateSetting("nameSync",[type:"enum", value:"none"])
	def name = device.getLabel()
	if (response.alias) {
		name = response.alias
		device.setLabel(name)
		parent.updateAlias(device.deviceNetworkId, name)
	} else if (response.err_code != 0) {
		def msg = "updateName: Name Sync from Hubitat to Device returned an error."
		msg+= "\n\rNote: <b>Some devices do not support syncing name from the hub.</b>\n\r"
		logWarn(msg)
		return
	}
	logInfo("updateName: Hubitat and Kasa device name synchronized to ${name}")
}

def getSysinfo() {
	if (getDataValue("altComms") == "true") {
		sendTcpCmd("""{"system":{"get_sysinfo":{}}}""")
	} else {
		sendCmd("""{"system":{"get_sysinfo":{}}}""")
	}
}

def bindService() {
	def service = "cnCloud"
	def feature = getDataValue("feature")
	if (feature.contains("Bulb") || feature == "lightStrip") {
		service = "smartlife.iot.common.cloud"
	}
	return service
}

def getBind() {
	if (getDataValue("deviceIP") == "CLOUD") {
		logDebug("getBind: [status: notRun, reason: [deviceIP: CLOUD]]")
	} else {
		sendLanCmd("""{"${bindService()}":{"get_info":{}}}""")
	}
}

def setBind(userName, password) {
	if (getDataValue("deviceIP") == "CLOUD") {
		logDebug("setBind: [status: notRun, reason: [deviceIP: CLOUD]]")
	} else {
		sendLanCmd("""{"${bindService()}":{"bind":{"username":"${userName}",""" +
				   """"password":"${password}"}},""" +
				   """"${bindService()}":{"get_info":{}}}""")
	}
}

def setUnbind() {
	if (getDataValue("deviceIP") == "CLOUD") {
		logDebug("setUnbind: [status: notRun, reason: [deviceIP: CLOUD]]")
	} else {
		sendLanCmd("""{"${bindService()}":{"unbind":""},""" +
				   """"${bindService()}":{"get_info":{}}}""")
	}
}

def sysService() {
	def service = "system"
	def feature = getDataValue("feature")
	if (feature.contains("Bulb") || feature == "lightStrip") {
		service = "smartlife.iot.common.system"
	}
	return service
}

def reboot() {
	sendCmd("""{"${sysService()}":{"reboot":{"delay":1}}}""")
}

def setDeviceAlias(newAlias) {
	if (getDataValue("plugNo") != null) {
		sendCmd("""{"context":{"child_ids":["${getDataValue("plugId")}"]},""" +
				""""system":{"set_dev_alias":{"alias":"${device.getLabel()}"}}}""")
	} else {
		sendCmd("""{"${sysService()}":{"set_dev_alias":{"alias":"${device.getLabel()}"}}}""")
	}
}
