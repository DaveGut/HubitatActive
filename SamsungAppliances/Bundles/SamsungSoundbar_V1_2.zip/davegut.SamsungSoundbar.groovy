/*	Samsung Soundbar using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung Soundbars for import of control
and status of defined functions into Hubitat Environment.
=====	Library Use
This driver uses libraries for the functions common to SmartThings devices. 
Library code is at the bottom of the distributed single-file driver.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
=====	Version B0.2
Second Beta Release of the driver set.  All functions tested and validated on 
a Q900 as well as a MS-650.
a.	Removed preferences simulate and infoLog.  added function simulate()
b.	Changed validateResp to distResp and added processing for init (as req.)
c.	Removed try statements from data parsing.
d.	Automatically send refresh with any command (reducing timeline and number of comms).
===== B0.3
Updated to support newer soundbars with more commands
B0.31.  Corrections to account for format differences between Soundbars.
==============================================================================*/
def driverVer() { return "1.2" }

metadata {
	definition (name: "Samsung Soundbar",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Soundbar.groovy"
			   ){
		capability "Switch"
		command "toggleOnOff"
		capability "MediaInputSource"
		command "setInputSource", [[
			name: "Soundbar Input",
			constraints: ["digital", "HDMI1", "bluetooth", "HDMI2", "wifi"],
			type: "ENUM"]]
		command "toggleInputSource"
		capability "MediaTransport"
		capability "AudioVolume"
		command "toggleMute"
		capability "Refresh"
		attribute "trackData", "JSON_OBJECT"
//	Audio Notification Testing
		capability "AudioNotification"
//		command "playTrack", [[name: "Track Uri", type: "STRING"],
//							  [name: "Volume", type: "NUMBER"]]
	}
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("volIncrement", "number", title: "Volume Up/Down Increment", defaultValue: 1)
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["1", "5", "10", "30"], defaultValue: "5")
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: true)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() {
	sendEvent(name: "switch", value: "on")
	sendEvent(name: "volume", value: 0)
	sendEvent(name: "mute", value: "unmuted")
	sendEvent(name: "transportStatus", value: "stopped")
	sendEvent(name: "mediaInputSource", value: "wifi")
	runIn(1, updated)
}

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "OK") {
		logInfo("updated: ${commonStatus}")
	} else {
		logWarn("updated: ${commonStatus}")
	}
	if (volIncrement == null || !volIncrement) {
		device.updateSetting("volIncrement", [type:"number", value: 1])
	}
	deviceSetup()
}

//	===== Switch =====
def on() { setSwitch("on") }
def off() { setSwitch("off") }
def toggleOnOff() {
	def onOff = "on"
	if (device.currentValue("switch") == "on") {
		onOff = "off"
	}
	setSwitch(onOff)
}
def setSwitch(onOff) {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: onOff,
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setSwitch: [cmd: ${onOff}, ${cmdStatus}]")
}

//	===== Media Input Source =====
def toggleInputSource() {
	if (state.supportedInputs) {
		def inputSources = state.supportedInputs
		def totalSources = inputSources.size()
		def currentSource = device.currentValue("mediaInputSource")
		def sourceNo = inputSources.indexOf(currentSource)
		def newSourceNo = sourceNo + 1
		if (newSourceNo == totalSources) { newSourceNo = 0 }
		def inputSource = inputSources[newSourceNo]
		setInputSource(inputSource)
	} else { logWarn("toggleInputSource: NOT SUPPORTED") }
}
def setInputSource(inputSource) {
	if (state.supportedInputs) {
		def inputSources = state.supportedInputs
		if (inputSources.contains(inputSource)) {
		def cmdData = [
			component: "main",
			capability: "mediaInputSource",
			command: "setInputSource",
			arguments: [inputSource]]
		def cmdStatus = deviceCommand(cmdData)
		logInfo("setInputSource: [cmd: ${inputSource}, ${cmdStatus}]")
		} else {
			logWarn("setInputSource: Invalid input source")
		}
	} else { logWarn("setInputSource: NOT SUPPORTED") } 
}

//	===== Media Transport =====
def play() { setMediaPlayback("play") }
def pause() { setMediaPlayback("pause") }
def stop() { setMediaPlayback("stop") }
def setMediaPlayback(pbMode) {
	def cmdData = [
		component: "main",
		capability: "mediaPlayback",
		command: pbMode,
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMediaPlayback: [cmd: ${pbMode}, ${cmdStatus}]")
}

//	===== Audio Volume =====
def volumeUp() { 
	def curVol = device.currentValue("volume")
	def newVol = curVol + volIncrement.toInteger()
	setVolume(newVol)
}
def volumeDown() {
	def curVol = device.currentValue("volume")
	def newVol = curVol - volIncrement.toInteger()
	setVolume(newVol)
}
def setVolume(volume) {
	if (volume == null) { volume = device.currentValue("volume") }
	else if (volume < 0) { volume = 0 }
	else if (volume > 100) { volume = 100 }
	def cmdData = [
		component: "main",
		capability: "audioVolume",
		command: "setVolume",
		arguments: [volume]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setVolume: [cmd: ${volume}, ${cmdStatus}]")
}

def mute() { setMute("muted") }
def unmute() { setMute("unmuted") }
def toggleMute() {
	def muteValue = "muted"
	if(device.currentValue("mute") == "muted") {
		muteValue = "unmuted"
	}
	setMute(muteValue)
}
def setMute(muteValue) {
	def cmdData = [
		component: "main",
		capability: "audioMute",
		command: "setMute",
		arguments: [muteValue]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMute: [cmd: ${muteValue}, ${cmdStatus}]")
}

//	Audio Notification Test
/*
"Bell 1": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/bell1.mp3", duration: "10"]
"Bell 2": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/bell2.mp3", duration: "10"]
"Dogs Barking": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/dogs.mp3", duration: "10"]
"Fire Alarm": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/alarm.mp3", duration: "17"]
"The mail has arrived": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/the+mail+has+arrived.mp3", duration: "1"]
"A door opened": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/a+door+opened.mp3", duration: "1"]
"There is motion": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/there+is+motion.mp3", duration: "1"]
"Someone is arriving": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/someone+is+arriving.mp3", duration: "1"]
"Piano": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/piano2.mp3", duration: "10"]
"Lightsaber": [uri: "http://s3.amazonaws.com/smartapp-media/sonos/lightsaber.mp3", duration: "10"]
*/
def playText(text, volume = null) {
	logDebug("playText: [text: ${text}, Volume: ${volume}]")
	playNotification("playTrack", textToSpeech(text), volume)
}
def playTrack(uri, volume = null) {
	logDebug("playText: [uri: ${uri}, volume: ${volume}]")
	playNotification("playTrack", uri, volume)
}
def playTextAndRestore(text, volume = null) {
	logDebug("playTextAndRestore: [text: ${text}, Volume: ${volume}]")
	playNotification("playTrackAndRestore", textToSpeech(text), volume)
}
def playTrackAndRestore(uri, volume=null) {
	logDebug("playTrackAndRestore: [uri: ${uri}, Volume: ${volume}]")
	playNotification("playTrackAndRestore", uri, volume)
}
def playTextAndResume(text, volume = null) {
	logDebug("playTextAndRResume: [text: ${text}, Volume: ${volume}]")
	playNotification("playTrackAndResume", textToSpeech(text), volume)
}
def playTrackAndResume(uri, volume=null) {
	logDebug("playTrackAndResume: [uri: ${uri}, Volume: ${volume}]")
	playNotification("playTrackAndResume", uri, volume)
}
def playNotification(cmd, uri, volume) {
	def cmdData = [
		component: "main",
		capability: "audioNotification",
		command: cmd,
		arguments: [uri, volume]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("[playNotification: [cmd: ${cmd}, uri: ${uri}, volume: ${volume}, status: ${cmdStatus}]")
	runIn(1, refresh)
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
			}
			statusParse(respData.components.main)
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(mainData) {
	def setupData = [:]
	if (mainData.mediaInputSource != null) {
		def supportedInputs =  mainData.mediaInputSource.supportedInputSources.value
		sendEvent(name: "supportedInputs", value: supportedInputs)	
		state.supportedInputs = supportedInputs
		setupData << [supportedInputs: supportedInputs]
	} else {
		state.remove("supportedInputs")
	}
	if (setupData != [:]) {
		logInfo("deviceSetupParse: ${setupData}")
	}
}

def statusParse(mainData) {
	def onOff = mainData.switch.switch.value
	if (device.currentValue("switch") != onOff) {
		sendEvent(name: "switch", value: onOff)
	}
	
	def volume = mainData.audioVolume.volume.value.toInteger()
	sendEvent(name: "volume", value: volume)

	def mute = mainData.audioMute.mute.value
	sendEvent(name: "mute", value: mute)

	def transportStatus = mainData.mediaPlayback.playbackStatus.value
	sendEvent(name: "transportStatus", value: transportStatus)
	
	if (mainData.mediaInputSource != null) {
		def mediaInputSource = mainData.mediaInputSource.inputSource.value
		sendEvent(name: "mediaInputSource", value: mediaInputSource)
	}
	
	if (mainData.audioTrackData != null) {
		def audioTrackData = mainData.audioTrackData.audioTrackData.value
		sendEvent(name: "trackData", value: audioTrackData)
	}

	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Soundbar-Sim
