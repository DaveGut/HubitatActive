library (
	name: "Samsung-Soundbar-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Simulator - Samsung Soundbar",
	category: "utilities",
	documentationLink: ""
)

def testData() {
	def supportedSources = ["digital", "HDMI1", "bluetooth", "HDMI2", "wifi"]
	def trackTime = 280
	def trackRemain = 122
	def trackData = [title: "a", artist: "b"]
	
	if (!state.onOff) {
		state.onOff = "on"
		state.pbStatus = "playing"
		state.volume = 11
		state.inputSource = "HDMI2"
		state.mute = "unmuted"
	}
	
	return [
		mediaPlayback:[
			playbackStatus: [value: state.pbStatus],	//
			supportedPlaybackCommands:[value:[play, pause, stop]]],	//	not used
		audioVolume:[volume:[value: state.volume]],	//
		mediaInputSource:[
			supportedInputSources:[value: supportedSources], 	//	devicesetup
			inputSource:[value: state.inputSource]],	//
		audioMute:[mute:[value: state.mute]],	//
		switch:[switch:[value: state.onOff]],
		audioTrackData:[
			totalTime:[value: trackTime],
			audioTrackData:[value: trackData],
			elapsedTime:[value: trackRemain]]
	]
}
def testResp(cmdData) {
	def cmd = cmdData.command
	def args = cmdData.arguments
	switch(cmd) {
		case "off":
			state.onOff = "off"
			break
		case "on":
			state.onOff = "on"
			break
		case "play":
			state.pbStatus = "playing"
			break
		case "pause":
			state.pbStatus = "paused"
			break
		case "stop":
			state.pbStatus = "stopped"
			break
		case "setVolume":
			state.volume = args[0]
			break
		case "setInputSource":
			state.inputSource = args[0]
			break
		case "setMute":
			def muteState = "muted"
			if (args[0] == "unmute") {
				muteState = "unmuted"
			}
			state.mute = muteState
			break
		case "playTrack":
			break
		case "refresh":
			break
		default:
			logWarn("testResp: [unhandled: ${cmdData}]")
	}
	
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
def xxtestData() {
	def pbStatus = "playing"
	def sfMode = 3
	def sfDetail = "External Device"
	def volume = 15
	def inputSource = "HDMI2"
	def supportedSources = ["digital", "HDMI1", "bluetooth", "HDMI2", "wifi"]
	def mute = "unmuted"
	def onOff = "on"
	def trackTime = 280
	def trackRemain = 122
	def trackData = [title: "a", artist: "b", album: "c"]


	return [
		mediaPlayback:[
			playbackStatus: [value: pbStatus],
			supportedPlaybackCommands:[value:[play, pause, stop]]],
		"samsungvd.soundFrom":[
			mode:[value: sfMode],
			detailName:[value: sfDetail]],
		audioVolume:[volume:[value: volume]],
		mediaInputSource:[
			supportedInputSources:[value: supportedSources], 
			inputSource:[value: inputSource]],
		audioMute:[mute:[value: mute]],
		switch:[switch:[value: onOff]],
		audioTrackData:[
			totalTime:[value: trackTime],
			audioTrackData:[value: trackData],
			elapsedTime:[value: trackRemain]]]
}
def xxtestResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
