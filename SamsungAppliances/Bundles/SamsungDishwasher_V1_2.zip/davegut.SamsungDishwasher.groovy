/*	Samsung Dishwasher using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung Washers for import of control
and status of defined functions into Hubitat Environment.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Dishwasher",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Washer.groovy"
			   ){
		capability "Refresh"
		capability "Switch"
		command "toggleOnOff"
		attribute "kidsLock", "string"
		command "setDishwasherMode", [[
			name: "Dishwasher Mode",
			constraints: ["auto", "normal", "heavy", "delicate", "express", "rinseOnly", "selfClean"],
			type: "ENUM"]]
		command "toggleDishwasherMode"
		attribute "dishwasherMode", "string"
		attribute "supportedDishwasherModes", "string"
		attribute "operatingState", "string"
		attribute "timeRemaining", "string"
		attribute "currentJob", "string"
	}
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["10sec", "20sec", "30sec", "1", "5", "10", "30"], defaultValue: "10")
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: false)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() { }

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "FAILED") {
		logWarn("updated: ${commonStatus}")
	} else {
		logInfo("updated: ${commonStatus}")
	}
	deviceSetup()
}

def on() { setSwitch("on") }
def off() { setSwitch("off") }
def toggleOnOff() {
	def onOff = "on"
	if (device.currentValue("switch") == "on") {
		onOff = "off"
	}
	setSwitch(onOff)
}
def setSwitch(onOff) {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: onOff,
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setSwitch: [cmd: ${onOff}, ${cmdStatus}]")
}

def toggleDishwasherMode() {
	if (state.supportedDishwasherModes) {
		def modes = state.supportedDishwasherModes
		def totalModes = modes.size()
		def currentMode = device.currentValue("dishwasherMode")
		def modeIndex = modes.indexOf(currentMode)
		def newModeIndex = modeIndex + 1
		if (newModeIndex == totalModes) { newModeIndex = 0 }
		setDishwasherMode(modes[newModeIndex])
	} else { logWarn("toggleInputSource: NOT SUPPORTED") }
}
def setDishwasherMode(dishwasherMode) {
	def cmdData = [
		component: "main",
		capability: "samsungce.dishwasherWashingCourse",
		command: "setWashingCourse",
		arguments: [dishwasherMode]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setDishwasherMode: [cmd: ${dishwasherMode}, ${cmdStatus}]")
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			statusParse(respData.components.main)
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(parseData) {
	def logData = [:]
	
	def supportedDishwasherModes = parseData["samsungce.dishwasherWashingCourse"].supportedCourses.value
	sendEvent(name: "supportedDishwasherModes", value: supportedDishwasherModes)
	state.supportedDishwasherModes = supportedDishwasherModes
	logData << [supportedDishwasherModes: supportedDishwasherModes]

	logInfo("deviceSetupParse: ${logData}")
}

def statusParse(mainData) {
	def onOff = mainData.switch.switch.value
	if (device.currentValue("switch") != onOff) {
		if (onOff == "off") {
			setPollInterval(state.pollInterval)
		} else {
			runEvery1Minute(poll)
		}
		sendEvent(name: "switch", value: onOff)
	}
	
	def kidsLock = mainData["samsungce.kidsLock"].lockState.value
	sendEvent(name: "kidsLock", value: kidsLock)
	
	def dishwasherMode = mainData["samsungce.dishwasherWashingCourse"].washingCourse.value
	sendEvent(name: "dishwasherMode", value: dishwasherMode)
	
	def operatingState = mainData["samsungce.dishwasherOperation"].operatingState.value
	sendEvent(name: "operatingState", value: operatingState)
	
	def timeRemaining = mainData["samsungce.dishwasherOperation"].remainingTimeStr.value
	sendEvent(name: "timeRemaining", value: timeRemaining)
	
	def currentJob = mainData["samsungce.dishwasherJobState"].dishwasherJobState.value
	sendEvent(name: "currentJob", value: currentJob)
	
	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Dishwasher-Sim
