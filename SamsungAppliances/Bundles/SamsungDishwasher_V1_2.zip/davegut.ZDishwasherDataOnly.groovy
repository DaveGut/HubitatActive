metadata {
	definition (name: "Z Dishwasher Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

/*

deviceStatus: [
	components:[
		main:[
			samsungce.dishwasherWashingCourse:[
				customCourseCandidates:[value:null], 
				washingCourse:[value:auto, timestamp:2022-07-31T05:25:52.494Z], 
				supportedCourses:[value:[auto, normal, heavy, delicate, express, rinseOnly, selfClean], timestamp:2021-06-20T02:28:43.163Z]], 
			switch:[switch:[value:off, timestamp:2022-08-09T23:02:37.426Z]], 
//			custom.dishwasherOperatingPercentage:[dishwasherOperatingPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z]], 
			samsungce.dishwasherOperation:[
				supportedOperatingState:[value:null], 
				operatingState:[value:ready, timestamp:2022-08-09T23:02:37.497Z], 
				reservable:[value:false, timestamp:2022-07-20T02:35:28.876Z], 
				progressPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z], 
				remainingTimeStr:[value:02:16, timestamp:2022-08-09T23:02:37.716Z], 
				operationTime:[value:null], remainingTime:[value:136.0, unit:min, timestamp:2022-08-09T23:02:37.716Z], 
				timeLeftToStart:[value:0.0, unit:min, timestamp:2022-08-05T16:57:02.657Z]], 
			samsungce.dishwasherJobState:[
				scheduledJobs:[value:[[jobName:washing, timeInSec:3530], [jobName:rinsing, timeInSec:770], [jobName:drying, timeInSec:1400]], timestamp:2022-08-09T23:02:37.933Z], 
				dishwasherJobState:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-06-20T02:28:42.662Z]]]]]

IMPLEMENTATION
samsungce.dishwasherWashingCourse:[
	attribute: supportedCourses [auto, normal, heavy, delicate, express, rinseOnly, selfClean],
	attribute: washingCourse,
	command setWashingCourse
	]
switch:[
	attribute: switch(on/off),
	commands: on/off
	]
samsungce.dishwasherOperation:[
	attribute: operatingState,
	attribute: remainingTime(min:sec)
	]
samsungce.kidsLock:[
	attribute: lockState
	]




AlldeviceStatus: [
	components:[
		main:[
			samsungce.dishwasherWashingCourse:[
				customCourseCandidates:[value:null], washingCourse:[value:auto, timestamp:2022-07-31T05:25:52.494Z], 
				supportedCourses:[value:[auto, normal, heavy, delicate, express, rinseOnly, selfClean], timestamp:2021-06-20T02:28:43.163Z]], 
			N/ApowerConsumptionReport:[powerConsumption:[
				value:[energy:202600, deltaEnergy:0, power:0, powerEnergy:0.0, persistedEnergy:0, energySaved:0, 
					   start:2022-08-09T22:52:45Z, end:2022-08-09T23:02:32Z], timestamp:2022-08-09T23:02:32.759Z]], refresh:[:], 
			DISdishwasherOperatingState:[
				completionTime:[value:2022-08-10T01:18:37Z, timestamp:2022-08-09T23:02:37.716Z], 
				machineState:[value:stop, timestamp:2022-08-09T23:02:37.497Z], 
				supportedMachineStates:[value:null], 
				dishwasherJobState:[value:unknown, timestamp:2022-08-09T23:02:37.504Z]], 
			DISsamsungce.dishwasherWashingCourseDetails:[predefinedCourses:[value:[
				[courseName:auto, energyUsage:3, waterUsage:3, temperature:[min:50, max:60, unit:C], expectedTime:[time:136, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], 
						  sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:normal, energyUsage:3, waterUsage:4, temperature:[min:45, max:62, unit:C], expectedTime:[time:148, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], 
						  speedBooster:[default:false, settable:[false, true]], zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:heavy, energyUsage:4, waterUsage:5, temperature:[min:65, max:65, unit:C], expectedTime:[time:155, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:delicate, energyUsage:2, waterUsage:3, temperature:[min:50, max:50, unit:C], expectedTime:[time:112, unit:min], 
				 options:[highTempWash:[default:false, settable:[]],sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[false, true]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:express, energyUsage:2, waterUsage:2, temperature:[min:52, max:52, unit:C], expectedTime:[time:60, unit:min], 
				 options:[highTempWash:[default:false, settable:[false, true]], sanitize:[default:false, settable:[false, true]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[none, left]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:rinseOnly, energyUsage:1, waterUsage:1, temperature:[min:40, max:40, unit:C], expectedTime:[time:14, unit:min], 
				 options:[highTempWash:[default:false, settable:[]], sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, lower, all]]]], 
				[courseName:selfClean, energyUsage:5, waterUsage:4, temperature:[min:70, max:70, unit:C], expectedTime:[time:139, unit:min], 
				 options:[highTempWash:[default:false, settable:[]], sanitize:[default:false, settable:[]], speedBooster:[default:false, settable:[]], 
						  zoneBooster:[default:none, settable:[]], selectedZone:[default:all, settable:[none, all]]]]], timestamp:2022-07-18T20:00:32.697Z],waterUsageMax:[value:5, timestamp:2021-06-20T02:28:43.163Z], energyUsageMax:[value:5, timestamp:2021-06-20T02:28:43.163Z]], 
			DISsamsungce.dishwasherWashingOptions:[
				dryPlus:[value:null], 
				stormWash:[value:null], 
				hotAirDry:[value:null], 
				selectedZone:[value:[value:all, settable:[none, upper, lower, all]], timestamp:2021-06-21T17:15:23.099Z], 
				speedBooster:[value:[value:false, settable:[false, true]], timestamp:2022-08-08T05:25:37.271Z], 
				highTempWash:[value:[value:false, settable:[false, true]], timestamp:2022-08-08T05:25:37.499Z], 
				sanitizingWash:[value:null], 
				zoneBooster:[value:[value:none, settable:[none, left, right, all]], timestamp:2021-06-21T17:15:22.788Z], 
				addRinse:[value:null], 
				supportedList:[value:[selectedZone, zoneBooster, speedBooster, sanitize, highTempWash], timestamp:2021-06-20T02:28:43.343Z], 
				rinsePlus:[value:null], 
				sanitize:[value:[value:false, settable:[false, true]], timestamp:2022-06-19T16:26:14.740Z], 
				steamSoak:[value:null]], 
			N/Aexecute:[data:[
				value:[payload:[rt:[x.com.samsung.da.mode], 
								if:[oic.if.baseline, oic.if.a], 
								x.com.samsung.da.options:[ProgressTimeSet_420DCA820302B20578]]], data:[href:/course/vs/0], timestamp:2022-08-09T23:02:37.933Z]], 
			N/Asamsungce.deviceIdentification:[
				micomAssayCode:[value:null], 
				modelName:[value:null], 
				serialNumber:[value:null], 
				serialNumberExtra:[value:null], 
				modelClassificationCode:[value:null], 
				description:[value:null], 
				binaryId:[value:DA_DW_A51_20_COMMON, timestamp:2022-07-20T02:35:28.876Z]], 
			DIScustom.dishwasherOperatingProgress:[
				dishwasherOperatingProgress:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			switch:[switch:[value:off, timestamp:2022-08-09T23:02:37.426Z]], 
			DIScustom.dishwasherOperatingPercentage:[dishwasherOperatingPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z]], 
			N/Aocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:DA_DW_A51_20_COMMON_30220418, timestamp:2022-07-30T20:16:08.983Z], 
				 mnhw:[value:ARTIK051, timestamp:2021-06-20T02:28:43.018Z], di:[value:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, timestamp:2021-06-20T02:28:43.018Z], 
				 mnsl:[value:http:www.samsung.com, timestamp:2021-06-20T02:28:43.018Z], dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-07-30T20:33:34.910Z], 
				 n:[value:[dishwasher] Samsung, timestamp:2021-06-20T02:28:43.018Z], mnmo:[value:DA_DW_A51_20_COMMON|30007242|40010201001311000101000000000000, timestamp:2021-06-20T02:28:43.018Z], 
				 vid:[value:DA-WM-DW-000001, timestamp:2021-06-20T02:28:43.018Z], mnmn:[value:Samsung Electronics, timestamp:2021-06-20T02:28:43.018Z], 
				 mnml:[value:http:www.samsung.com, timestamp:2021-06-20T02:28:43.018Z], mnpv:[value:DAWIT 2.0, timestamp:2021-06-20T02:28:43.018Z], 
				 mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-06-20T02:28:43.018Z], pi:[value:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, timestamp:2021-06-20T02:28:43.018Z], 
				 icv:[value:core.1.1.0, timestamp:2021-06-20T02:28:43.018Z]], 
			DISremoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-01-23T05:05:50.482Z]], 
			N/Acustom.supportedOptions:[
				referenceTable:[value:null], 
				supportedCourses:[value:[82, 83, 84, 85, 86, 87, 88], timestamp:2021-06-20T02:28:43.163Z]], 
			DIScustom.dishwasherDelayStartTime:[dishwasherDelayStartTime:[value:00:00:00, timestamp:2022-08-05T16:57:02.657Z]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[
					custom.dishwasherOperatingProgress,
					custom.dishwasherOperatingPercentage,
					custom.dishwasherDelayStartTime,
					samsungce.dishwasherWashingCourse,
					samsungce.dishwasherWashingCourseDetails,
					samsungce.dishwasherWashingOptions,
					dishwasherOperatingState,
					remoteControlStatus,
					sec.diagnosticsInformation,
					custom.waterFilter], timestamp:2022-08-09T22:37:48.055Z]], 
			N/Asamsungce.driverVersion:[versionNumber:[value:22070701, timestamp:2022-07-20T02:35:28.876Z]], 
			N/Asamsungce.softwareUpdate:[
				otnDUID:[value:MTCNQWBWKPONC, timestamp:2022-07-20T02:35:28.876Z],
				availableModules:[value:[], timestamp:2022-07-20T02:35:28.876Z],
				newVersionAvailable:[value:false, timestamp:2022-07-20T02:35:28.876Z]], 
			DISsec.diagnosticsInformation:[
				logType:[value:null], endpoint:[value:null], minVersion:[value:null], setupId:[value:null], protocolType:[value:null], mnId:[value:null], dumpType:[value:null]], 
			samsungce.dishwasherOperation:[
				supportedOperatingState:[value:null], 
				operatingState:[value:ready, timestamp:2022-08-09T23:02:37.497Z], 
				reservable:[value:false, timestamp:2022-07-20T02:35:28.876Z], 
				progressPercentage:[value:100, timestamp:2022-08-09T23:02:37.714Z], 
				remainingTimeStr:[value:02:16, timestamp:2022-08-09T23:02:37.716Z], 
				operationTime:[value:null], remainingTime:[value:136.0, unit:min, timestamp:2022-08-09T23:02:37.716Z], 
				timeLeftToStart:[value:0.0, unit:min, timestamp:2022-08-05T16:57:02.657Z]], 
			DIScustom.waterFilter:[
				waterFilterUsageStep:[value:null], waterFilterResetType:[value:null], waterFilterCapacity:[value:null],
				waterFilterLastResetDate:[value:null], waterFilterUsage:[value:null], waterFilterStatus:[value:null]],
			samsungce.dishwasherJobState:[
				scheduledJobs:[value:[[jobName:washing, timeInSec:3530], [jobName:rinsing, timeInSec:770], [jobName:drying, timeInSec:1400]], timestamp:2022-08-09T23:02:37.933Z], 
				dishwasherJobState:[value:none, timestamp:2022-08-09T23:02:37.504Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-06-20T02:28:42.662Z]]]]]


deviceData: [
	deviceId:ad0ff2d1-fe5f-e23c-961b-4e6ae18dd6ff, 
	name:[dishwasher] Samsung, 
	label:Dishwasher, 
	manufacturerName:Samsung Electronics, 
	presentationId:DA-WM-DW-000001, 
	deviceManufacturerCode:Samsung Electronics, 
	locationId:f4b7b4c0-d957-4f83-b8b4-1e00e71b101b, 
	ownerId:e8685053-d886-4a82-bcff-149e263b9334, 
	roomId:f4ab9071-b494-43d8-8bd0-8e0c6927917c, 
	deviceTypeName:Samsung OCF Dishwasher, c
	omponents:[
		[id:main, label:main, capabilities:[
			[id:execute, version:1], 
			[id:ocf, version:1], 
			[id:powerConsumptionReport, version:1], 
			[id:refresh, version:1], 
			[id:remoteControlStatus, version:1], 
			[id:switch, version:1], 
			[id:dishwasherOperatingState, version:1], 
			[id:custom.disabledCapabilities, version:1], 
			[id:custom.dishwasherOperatingProgress, version:1], 
			[id:custom.dishwasherOperatingPercentage, version:1], 
			[id:custom.dishwasherDelayStartTime, version:1], 
			[id:custom.supportedOptions, version:1], 
			[id:custom.waterFilter, version:1], 
			[id:samsungce.deviceIdentification, version:1], 
			[id:samsungce.dishwasherJobState, version:1], 
			[id:samsungce.dishwasherWashingCourse, version:1], 
			[id:samsungce.dishwasherWashingCourseDetails, version:1], 
			[id:samsungce.dishwasherOperation, version:1], 
			[id:samsungce.dishwasherWashingOptions, version:1], 
			[id:samsungce.driverVersion, version:1], [id:samsungce.softwareUpdate, version:1], 
			[id:samsungce.kidsLock, version:1], 
			[id:sec.diagnosticsInformation, version:1]], 
		 categories:[[name:Dishwasher, categoryType:manufacturer]]]], createTime:2021-06-20T02:28:41.270Z, 
	profile:[id:83215147-9581-3e0e-acca-b4e2e1a406b2], 
	ocf:[
		ocfDeviceType:oic.d.dishwasher, 
		name:[dishwasher] Samsung, 
		specVersion:core.1.1.0, 
		verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, 
		manufacturerName:Samsung Electronics, 
		modelNumber:DA_DW_A51_20_COMMON|30007242|40010201001311000101000000000000, 
		platformVersion:DAWIT 2.0, 
		platformOS:TizenRT 1.0 + IPv6, hwVersion:ARTIK051, 
		firmwareVersion:DA_DW_A51_20_COMMON_30220418, 
		vendorId:DA-WM-DW-000001, 
		vendorResourceClientServerVersion:ARTIK051 Release 2.210224.1, 
		lastSignupTime:2021-06-20T02:28:38.121470Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]
























*/