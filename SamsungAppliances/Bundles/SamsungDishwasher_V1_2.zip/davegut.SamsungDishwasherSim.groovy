library (
	name: "Samsung-Dishwasher-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "ST Samsung AC Simulator",
	category: "utilities",
	documentationLink: ""
)

def setTimeRemaining(timeRemaining) {
	state.timeRemaining = timeRemaining
	poll()
}
def setKidsLock(lock) {
	state.lock = lock
	poll()
}
def setJobState(jobState) {
	state.jobState = jobState
	poll()
}

def testResp(cmdData) {
	def cmd = cmdData.command
	def args = cmdData.arguments
	switch(cmd) {
		case "off":
			state.switch = "off"
			break
		case "on":
			state.switch = "on"
			break
		case "setWashingCourse":
			state.course = args[0]
			break
//		case "opState":
//			state.opState = args[0]
//			break
		case "refresh":
			break
		default:
			logWarn("testResp: [unhandled: ${cmdData}]")
	}
	
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}

def testData() {
	if (!state.course) {
		state.course = "auto"		//	auto, normal, heavy, delicate, express, rinseOnly, selfClean
		state.switch = "off"
		state.opState = "ready"
		state.timeRemaining = "01:30"
		state.lock = "unlocked"
		state.jobState = "none"		//	none, washing, rinsing, drying
	}

	return [
		"samsungce.dishwasherWashingCourse":[
			washingCourse:[value: state.course],
			supportedCourses:[value:["auto", "normal", "heavy", "delicate", "express", "rinseOnly", "selfClean"]]],
		switch:[switch:[value: state.switch]],
		"samsungce.dishwasherOperation":[
			operatingState:[value: state.opState],
			remainingTimeStr:[value: state.timeRemaining]],
		"samsungce.dishwasherJobState":[
			dishwasherJobState:[value: state.jobState]], 
		"samsungce.kidsLock":[lockState:[value: state.lock]]
	]
}

