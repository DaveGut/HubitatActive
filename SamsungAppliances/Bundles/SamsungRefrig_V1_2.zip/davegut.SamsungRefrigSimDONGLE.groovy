library (
	name: "Samsung-Refrig-Sim-DONGLE",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Simulator - Samsung DONGLE Refrigerator",
	category: "utilities",
	documentationLink: ""
)

def testData() {
	if (!state.dongle) { state.dongle = true }

//	def test = 0
//	def test = 1
	def test = 2
	def tempUnit = "C"
//	onedoor
	def onedoorContact = "closed"
	def onedoorSetpoint = 5
//	cooler
	def coolerContact = "closed"
	def coolerSetpoint = 3
//	freezer
	def freezerContact = "closed"
	def freezerSetpoint = -2
//	main
	def mainContact = "closed"
	def defrost = "off"
	def rapidCooling = "off"
	def rapidFreezing = "off"
	def filterReplace = "replace"
	def mainSetpoint = 4
//	cvroom
	def cvContact = "closed"
	def cvSetpoint = 1
//	icemaker
	def onOff = "off"
	if (test == 1) {
		tempUnit = "F"
		onedoorContact = "open"
		onedoorSetpoint = 33
		coolerContact = "open"
		coolerSetpoint = 34
		freezerContact = "open"
		freezerSetpoint = 30
		mainContact = "open"
		defrost = "on"
		rapidCooling = "on"
		rapidFreezing = "on"
		filterReplace = "normal"
		mainSetpoint = 37
		cvContact = "open"
		cvSetpoint = 35
		onOff = "on"
	} else if (test == 2) {
		onedoorContact = null
		onedoorSetpoint = null
		coolerContact = null
		coolerSetpoint = null
		freezerContact = null
		freezerSetpoint = null
		mainContact = null
		defrost = null
		rapidCooling = null
		rapidFreezing = null
		filterReplace =null
		mainSetpoint = null
		cvContact = null
		cvSetpoint = null
		onOff = null
	}
		

	
	return [components:[
		onedoor:[
			contactSensor:[contact:[value:onedoorContact]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:onedoorSetpoint, unit:tempUnit]]], 
		cooler:[
			contactSensor:[contact:[value:coolerContact]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:coolerSetpoint, unit:tempUnit]]], 
		freezer:[
			contactSensor:[contact:[value:freezerContact]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:freezerSetpoint, unit:tempUnit]]],
		main:[
			contactSensor:[contact:[value:mainContact]], 
			ocf:[
				mnmo:[value:"DONGLE_0241|00089841|00020340051131200103000000000000"]], 
			refrigeration:[
				defrost:[value:defrost], 
				rapidCooling:[value:rapidCooling], 
				rapidFreezing:[value:rapidFreezing]], 
			"custom.disabledCapabilities":[disabledCapabilities:[value:null]],
			"custom.waterFilter":[
				waterFilterStatus:[value:filterReplace]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:mainSetpoint, unit:tempUnit]]], 
		cvroom:[
			contactSensor:[contact:[value:cvContact]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:cvSetpoint], unit:tempUnit]]]]
}

def testResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
