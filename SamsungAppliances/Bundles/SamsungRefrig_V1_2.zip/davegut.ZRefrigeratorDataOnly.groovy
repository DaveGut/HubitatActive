metadata {
	definition (name: "Z Refrigerator Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}


/*
resp: [
	components:[
		pantry-01:[
			samsungce.foodDefrost:[
				supportedOptions:[value:null],foodType:[value:null], weight:[value:null], operationTime:[value:null],remainingTime:[value:null]],
			samsungce.fridgePantryInfo:[name:[value:null]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.meatAging,samsungce.foodDefrost], timestamp:2022-08-16T23:11:32.877Z]],
			samsungce.meatAging:[zoneInfo:[value:null],supportedMeatTypes:[value:null], supportedAgingMethods:[value:null],status:[value:null]], 
			samsungce.fridgePantryMode:[mode:[value:null],supportedModes:[value:null]]],
		pantry-02:[
			samsungce.foodDefrost:[supportedOptions:[value:null],foodType:[value:null], weight:[value:null], operationTime:[value:null]remainingTime:[value:null]],
			samsungce.fridgePantryInfo:[name:[value:null]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[samsungce.meatAging,samsungce.foodDefrost], timestamp:2022-08-16T23:11:32.877Z]],
			samsungce.meatAging:[zoneInfo:[value:null],supportedMeatTypes:[value:null], supportedAgingMethods:[value:null],status:[value:null]], 
			samsungce.fridgePantryMode:[mode:[value:null],supportedModes:[value:null]]],
		icemaker:[
			custom.disabledCapabilities:[disabledCapabilities:[value:[],timestamp:2022-08-16T23:11:32.877Z]], 
			switch:[switch:[value:on,timestamp:2022-08-17T02:27:15.205Z]]],
		onedoor:[
			custom.fridgeMode:[fridgeModeValue:[value:null],fridgeMode:[value:null]], 
			contactSensor:[contact:[value:null]],
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[custom.fridgeMode,temperatureMeasurement, thermostatCoolingSetpoint],timestamp:2022-08-16T23:11:32.877Z]],
			temperatureMeasurement:[
				temperature:[value:null]],thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]],
		scale-10:[
			samsungce.connectionState:[connectionState:[value:null]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[],timestamp:2022-08-16T23:11:32.877Z]],
			samsungce.weightMeasurement:[weight:[value:null]],
			samsungce.weightMeasurementCalibration:[:]],
		scale-11:[
			custom.disabledCapabilities:[disabledCapabilities:[value:[],timestamp:2022-08-16T23:11:32.877Z]],
			samsungce.weightMeasurement:[weight:[value:null]]],
		cooler:[
			custom.fridgeMode:[fridgeModeValue:[value:null],fridgeMode:[value:null]],
			contactSensor:[contact:[value:closed,timestamp:2022-09-09T01:20:22.537Z]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[custom.fridgeMode,samsungce.temperatureSetting], timestamp:2022-08-16T23:11:36.106Z]],
			samsungce.temperatureSetting:[supportedDesiredTemperatures:[value:null],desiredTemperature:[value:null]],
			temperatureMeasurement:[temperature:[value:37, unit:F,timestamp:2022-08-17T01:44:21.647Z]],
			custom.thermostatSetpointControl:[
				minimumSetpoint:[value:34, unit:F,timestamp:2022-08-16T23:11:35.364Z], 
				maximumSetpoint:[value:44, unit:F,timestamp:2022-08-16T23:11:35.364Z]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:37, unit:F,timestamp:2022-08-16T23:11:35.364Z]]],
		freezer:[
			custom.fridgeMode:[fridgeModeValue:[value:null],fridgeMode:[value:null]], 
			contactSensor:[contact:[value:closed, timestamp:2022-09-08T21:07:09.158Z]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[custom.fridgeMode,samsungce.temperatureSetting], timestamp:2022-08-16T23:11:36.106Z]],
			samsungce.temperatureSetting:[supportedDesiredTemperatures:[value:null],desiredTemperature:[value:null]],
			temperatureMeasurement:[temperature:[value:0, unit:F,timestamp:2022-08-17T02:43:21.176Z]],
			custom.thermostatSetpointControl:[
				minimumSetpoint:[value:-8, unit:F,timestamp:2022-08-16T23:11:35.364Z],maximumSetpoint:[value:5, unit:F,timestamp:2022-08-16T23:11:35.364Z]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:0, unit:F,timestamp:2022-08-16T23:11:35.364Z]]],
		main:[
			custom.disabledComponents:[disabledComponents:[value:[cvroom,onedoor, icemaker-02, pantry-01, pantry-02, scale-10, scale-11],timestamp:2022-08-16T23:11:36.106Z]],
			demandResponseLoadControl:[drlcStatus:[value:[drlcType:1, drlcLevel:0,duration:0, override:false], timestamp:2022-08-16T23:11:35.604Z]],
			contactSensor:[contact:[value:closed, timestamp:2022-09-09T01:20:22.537Z]],
			powerConsumptionReport:[
				powerConsumption:[value:[energy:37514,deltaEnergy:1, power:2, powerEnergy:0.2402049998442332, persistedEnergy:0,energySaved:0, 
										 start:2022-09-09T01:20:19Z, end:2022-09-09T01:22:43Z],timestamp:2022-09-09T01:22:43.132Z]],
			samsungce.viewInside:[contents:[value:null], lastUpdatedTime:[value:null]],
			refresh:[:],
			execute:[
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.refcontrol],
							if:[oic.if.baseline, oic.if.a],
							x.com.samsung.da.sabbathMode:On]],
					data:[href:/sabbath/vs/0], timestamp:2022-09-09T01:29:59.014Z]],
			samsungce.deviceIdentification:[
				micomAssayCode:[value:null],modelName:[value:null], serialNumber:[value:null],serialNumberExtra:[value:null], 
				modelClassificationCode:[value:null],description:[value:null], binaryId:[value:TP1X_REF_21K,timestamp:2022-08-16T23:11:35.205Z]],
			custom.fridgeMode:[fridgeModeValue:[value:null], fridgeMode:[value:null]],
			samsungce.selfCheck:[
				result:[value:passed,timestamp:2022-08-16T23:11:33.301Z], 
				supportedActions:[value:[start],timestamp:2022-08-16T23:11:33.301Z], 
				progress:[value:null],errors:[value:[], timestamp:2022-08-16T23:11:33.301Z], 
				status:[value:ready,timestamp:2022-08-16T23:11:33.301Z]], 
			ocf:[
				st:[value:null],mndt:[value:null], mnfv:[value:A-RFWW-TP1-22-REV1_20220604,timestamp:2022-08-16T23:24:33.442Z], 
				 mnhw:[value:Realtek,timestamp:2022-08-16T23:11:36.419Z],di:[value:86cb4b57-bbc3-d180-d6ec-18b77edf6b70,timestamp:2022-08-16T23:11:36.419Z], 
				 mnsl:[value:http:www.samsung.com<https:link.engageusercontent.com/mt/lte?tid=87281789190314&lid=3&targetURL=http%3A%2F%2Fwww.samsung.com>,timestamp:2022-08-16T23:11:36.419Z], 
				 dmv:[value:1.2.1,timestamp:2022-08-16T23:18:16.237Z], n:[value:[refrigerator] Samsung,timestamp:2022-08-16T23:11:36.419Z],
				 mnmo:[value:TP1X_REF_21K|00148242|00020253031611200103000031010000,timestamp:2022-08-16T23:11:36.419Z], 
				 vid:[value:DA-REF-NORMAL-01011,timestamp:2022-08-16T23:11:36.419Z], mnmn:[value:Samsung Electronics,timestamp:2022-08-16T23:11:36.419Z], 
				 mnml:[value:http:www.samsung.com<https:link.engageusercontent.com/mt/lte?tid=87281789190314&lid=4&targetURL=http%3A%2F%2Fwww.samsung.com>,timestamp:2022-08-16T23:11:36.419Z], 
				 mnpv:[value:DAWIT 2.0,timestamp:2022-08-16T23:11:36.419Z], mnos:[value:TizenRT 3.1,timestamp:2022-08-16T23:11:36.419Z],
				 pi:[value:86cb4b57-bbc3-d180-d6ec-18b77edf6b70,timestamp:2022-08-16T23:11:36.419Z], icv:[value:core.1.1.0,timestamp:2022-08-16T23:11:36.419Z]], 
			refrigeration:[
				defrost:[value:off,timestamp:2022-08-16T23:11:33.559Z], rapidCooling:[value:off,timestamp:2022-08-17T01:42:53.444Z], 
				rapidFreezing:[value:off,timestamp:2022-08-17T02:27:12.883Z]],
			custom.deodorFilter:[
				deodorFilterLastResetDate:[value:null],deodorFilterCapacity:[value:null], deodorFilterStatus:[value:null],
				deodorFilterResetType:[value:null], deodorFilterUsage:[value:null],deodorFilterUsageStep:[value:null]],
			samsungce.powerCool:[activated:[value:false,timestamp:2022-08-17T01:42:53.444Z]],
			custom.energyType:[
				energyType:[value:2.0,timestamp:2022-08-16T23:11:32.877Z], energySavingSupport:[value:false,timestamp:2022-08-16T23:11:33.021Z], 
				drMaxDuration:[value:1440, unit:min,timestamp:2022-08-16T23:11:35.604Z], 
				energySavingOperation:[value:null],energySavingOperationSupport:[value:false,timestamp:2022-08-16T23:11:35.604Z]],
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[custom.deodorFilter,samsungce.viewInside, demandResponseLoadControl,thermostatCoolingSetpoint], timestamp:2022-09-08T02:22:04.355Z]],
			samsungce.softwareUpdate:[
				otnDUID:[value:7XCGCEMPYLRUC,timestamp:2022-08-16T23:11:35.205Z], availableModules:[value:[],timestamp:2022-08-16T23:11:35.205Z], 
				newVersionAvailable:[value:false,timestamp:2022-08-16T23:11:35.205Z]],
			samsungce.driverVersion:[versionNumber:[value:22072701,timestamp:2022-09-07T08:04:37.166Z]],
			samsungce.powerFreeze:[activated:[value:false,timestamp:2022-08-17T02:27:12.883Z]],
			sec.diagnosticsInformation:[
				logType:[value:[errCode, dump],timestamp:2022-08-16T23:24:35.210Z], endpoint:[value:SSM,timestamp:2022-08-16T23:24:35.210Z], 
				minVersion:[value:1.0,timestamp:2022-08-16T23:24:35.210Z], setupId:[value:513,timestamp:2022-08-16T23:24:35.210Z], 
				protocolType:[value:wifi_https,timestamp:2022-08-16T23:24:35.210Z], mnId:[value:0AJT,timestamp:2022-08-16T23:24:35.210Z], 
				dumpType:[value:file,timestamp:2022-08-16T23:24:35.210Z]],
			temperatureMeasurement:[temperature:[value:null]],
			custom.deviceReportStateConfiguration:[
				reportStateRealtimePeriod:[value:null],reportStateRealtime:[value:[state:disabled],timestamp:2022-08-16T23:11:33.419Z], 
				reportStatePeriod:[value:enabled,timestamp:2022-08-16T23:11:33.419Z]],
			custom.waterFilter:[
				waterFilterUsageStep:[value:1,timestamp:2022-08-16T23:11:34.578Z],waterFilterResetType:[value:[replaceable],timestamp:2022-08-16T23:11:34.578Z], 
				waterFilterCapacity:[value:null],waterFilterLastResetDate:[value:null], waterFilterUsage:[value:8,timestamp:2022-09-02T21:39:16.144Z], 
				waterFilterStatus:[value:normal,timestamp:2022-08-16T23:11:34.578Z]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]],
		cvroom:[
			custom.fridgeMode:[fridgeModeValue:[value:null],fridgeMode:[value:null]], 
			contactSensor:[contact:[value:null]],
			custom.disabledCapabilities:[disabledCapabilities:[value:[temperatureMeasurement,thermostatCoolingSetpoint], timestamp:2022-08-16T23:11:32.877Z]],
			temperatureMeasurement:[temperature:[value:null]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]],
		icemaker-02:[custom.disabledCapabilities:[disabledCapabilities:[value:[],timestamp:2022-08-16T23:11:32.877Z]], switch:[switch:[value:null]]]]]


device: [
	deviceId:86cb4b57-bbc3-d180-d6ec-18b77edf6b70,
	name:[refrigerator]Samsung, label:Refrigerator, manufacturerName:Samsung Electronics,
	presentationId:DA-REF-NORMAL-01011, deviceManufacturerCode:SamsungElectronics, 
	locationId:432079f9-71ac-4ff9-bf40-325e5b713c51,ownerId:6fc2847b-c368-4c83-833b-7718ac6c6f5b,
	roomId:7dc2d560-0c56-49cc-ac4b-5761ba516784, deviceTypeName:Samsung OCFRefrigerator, 
	components:[
		[
			id:main, label:main,
			capabilities:[
				[id:contactSensor, version:1], 
				[id:execute, version:1],
				[id:ocf, version:1], 
				[id:powerConsumptionReport, version:1],
				[id:demandResponseLoadControl, version:1], 
				[id:refresh, version:1],
				[id:refrigeration, version:1], 
				[id:temperatureMeasurement, version:1],
				[id:thermostatCoolingSetpoint, version:1], 
				[id:custom.deodorFilter,version:1], 
				[id:custom.deviceReportStateConfiguration, version:1],
				[id:custom.energyType, version:1], 
				[id:custom.fridgeMode, version:1],
				[id:custom.disabledCapabilities, version:1], 
				[id:custom.disabledComponents,version:1], 
				[id:custom.waterFilter, version:1],
				[id:samsungce.softwareUpdate, version:1],
				[id:samsungce.deviceIdentification, version:1],
				[id:samsungce.driverVersion, version:1], 
				[id:samsungce.powerCool,version:1], 
				[id:samsungce.powerFreeze, version:1], 
				[id:samsungce.selfCheck,version:1], 
				[id:samsungce.viewInside, version:1],
				[id:sec.diagnosticsInformation, version:1]],
			categories:[
				[name:Refrigerator, categoryType:manufacturer],
				[name:Refrigerator, categoryType:manufacturer]]], 
		[id:freezer,label:freezer, 
		 capabilities:[
			 [id:contactSensor, version:1],[id:temperatureMeasurement, version:1], 
			 [id:thermostatCoolingSetpoint,version:1], [id:custom.disabledCapabilities, version:1],
			 [id:custom.fridgeMode, version:1], [id:custom.thermostatSetpointControl,version:1], 
			 [id:samsungce.temperatureSetting, version:1]],
		 categories:[[name:Other, categoryType:manufacturer]]], 
		[id:cooler,label:cooler, 
		 capabilities:[
			 [id:contactSensor, version:1],[id:temperatureMeasurement, version:1], 
			 [id:thermostatCoolingSetpoint,version:1], [id:custom.disabledCapabilities, version:1],
			 [id:custom.fridgeMode, version:1], [id:custom.thermostatSetpointControl,version:1], 
			 [id:samsungce.temperatureSetting, version:1]],
		 categories:[[name:Other, categoryType:manufacturer]]], 
		[id:cvroom,label:cvroom, c
		 apabilities:[
			 [id:contactSensor, version:1],[id:temperatureMeasurement, version:1], 
			 [id:thermostatCoolingSetpoint,version:1], [id:custom.disabledCapabilities, version:1],
			 [id:custom.fridgeMode, version:1]], categories:[[name:Other,categoryType:manufacturer]]], 
		[id:onedoor, label:onedoor,capabilities:[[id:contactSensor, version:1], [id:temperatureMeasurement,version:1], 
												 [id:thermostatCoolingSetpoint, version:1],[id:custom.disabledCapabilities, version:1], 
												 [id:custom.fridgeMode,version:1]], categories:[[name:Other, categoryType:manufacturer]]],
		[id:icemaker, label:icemaker, 
		 capabilities:[
			 [id:switch, version:1],[id:custom.disabledCapabilities, version:1]], 
		 categories:[[name:Other,categoryType:manufacturer]]], 
		[id:icemaker-02, label:icemaker-02,
		 capabilities:[[id:switch, version:1], [id:custom.disabledCapabilities,version:1]], 
		 categories:[[name:Other, categoryType:manufacturer]]],
		[id:scale-10, label:scale-10,
		 capabilities:[[id:samsungce.weightMeasurement, version:1], [id:samsungce.weightMeasurementCalibration, version:1],
					   [id:samsungce.connectionState, version:1], [id:custom.disabledCapabilities,version:1]], 
		 categories:[[name:Other, categoryType:manufacturer]]],
		[id:scale-11, label:scale-11,
		 capabilities:[[id:samsungce.weightMeasurement, version:1],[id:custom.disabledCapabilities, version:1]], 
		 categories:[[name:Other,categoryType:manufacturer]]], 
		[id:pantry-01, label:pantry-01,
		 capabilities:[[id:samsungce.fridgePantryInfo, version:1],[id:samsungce.fridgePantryMode, version:1], 
					   [id:samsungce.meatAging,version:1], [id:samsungce.foodDefrost, version:1],
					   [id:custom.disabledCapabilities, version:1]], categories:[[name:Other,categoryType:manufacturer]]], 
		[id:pantry-02, label:pantry-02,
		 capabilities:[[id:samsungce.fridgePantryInfo, version:1],[id:samsungce.fridgePantryMode, version:1], 
					   [id:samsungce.meatAging,version:1], [id:samsungce.foodDefrost, version:1],
					   [id:custom.disabledCapabilities, version:1]], categories:[[name:Other,categoryType:manufacturer]]]], 
	createTime:2022-08-16T23:11:32.571Z,profile:[id:2fc0c7f7-ff76-3a65-af53-3cdd7adc800e],
	ocf:[
		ocfDeviceType:oic.d.refrigerator, name:[refrigerator] Samsung,specVersion:core.1.1.0, verticalDomainSpecVersion:1.2.1,
		manufacturerName:Samsung Electronics,modelNumber:TP1X_REF_21K|00148242|00020253031611200103000031010000,platformVersion:DAWIT 2.0, 
		platformOS:TizenRT 3.1, hwVersion:Realtek,firmwareVersion:A-RFWW-TP1-22-REV1_20220604, vendorId:DA-REF-NORMAL-01011,
		vendorResourceClientServerVersion:Realtek Release 3.1.220422,lastSignupTime:2022-09-02T21:39:10.169219Z], type:OCF, restrictionTier:0,allowed:[]]










dongle : [
	components:[
		onedoor:[
			contactSensor:[contact:[value:null]],
			custom.disabledCapabilities:[disabledCapabilities:[value:null]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		cooler:[
			contactSensor:[contact:[value:closed, timestamp:2022-08-04T18:00:57.397Z]],
			custom.disabledCapabilities:[disabledCapabilities:[value:null]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value:37, unit:C, timestamp:2022-07-15T17:25:16.182Z]]], 
		freezer:[
			contactSensor:[contact:[value:closed, timestamp:2022-08-04T02:23:24.483Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		main:[
			custom.disabledComponents:[disabledComponents:[value:null]], 
			contactSensor:[contact:[value:null]], 
			ocf:[
				st:[value:null], mndt:[value:null], mnfv:[value:null], mnhw:[value:null], 
				di:[value:C0972783-A869-0000-0000-000000000000, timestamp:2022-07-15T17:25:16.460Z],
				mnsl:[value:null], 
				dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-07-15T17:25:16.460Z], 
				n:[value:Samsung Refrigerator, timestamp:2022-07-15T17:36:34.247Z], 
				mnmo:[value:DONGLE_0241|00089841|00020340051131200103000000000000, timestamp:2022-07-15T17:25:16.460Z], 
				vid:[value:DA-REF-NORMAL-100001, timestamp:2022-07-15T17:25:16.460Z], 
				mnmn:[value:Samsung Electronics, timestamp:2022-07-15T17:25:16.460Z], 
				mnml:[value:null], 
				mnpv:[value:null], 
				mnos:[value:null], 
				pi:[value:shp, timestamp:2022-07-15T17:25:16.460Z], 
				icv:[value:core.1.1.0, timestamp:2022-07-15T17:25:16.460Z]], 
			refrigeration:[
				defrost:[value:null], 
				rapidCooling:[value:off, timestamp:2022-07-15T17:25:16.063Z], 
				rapidFreezing:[value:off, timestamp:2022-07-15T17:25:16.063Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
			samsungce.driverVersion:[versionNumber:[value:21031201, timestamp:2022-07-15T17:25:16.063Z]], 
			refresh:[:], 
			execute:[data:[value:null]], 
			custom.waterFilter:[
				waterFilterUsageStep:[value:null], 
				waterFilterResetType:[value:null], 
				waterFilterCapacity:[value:null], 
				waterFilterLastResetDate:[value:null], 
				waterFilterUsage:[value:null], 
				waterFilterStatus:[value:normal, timestamp:2022-07-15T17:25:16.141Z]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		cvroom:[
			contactSensor:[contact:[value:closed, timestamp:2022-08-04T02:23:38.886Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]]]]

TP2X_REF_20K: [
	components:[
		pantry-01:[
			samsungce.fridgePantryInfo:[name:[value:null]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2022-04-25T16:09:43.901Z]], 
			samsungce.fridgePantryMode:[mode:[value:null], supportedModes:[value:null]]], 
		pantry-02:[
			samsungce.fridgePantryInfo:[name:[value:null]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2022-04-25T16:09:43.901Z]], 
			samsungce.fridgePantryMode:[mode:[value:null], supportedModes:[value:null]]], 
		icemaker:[
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2022-04-25T16:09:43.901Z]], 
			switch:[switch:[value:on, timestamp:2022-04-25T16:09:44.305Z]]], 
		onedoor:[
			custom.fridgeMode:[fridgeModeValue:[value:null], fridgeMode:[value:null]], 
			contactSensor:[contact:[value:null]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2022-04-25T16:09:43.901Z]], 
			temperatureMeasurement:[temperature:[value:null]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		cooler:[
			custom.fridgeMode:[fridgeModeValue:[value:null], fridgeMode:[value:null]], 
			contactSensor:[contact:[value:closed, timestamp:2022-05-06T02:57:03.456Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[custom.fridgeMode], timestamp:2022-04-25T16:09:43.901Z]], 
			temperatureMeasurement:[temperature:[value:3, unit:C, timestamp:2022-04-25T16:09:44.114Z]], 
			custom.thermostatSetpointControl:[minimumSetpoint:[value:1, unit:C, timestamp:2022-04-25T16:09:44.114Z], 
											  maximumSetpoint:[value:7, unit:C, timestamp:2022-04-25T16:09:44.114Z]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:3, unit:C, timestamp:2022-04-25T16:09:44.114Z]]], 
		freezer:[
			custom.fridgeMode:[fridgeModeValue:[value:null], fridgeMode:[value:null]], 
			contactSensor:[contact:[value:closed, timestamp:2022-05-06T02:56:34.725Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[custom.fridgeMode], timestamp:2022-04-25T16:09:43.901Z]], 
			temperatureMeasurement:[temperature:[value:-18, unit:C, timestamp:2022-04-25T16:09:44.114Z]], 
			custom.thermostatSetpointControl:[minimumSetpoint:[value:-23, unit:C, timestamp:2022-04-25T16:09:44.114Z], 
											  maximumSetpoint:[value:-15, unit:C, timestamp:2022-04-25T16:09:44.114Z]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:-18, unit:C, timestamp:2022-04-25T16:09:44.114Z]]], 
		main:[
			custom.disabledComponents:[
				disabledComponents:[value:[cvroom, onedoor, icemaker-02, pantry-01, pantry-02], timestamp:2022-04-25T16:09:46.151Z]], 
			demandResponseLoadControl:[drlcStatus:[value:[drlcType:1, drlcLevel:0, duration:0, override:true], timestamp:2022-04-25T16:09:44.308Z]], 
			contactSensor:[contact:[value:closed, timestamp:2022-05-06T02:57:03.456Z]], 
			powerConsumptionReport:[
				powerConsumption:[value:[energy:76131, deltaEnergy:8, power:94, powerEnergy:0.8900433333714803, persistedEnergy:0, 
										 energySaved:0, start:2022-05-06T02:48:54Z, end:2022-05-06T03:02:15Z], 
								  timestamp:2022-05-06T03:02:15.047Z]], 
			refresh:[:], 
			samsungce.dongleSoftwareInstallation:[status:[value:completed, timestamp:2022-04-25T16:09:43.901Z]], 
			execute:[data:[value:[payload:[rt:[x.com.samsung.da.energyconsumption], if:[oic.if.baseline, oic.if.a], 
										   x.com.samsung.da.cumulativeConsumption:10741, x.com.samsung.da.cumulativePower:76131, x.com.samsung.da.cumulativeUnit:Wh, 
										   x.com.samsung.da.instantaneousPower:94, x.com.samsung.da.instantaneousPowerUnit:W, x.com.samsung.da.monthlyConsumption:4800, 
										   x.com.samsung.da.thismonthlyConsumption:4531]], data:[href:/energy/consumption/vs/0], timestamp:2022-05-06T03:02:15.047Z]], 
			samsungce.deviceIdentification:[micomAssayCode:[value:null], modelName:[value:null], serialNumber:[value:null], serialNumberExtra:[value:null], 
											modelClassificationCode:[value:null], description:[value:null], binaryId:[value:TP2X_REF_20K, timestamp:2022-04-25T16:09:45.661Z]], 
			custom.fridgeMode:[
				fridgeModeValue:[value:null], fridgeMode:[value:null]], 
			ocf:[
				st:[value:null], 
				mndt:[value:null], 
				mnfv:[value:A-RFWW-TP2-21-COMMON_20211110, timestamp:2022-04-25T16:34:01.648Z], 
				mnhw:[value:MediaTek, timestamp:2022-04-25T16:09:45.756Z], 
				di:[value:d805b7af-d6b1-d084-60ca-2a33e0d4a8a4, timestamp:2022-04-25T16:09:45.756Z], 
				mnsl:[value:http:www.samsung.com, timestamp:2022-04-25T16:09:45.756Z], dmv:[value:1.2.1, timestamp:2022-04-25T16:15:38.520Z], 
				n:[value:[refrigerator] Samsung, timestamp:2022-04-25T16:09:45.756Z], 
				mnmo:[value:TP2X_REF_20K|00144441|0002023E011511200103000030000000, timestamp:2022-04-25T16:09:45.756Z], 
				vid:[value:DA-REF-NORMAL-000001, timestamp:2022-04-25T16:09:45.756Z], 
				mnmn:[value:Samsung Electronics, timestamp:2022-04-25T16:09:45.756Z], 
				mnml:[value:http:www.samsung.com, timestamp:2022-04-25T16:09:45.756Z], 
				mnpv:[value:DAWIT 2.0, timestamp:2022-04-25T16:09:45.756Z], 
				mnos:[value:TizenRT 1.0 + IPv6, timestamp:2022-04-25T16:09:45.756Z], 
				pi:[value:d805b7af-d6b1-d084-60ca-2a33e0d4a8a4, timestamp:2022-04-25T16:09:45.756Z], 
				icv:[value:core.1.1.0, timestamp:2022-04-25T16:09:45.756Z]], 
			refrigeration:[
				defrost:[value:off, timestamp:2022-04-25T16:09:44.738Z], 
				rapidCooling:[value:off, timestamp:2022-04-25T16:09:44.308Z], 
				rapidFreezing:[value:off, timestamp:2022-04-25T16:09:44.308Z]], 
			custom.deodorFilter:[
				deodorFilterLastResetDate:[value:null], 
				deodorFilterCapacity:[value:null], 
				deodorFilterStatus:[value:null], 
				deodorFilterResetType:[value:null], 
				deodorFilterUsage:[value:null], d
				eodorFilterUsageStep:[value:null]], 
			samsungce.powerCool:[
				activated:[value:false, timestamp:2022-04-25T16:09:44.308Z]],
			custom.energyType:[
				energyType:[value:2.0, timestamp:2022-04-25T16:09:43.901Z], 
				energySavingSupport:[value:false, timestamp:2022-04-25T16:21:45.391Z], 
				drMaxDuration:[value:1440, unit:min, timestamp:2022-04-25T16:09:44.308Z], 
				energySavingOperation:[value:null], 
				energySavingOperationSupport:[value:false, timestamp:2022-04-25T16:09:44.308Z]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[
					value:[custom.deodorFilter, samsungce.dongleSoftwareInstallation, demandResponseLoadControl], 
					timestamp:2022-04-25T16:09:46.151Z]], 
			samsungce.softwareUpdate:[
				otnDUID:[value:JHCNQWBWQZCH4, timestamp:2022-04-25T16:09:45.661Z], 
				availableModules:[value:[], timestamp:2022-04-25T16:09:45.661Z], 
				newVersionAvailable:[value:false, timestamp:2022-04-25T16:09:44.482Z]], 
			samsungce.driverVersion:[versionNumber:[value:22010301, timestamp:2022-04-25T16:09:43.901Z]], 
			samsungce.powerFreeze:[activated:[value:false, timestamp:2022-04-25T16:09:44.308Z]], 
			temperatureMeasurement:[temperature:[value:null]], 
			custom.deviceReportStateConfiguration:[reportStateRealtimePeriod:[value:null], 
												   reportStateRealtime:[value:[state:disabled], timestamp:2022-05-06T02:04:57.520Z], 
												   reportStatePeriod:[value:enabled, timestamp:2022-04-25T16:09:45.815Z]], 
			custom.waterFilter:[
				waterFilterUsageStep:[value:1, timestamp:2022-04-25T16:09:44.247Z], 
				waterFilterResetType:[value:[replaceable], timestamp:2022-04-25T16:09:44.247Z], 
				waterFilterCapacity:[value:null], waterFilterLastResetDate:[value:null], 
				waterFilterUsage:[value:36, timestamp:2022-05-06T01:32:27.755Z], 
				waterFilterStatus:[value:normal, timestamp:2022-04-25T16:09:44.247Z]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		cvroom:[
			custom.fridgeMode:[fridgeModeValue:[value:null], fridgeMode:[value:null]], 
			contactSensor:[contact:[value:null]], 
			custom.disabledCapabilities:
			[disabledCapabilities:[value:[temperatureMeasurement, thermostatCoolingSetpoint], timestamp:2022-04-25T16:09:43.901Z]], 
			temperatureMeasurement:[temperature:[value:null]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:null]]], 
		icemaker-02:[
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2022-04-25T16:09:43.901Z]], 
			switch:[switch:[value:null]]]]]]

*/

