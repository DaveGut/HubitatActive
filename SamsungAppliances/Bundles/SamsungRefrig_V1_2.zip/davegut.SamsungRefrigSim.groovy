library (
	name: "Samsung-Refrig-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Simulator - Samsung Refrigerator",
	category: "utilities",
	documentationLink: ""
)

def testData() {
/*
//	main
	def mainContact = "closed"
	def defrost = "off"
	def rapidCooling = "off"
	def rapidFreezing = "off"
	def filterReplace = "replace"
	def SabbathMode = "On"
	
//	cooler
	def tempUnit = "C"
	def coolerContact = "closed"
	def coolerTemperature = 35
	def coolerSetpoint = 30
//	freezer
	def freezerContact = "closed"
	def freezerTemperature = 36
	def freezerSetpoint = 31
//	cvroom
	def drawerMode = "CV_FDR_MEAT"
	def drawerContact = "closed"
//	icemaker
	def onOff = "on"
*/

//	main
	def mainContact = "open"
	def defrost = "on"
	def rapidCooling = "on"
	def rapidFreezing = "on"
	def filterReplace = "ok"
	def SabbathMode = "On"
//	cooler
	def tempUnit = "F"
	def coolerContact = "open"
	def coolerTemperature = 32
	def coolerSetpoint = 32
//	freezer
	def freezerContact = "open"
	def freezerTemperature = 33
	def freezerSetpoint = 33
//	cvroom
	def drawerMode = "CV_FDR_VEG"
	def drawerContact = "open"
//	icemaker
	def onOff = "off"

/*
//	main
	def mainContact = null
	def defrost = null
	def rapidCooling = null
	def rapidFreezing = null
	def filterReplace = null
	def SabbathMode = "Off"
//	cooler
	def tempUnit = null
	def coolerContact = null
	def coolerTemperature = null
	def coolerSetpoint = null
//	freezer
	def freezerContact = null
	def freezerTemperature = null
	def freezerSetpoint = null
//	cvroom
	def drawerMode = null
	def drawerContact = null
//	icemaker
	def onOff = null
*/	
	
	
	return [components:[
		icemaker:[
			switch:[switch:[value: onOff]]],
		cooler:[
			contactSensor:[contact:[value: coolerContact]],
			temperatureMeasurement:[temperature:[value: coolerTemperature, unit: tempUnit]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value: coolerSetpoint, unit: tempUnit]]],
		freezer:[
			contactSensor:[contact:[value: freezerContact]],
			temperatureMeasurement:[temperature:[value: freezerTemperature, unit: tempUnit]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value: freezerSetpoint, unit: tempUnit]]],
		main:[
			ocf:[
				mnmo:[value:"TP2X_REF_20K|00144441|0002023E011511200103000030000000"]], 
			"custom.disabledComponents":[disabledComponents:[
				value:["icemaker-02", "pantry-01", "pantry-02"]]], 
			temperatureMeasurement:[temperature:[value: coolerTemperature, unit: tempUnit]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value: coolerSetpoint, unit: tempUnit]],
			contactSensor:[contact:[value: mainContact]], 
			refrigeration:[
				defrost:[value: defrost], 
				rapidCooling:[value: rapidCooling], 
				rapidFreezing:[value: rapidFreezing]], 
			"custom.waterFilter":[waterFilterStatus:[value: filterReplace]],
			execute:[data:[value:[payload:["x.com.samsung.da.sabbathMode": SabbathMode]]]]], 
		cvroom:[
			"custom.fridgeMode":[fridgeMode:[value: drawerMode]], 
			contactSensor:[contact:[value: drawerContact]],
			temperatureMeasurement:[temperature:[value: coolerTemperature, unit: tempUnit]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value: coolerSetpoint, unit: tempUnit]]],
		onedoor:[
			contactSensor:[contact:[value:drawerContact]],
			temperatureMeasurement:[temperature:[value: coolerTemperature, unit: tempUnit]], 
			thermostatCoolingSetpoint:[coolingSetpoint:[value:coolerSetpoint, unit: tempUnit]]],
		"pantry-01":[],
		"pantry-02":[],
		"icemaker-02":[]
	]]
}

def testResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
