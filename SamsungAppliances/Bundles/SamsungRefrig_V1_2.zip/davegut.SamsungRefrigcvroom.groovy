/*	Samsung Refrigerator CV Room using SmartThings Interfae
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This is a child driver to Samsung Oven and will not work indepenently of same.
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Refrig cvroom",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Refrig_cvroom.groovy"
			   ){
		capability "Temperature Measurement"
		capability "Thermostat Cooling Setpoint"
		capability "Contact Sensor"
		attribute "mode", "string"
	}
	preferences {
		input ("infoLog", "bool",  
			   title: "Enable info logging", defaultValue: true)
		input ("debugLog", "bool",  
			   title: "Enable debug logging for 30 minutes", defaultValue: false)
	}
}

def installed() {
	runIn(1, updated)
}

def updated() {
	def logData = [:]
	if (driverVer() != parent.driverVer()) {
		logWarn("updated: Child driver version does not match parent.")
	}
	if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		logData << [driverVersion: driverVer()]
	}
	if (logData != [:]) {
		logInfo("updated: ${logData}")
	}
}

def setCoolingSetpoint(setpoint) {
	def cmdData = [
		component: getDataValue("component"),
		capability: "thermostatCoolingSetpoint",
		command: "setCoolingSetpoint",
		arguments: [setpoint]]
	def cmdStatus = parent.deviceCommand(cmdData)
	logInfo("setCoolingSetpoint: [cmd: ${setpoint}, ${cmdStatus}]")
}

def statusParse(respData) {
	def parseData
	try {
		parseData = respData.components.cvroom
	} catch (error) {
		logWarn("statusParse: [respData: ${respData}, error: ${error}]")
	}

	def contact = parseData.contactSensor.contact.value
	sendEvent(name: "contact", value: contact)

	def tempUnit = parseData.thermostatCoolingSetpoint.coolingSetpoint.unit
	def coolingSetpoint = parseData.thermostatCoolingSetpoint.coolingSetpoint.value
	sendEvent(name: "coolingSetpoint", value: coolingSetpoint, unit: tempUnit)
	
	if (parent.getDataValue("dongle") == "false") {
		def temperature = parseData.temperatureMeasurement.temperature.value
		sendEvent(name: "temperature", value: temperature, unit: tempUnit)

		def mode = parseData["custom.fridgeMode"].fridgeMode.value
		sendEvent(name: "mode", value: mode)
	}
	
	if (parent.simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
