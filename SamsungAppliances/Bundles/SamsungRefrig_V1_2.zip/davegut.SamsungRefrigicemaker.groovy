/*	Samsung Refrigerator Icemaker using SmartThings Interface
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This is a child driver to Samsung Oven and will not work indepenently of same.
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Refrig icemaker",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Refrig_icemaker.groovy"
			   ){
		capability "Switch"
	}
	preferences {
		input ("infoLog", "bool",  
			   title: "Enable info logging", defaultValue: true)
		input ("debugLog", "bool",  
			   title: "Enable debug logging for 30 minutes", defaultValue: false)
	}
}

def installed() {
	runIn(1, updated)
}

def updated() {
	def logData = [:]
	if (driverVer() != parent.driverVer()) {
		logWarn("updated: Child driver version does not match parent.")
	}
	if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		logData << [driverVersion: driverVer()]
	}
	if (logData != [:]) {
		logInfo("updated: ${logData}")
	}
}

def on() { setSwitch("on") }
def off() { setSwitch("off") }
def setSwitch(onOff) {
	def cmdData = [
		component: getDataValue("component"),
		capability: "switch",
		command: onOff,
		arguments: []]
	def cmdStatus = parent.deviceCommand(cmdData)
	logInfo("setOnOff: [cmd: ${onOff}, ${cmdStatus}]")
}

def statusParse(respData) {
	def parseData
	def componentId = getDataValue("component")
	try {
		parseData = respData.components[componentId]
	} catch (error) {
		logWarn("statusParse: [respData: ${respData}, error: ${error}]")
	}

	def onOff = parseData.switch.switch.value
	sendEvent(name: "switch", value: onOff)

	if (parent.simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
