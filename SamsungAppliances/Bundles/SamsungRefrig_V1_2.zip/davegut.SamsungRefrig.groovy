/*	Samsung Refrigerator using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung Refrigerators for import of control
and status of defined functions into Hubitat Environment.
=====	Library Use
This driver uses libraries for the functions common to SmartThings devices. 
Library code is at the bottom of the distributed single-file driver.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2T" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Refrig",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Refrig.groovy"
			   ){
		capability "Refresh"
		capability "Contact Sensor"
		capability "Temperature Measurement"
		capability "Thermostat Cooling Setpoint"
		capability "Filter Status"
		command "setRapidCooling", [[
			name: "Rapid Cooling",
			constraints: ["on", "off"],
			type: "ENUM"]]
		attribute "rapidCooling", "string"
		command "setRapidFreezing", [[
			name: "Rapid Freezing",
			constraints: ["on", "off"],
			type: "ENUM"]]
		attribute "rapidFreezing", "string"
		command "defrost", [[
			name: "Defrost",
			constraints: ["on", "off"],
			type: "ENUM"]]
		attribute "defrost", "string"
	}
	
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["10sec", "20sec", "30sec", "1", "5", "10", "30"], defaultValue: "10")
			input ("infoLog", "bool",  
				   title: "Enable info logging", defaultValue: true)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() { }

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "FAILED") {
		logWarn("updated: ${commonStatus}")
	} else {
		logInfo("updated: ${commonStatus}")
		deviceSetup()
	}
}

def setCoolingSetpoint(setpoint) {
	def cmdData = [
		component: getDataValue("component"),
		capability: "thermostatCoolingSetpoint",
		command: "setCoolingSetpoint",
		arguments: [setpoint]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setCoolingSetpoint: [cmd: ${setpoint}, ${cmdStatus}]")
}

def setRapidCooling(onOff) {
	setRefrigeration("setRapidCooling", onOff)
}
def setRapidFreezing(onOff) {
	setRefrigeration("setRapidFreezing", onOff)
}
def defrost(onOff) {
	setRefrigeration("setDefrost", onOff)
}
def setRefrigeration(command, onOff) {
	def cmdData = [
		component: getDataValue("component"),
		capability: "refrigeration",
		command: command,
		arguments: [onOff]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setRefrigeration: [cmd ${command}, onOff: ${onOff}, status: ${cmdStatus}]")
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData)
			} else {
				def children = getChildDevices()
				children.each {
						it.statusParse(respData)
				}
				statusParse(respData)
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(respData) {
	logInfo("deviceSetpParse")
	def respLog = [:]
	if (!getDataValue("dongle")) {
		def dongle = "false"
		def mnmo = respData.components.main.ocf.mnmo
		if (mnmo != null && mnmo.value.contains("DONGLE")) {
			dongle = "true"
		}
		updateDataValue("dongle", dongle)
		respLog << [dongle: dongle]
	}
	//	Install Children
	def compData = respData.components
	def disabledComponents = compData.main["custom.disabledComponents"].disabledComponents.value
	compData.each {
		if (it.key != "main") {
			def childDni = dni + "-${it.key}"
			def isChild = getChildDevice(childDni)
			if (!isChild) {
				if(!disabledComponents.contains(it.key)) {
					respLog << ["${it.key}": "Installing"]
					addChild(it.key, childDni)
				} else {
					respLog << ["${it.key}": "Disabled"]
				}
			}
		} else {
			updateDataValue("component", "main")
		}
	}
	logInfo("deviceSetupParse: ${respLog}")
}

def addChild(component, childDni) {
	def type
	switch(component) {
		case "freezer":
		case "cooler":
		case "onedoor":
			type = "Samsung Refrig cavity"
			break
		case "icemaker":
		case "icemaker-02":
			type = "Samsung Refrig icemaker"
			break
		case "cvroom":
			type = "Samsung Refrig cvroom"
			break
		default:
			logWarn("addChild: [component: ${component}, error: component not implemented.")
	}
	try {
		addChildDevice("davegut", "${type}", "${childDni}", [
			"name": type, "label": component, component: component])
		logInfo("addChild: [status: ADDED, label: ${component}, type: ${type}]")
	} catch (error) {
		logWarn("addChild: [status: FAILED, type: ${type}, dni: ${childDni}, component: ${component}, error: ${error}]")
	}
}

def statusParse(respData) {
	def parseData
	try {
		parseData = respData.components.main
	} catch (error) {
		logWarn("statusParse: [respData: ${respData}, error: ${error}]")
		return
	}

	def contact = parseData.contactSensor.contact.value
	sendEvent(name: "contact", value: contact)

	def tempUnit = parseData.thermostatCoolingSetpoint.coolingSetpoint.unit
	def coolingSetpoint = parseData.thermostatCoolingSetpoint.coolingSetpoint.value
	sendEvent(name: "coolingSetpoint", value: coolingSetpoint, unit: tempUnit)

	if (getDataValue("dongle") == "false") {
		def temperature = parseData.temperatureMeasurement.temperature.value
		sendEvent(name: "temperature", value: temperature, unit: tempUnit)
		
		def SabbathMode = parseData.execute.data.value.payload["x.com.samsung.da.sabbathMode"]
		sendEvent(name: "SabbathMode", value: SabbathMode)
	}

	def defrost = parseData.refrigeration.defrost.value
	sendEvent(name: "defrost", value: defrost)

	def rapidCooling = parseData.refrigeration.rapidCooling.value
	sendEvent(name: "rapidCooling", value: rapidCooling)

	def rapidFreezing = parseData.refrigeration.rapidFreezing.value
	sendEvent(name: "rapidFreezing", value: rapidFreezing)

	def filterStatus = parseData["custom.waterFilter"].waterFilterStatus.value
	sendEvent(name: "filterStatus", value: filterStatus)
	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Refrig-Sim
//#include davegut.Samsung-Refrig-Sim-DONGLE
