/*	Samsung Soundbar using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung Soundbars for import of control
and status of defined functions into Hubitat Environment.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Oven",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Oven.groovy"
			   ){
		capability "Refresh"
		capability "Contact Sensor"
		capability "Thermostat Setpoint"
		capability "Temperature Measurement"
		command "pauseOven"
		command "runOven"
		command "stopOven"
		command "setOvenSetpoint", ["NUMBER"]
		attribute "kidsLock", "string"
		attribute "cooktopState", "string"
		attribute "remoteControl", "string"
		attribute "completionTime", "string"
		attribute "timeRemaining", "string"
		attribute "ovenState", "string"
		attribute "jobState", "string"
		attribute "ovenMode", "string"
	}

	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["10sec", "20sec", "30sec", "1", "5", "10", "30"], defaultValue: "10")
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: false)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() { }

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "FAILED") {
		logWarn("updated: ${commonStatus}")
	} else {
		logInfo("updated: ${commonStatus}")
		def children = getChildDevices()
		if (children == []) {
			installChildren()
		} else {
			children.each {
				it.updated()
			}
		}
	}
}

def pauseOven() {
	setMachineState("paused", "main")
}
def runOven() {
	setMachineState("running", "main")
}
def setMachineState(machineState, component) {
	def cmdData = [
		component: component,
		capability: "ovenOperatingState",
		command: "setMachineState",
		arguments: [machineState]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMachineState: [comp: ${component}, state: ${machineState}, status: ${cmdStatus}]")
}

def stopOven(component = "main") {
	def cmdData = [
		component: component,
		capability: "ovenOperatingState",
		command: "stop",
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("stopOven: [comp: ${component}, status: ${cmdStatus}]")
}

def setOvenSetpoint(setpoint, component = "main") {
	def cmdData = [
		component: component,
		capability: "ovenSetpoint",
		command: "setOvenSetpoint",
		arguments: [setpoint]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setOvenSetpoint: [comp: ${component}, setpoint: ${setpoint}, status: ${cmdStatus}]")
}

def distResp(resp, data) {
	def respLog = "OK"
	def respData
	if (resp.status == 200) {
		try {
			respData = new JsonSlurper().parseText(resp.data)
		} catch (err) {
			respLog = [status: "ERROR", errorMsg: err, respData: resp.data]
		}
	} else {
		respLog = [status: "ERROR", httpCode: resp.status, errorMsg: resp.errorMessage]
	}
	if (respLog == "OK") {
		def children = getChildDevices()
		children.each {
			it.statusParse(respData)
		}
		statusParse(respData)
	} else {
		logWarn("validateResp: ${respLog}")
	}
}

def statusParse(respData) {
	try {
		respData = respData.components.main
	} catch (error) {
		logWarn("statusParse: [respData: ${respData}, error: ${error}]")
		return
	}
	def tempUnit = respData.temperatureMeasurement.temperature.unit
	def temperature = respData.temperatureMeasurement.temperature.value
	sendEvent(name: "temperature", value: temperature, unit: tempUnit)
	
	def thermostatSetpoint = respData.ovenSetpoint.ovenSetpoint.value
	sendEvent(name: "thermostatSetpoint", value: thermostatSetpoint, unit: tempUnit)
	
	def completionTime = respData.ovenOperatingState.completionTime.value
	if (completionTime != null) {
		sendEvent(name: "completionTime", value: completionTime)
		def timeRemaining = calcTimeRemaining(completionTime)
		sendEvent(name: "timeRemaining", value: timeRemaining)
		if (timeRemaining == 0 && state.pollInterval == "1") {
			setPollInterval("10")
		} else if (timeRemaining > 0 && state.pollInterval == "10") {
			setPollInterval("1")
		}
	}
	
	def kidsLock = respData["samsungce.kidsLock"].lockState.value
	sendEvent(name: "kidsLock", value: kidsLock)

	def cooktopState = respData["custom.cooktopOperatingState"].cooktopOperatingState.value
	sendEvent(name: "cooktopState", value: cooktopState)

	def remoteControl = respData.remoteControlStatus.remoteControlEnabled.value
	sendEvent(name: "remoteControl", value: remoteControl)

	def contact = respData["samsungce.doorState"].doorState.value
	sendEvent(name: "contact", value: contact)

	def ovenState = respData.ovenOperatingState.machineState.value
	sendEvent(name: "ovenState", value: ovenState)

	def jobState = respData.ovenOperatingState.ovenJobState.value
	sendEvent(name: "jobState", value: jobState)

	def ovenMode = respData.ovenMode.ovenMode.value
	sendEvent(name: "ovenMode", value: ovenMode)
	
	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Common Oven Parent/Child API Commands =====
//	===== Child Installation =====
def installChildren() {
	addChild("probe")
	pauseExecution(500)
	addChild("cavity")
	device.updateSetting("childInstall", [type:"bool", value: false])
}

def addChild(component) {
	def dni = device.getDeviceNetworkId()
	def childDni = dni + "-${component}"
	def isChild = getChildDevice(childDni)
	if (isChild) {
		logInfo("installChildren: [component: ${component}, status: already installed]")
	} else {
		def type = "Samsung Oven ${component}"
		try {
			addChildDevice("davegut", "${type}", "${childDni}", [
				"name": type, "label": component, component: component])
			logInfo("addChild: [status: ADDED, label: ${component}, type: ${type}]")
		} catch (error) {
			logWarn("addChild: [status: FAILED, type: ${type}, dni: ${childDni}, component: ${component}, error: ${error}]")
		}
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Oven-Sim
