metadata {
	definition (name: "Z Oven-Range Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

//	========================================================
//	===== Installation, setup and update ===================
//	========================================================
//NO CAVITY
//Test 1:
//data:[components:[cavity-01:[ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2021-12-14T19:25:30.534Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2021-12-14T19:25:30.534Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z], operatingState:[value:ready, timestamp:2021-12-14T19:25:30.821Z], progress:[value:1, timestamp:2021-12-14T19:25:30.821Z], ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z], operationTime:[value:00:00:00, timestamp:2021-12-14T19:25:30.821Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]], custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2022-04-12T18:54:48.890Z]], ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:Others, timestamp:2021-12-14T19:25:30.779Z]], ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z], machineState:[value:ready, timestamp:2021-12-14T19:25:30.821Z], progress:[value:1, unit:%, timestamp:2021-12-14T19:25:30.821Z], supportedMachineStates:[value:null], ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z], operationTime:[value:0, timestamp:2021-12-14T19:25:30.821Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:NoOperation, timestamp:2021-12-14T19:25:30.779Z]]], main:[ovenSetpoint:[ovenSetpoint:[value:425, timestamp:2022-04-12T18:56:06.618Z]], samsungce.meatProbe:[temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]], refresh:[:], samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-12T18:54:54.499Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.mode], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.supportedModes:[HOMECARE_WIZARD_V2, Bake, Broil, ConvectionBake, ConvectionRoast, UpperBroil, UpperConvectionBake, UpperConvectionRoast, LowerBake, LowerConvectionBake, KeepWarm, BreadProof, Dehydrate, AirFryer, SteamClean, SelfClean, NoOperation], x.com.samsung.da.defaultMode:ConvectionBake, x.com.samsung.da.modeSpec:[{"mode":"Bake","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"80","tempMaxC":"285","tempDefaultC":"175","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"350","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"Broil","version":"0000","default":"Normal","control":"Setting","cavity":"Single","tempMinC":"61442","tempMaxC":"61441","tempDefaultC":"61441","tempListLengthC":"0","tempMinF":"61442","tempMaxF":"61441","tempDefaultF":"61441","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"ConvectionBake","version":"0000","default":"Default","control":"Start&Setting","cavity":"Single","tempMinC":"80","tempMaxC":"285","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"325","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"ConvectionRoast","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"80","tempMaxC":"285","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"550","tempDefaultF":"325","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"UpperBroil","version":"0000","default":"Normal","control":"NotSupported","cavity":"Upper","tempMinC":"61442","tempMaxC":"61441","tempDefaultC":"61441","tempListLengthC":"0","tempMinF":"61442","tempMaxF":"61441","tempDefaultF":"61441","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"UpperConvectionBake","version":"0000","default":"Default","control":"Start&Setting","cavity":"Upper","tempMinC":"80","tempMaxC":"250","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"480","tempDefaultF":"325","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"UpperConvectionRoast","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Upper","tempMinC":"80","tempMaxC":"250","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"480","tempDefaultF":"325","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"LowerBake","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Lower","tempMinC":"80","tempMaxC":"250","tempDefaultC":"175","tempListLengthC":"0","tempMinF":"175","tempMaxF":"480","tempDefaultF":"350","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"LowerConvectionBake","version":"0000","default":"Default","control":"Start&Setting","cavity":"Lower","tempMinC":"80","tempMaxC":"250","tempDefaultC":"160","tempListLengthC":"0","tempMinF":"175","tempMaxF":"480","tempDefaultF":"325","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"KeepWarm","version":"0000","default":"Normal","control":"NotSupported","cavity":"Single","tempMinC":"80","tempMaxC":"80","tempDefaultC":"80","tempListLengthC":"0","tempMinF":"175","tempMaxF":"175","tempDefaultF":"175","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"BreadProof","version":"0000","default":"Normal","control":"NotSupported","cavity":"Single","tempMinC":"35","tempMaxC":"35","tempDefaultC":"35","tempListLengthC":"0","tempMinF":"95","tempMaxF":"95","tempDefaultF":"95","tempListLengthF":"0","timeMin":"NotSupported","timeMax":"NotSupported","timeDefault":"NotSupported","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"Dehydrate","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"40","tempMaxC":"105","tempDefaultC":"65","tempListLengthC":"0","tempMinF":"100","tempMaxF":"225","tempDefaultF":"150","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"AirFryer","version":"0000","default":"Normal","control":"Start&Setting","cavity":"Single","tempMinC":"175","tempMaxC":"260","tempDefaultC":"220","tempListLengthC":"0","tempMinF":"350","tempMaxF":"500","tempDefaultF":"425","tempListLengthF":"0","timeMin":"00:01:00","timeMax":"09:59:00","timeDefault":"01:00:00","probeMinC":"NotSupported","probeMaxC":"NotSupported","probeDefaultC":"NotSupported","probeMinF":"NotSupported","probeMaxF":"NotSupported","probeDefaultF":"NotSupported","powerDefault":"NotSupported","powerListLength":"0"},{"mode":"SteamClean","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0","tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0","tempListLengthF":"0","timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0","probeDefaultC":"0","probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"},{"mode":"SelfClean","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0","tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0","tempListLengthF":"0","timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0","probeDefaultC":"0","probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"},{"mode":"NoOperation","version":"0000","default":"NotSupported","control":"NotSupported","cavity":"Lower","tempMinC":"0","tempMaxC":"0","tempDefaultC":"0","tempListLengthC":"0","tempMinF":"0","tempMaxF":"0","tempDefaultF":"0","tempListLengthF":"0","timeMin":"00:00:00","timeMax":"00:00:00","timeDefault":"00:00:00","probeMinC":"0","probeMaxC":"0","probeDefaultC":"0","probeMinF":"0","probeMaxF":"0","probeDefaultF":"0","powerDefault":"(null)","powerListLength":"0"}], x.com.samsung.da.modes:[AirFryer], x.com.samsung.da.options:[DeviceType_NY9803T-/AA0, SettingPossible_7, keepWarmReservation_Off, meatprobe_disconnected, fastpreheat_Not_Supported, UpperTimerCurrent_0, UpperTimerSet_0, UpperTimerState_Ready, UpperLamp_Off, waterInlet_NotSupported, drain_NotSupported, ShowerLighting_NotSupported, ScreenTimeOut_NotSupported, Sound_On, RecipeConversion_Off, AdjustingTemp_0, VirtualFlame_NotSupported, Sabbath_Off, EnergySaving_Off, WarmingCenter_Off, Lamp_NotSupported, ShutOffTimerState_Ready]]], data:[href:/mode/vs/0], timestamp:2022-04-12T18:58:44.870Z]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:A-RG-WW-TP2-21-COMM_40210802, timestamp:2021-12-14T19:25:32.064Z], mnhw:[value:MediaTek, timestamp:2021-12-14T19:25:32.064Z], di:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], mnsl:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], dmv:[value:1.2.1, timestamp:2021-12-14T19:25:37.714Z], n:[value:[Range] Samsung, timestamp:2021-12-14T19:25:32.064Z], mnmo:[value:TP2X_DA-KS-RANGE-0101X|40434141|5001021E03141151020000000000000, timestamp:2021-12-14T19:25:32.064Z], vid:[value:DA-KS-RANGE-0101X, timestamp:2021-12-14T19:25:32.064Z], mnmn:[value:Samsung Electronics, timestamp:2021-12-14T19:25:32.064Z], mnml:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], mnpv:[value:DAWIT 2.0, timestamp:2021-12-14T19:25:32.064Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-12-14T19:25:32.064Z], pi:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], icv:[value:core.1.1.0, timestamp:2021-12-14T19:25:32.064Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]], samsungce.customRecipe:[:], samsungce.kitchenDeviceIdentification:[regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], modelCode:[value:NY9803T-/AA0, timestamp:2021-12-14T19:25:29.505Z], type:[value:range, timestamp:2021-12-14T19:25:29.505Z]], samsungce.kitchenModeSpecification:[specification:[value:[single:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:175, resolution:5], F:[min:175, max:550, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:Broil, supportedOperations:[set], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:KeepWarm, supportedOperations:[], supportedOptions:[temperature:[C:[min:80, max:80, default:80, resolution:5], F:[min:175, max:175, default:175, resolution:5]]]], [mode:BreadProof, supportedOperations:[], supportedOptions:[temperature:[C:[min:35, max:35, default:35, resolution:5], F:[min:95, max:95, default:95, resolution:5]]]], [mode:Dehydrate, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:40, max:105, default:65, resolution:5], F:[min:100, max:225, default:150, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:AirFryer, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:175, max:260, default:220, resolution:5], F:[min:350, max:500, default:425, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], upper:[[mode:Broil, supportedOperations:[], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], lower:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:175, resolution:5], F:[min:175, max:480, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:SteamClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:SelfClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:NoOperation, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]]]], timestamp:2021-12-14T19:25:32.622Z]], custom.cooktopOperatingState:[supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z], cooktopOperatingState:[value:run, timestamp:2022-04-12T18:55:07.336Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]], temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-09T16:35:22.265Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-12T18:56:06.435Z, timestamp:2022-04-12T18:56:06.444Z], operatingState:[value:running, timestamp:2022-04-12T18:56:06.444Z], progress:[value:1, timestamp:2022-03-25T19:17:36.737Z], ovenJobState:[value:cooking, timestamp:2022-04-12T18:56:06.515Z], operationTime:[value:00:00:00, timestamp:2022-03-25T19:17:36.737Z]], ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2022-04-12T18:54:48.890Z], ovenMode:[value:Others, timestamp:2022-04-09T21:15:24.902Z]], ovenOperatingState:[completionTime:[value:2022-04-12T18:56:06.435Z, timestamp:2022-04-12T18:56:06.444Z], machineState:[value:running, timestamp:2022-04-12T18:56:06.444Z], progress:[value:1, unit:%, timestamp:2022-03-25T19:17:36.737Z], supportedMachineStates:[value:null], ovenJobState:[value:cooking, timestamp:2022-04-12T18:56:06.515Z], operationTime:[value:0, timestamp:2022-03-25T19:17:36.737Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2022-04-12T18:54:48.890Z], ovenMode:[value:AirFryer, timestamp:2022-04-12T18:56:06.691Z]], samsungce.lamp:[brightnessLevel:[value:off, timestamp:2022-04-12T18:54:54.717Z], supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]]]]]]
//WITH CAVITIES
//data:[components:[cavity-01:[ovenSetpoint:[ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:30.751Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], temperatureMeasurement:[temperature:[value:250, unit:F, timestamp:2022-04-12T19:03:33.586Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-12T20:03:12.966Z, timestamp:2022-04-12T19:03:12.976Z], operatingState:[value:running, timestamp:2022-04-12T19:02:30.481Z], progress:[value:1, timestamp:2021-12-14T19:25:30.821Z], ovenJobState:[value:preheat, timestamp:2022-04-12T19:02:30.475Z], operationTime:[value:01:00:00, timestamp:2022-04-12T19:03:12.976Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]], custom.ovenCavityStatus:[ovenCavityStatus:[value:on, timestamp:2022-04-12T19:02:09.437Z]], ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]], ovenOperatingState:[completionTime:[value:2022-04-12T20:03:12.966Z, timestamp:2022-04-12T19:03:12.976Z], machineState:[value:running, timestamp:2022-04-12T19:02:30.481Z], progress:[value:1, unit:%, timestamp:2021-12-14T19:25:30.821Z], supportedMachineStates:[value:null], ovenJobState:[value:preheat, timestamp:2022-04-12T19:02:30.475Z], operationTime:[value:3600, timestamp:2022-04-12T19:03:12.976Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]]], main:[ovenSetpoint:[ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:18.947Z]], samsungce.meatProbe:[temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]], refresh:[:], samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-12T19:02:11.728Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]], execute:[data:[value:[payload:[rt:[oic.r.temperature], if:[oic.if.baseline, oic.if.s], units:F, temperature:291.0]], data:[href:/temperature/current/prob/0], timestamp:2022-04-12T19:03:35.225Z]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:A-RG-WW-TP2-21-COMM_40210802, timestamp:2021-12-14T19:25:32.064Z], mnhw:[value:MediaTek, timestamp:2021-12-14T19:25:32.064Z], di:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], mnsl:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], dmv:[value:1.2.1, timestamp:2021-12-14T19:25:37.714Z], n:[value:[Range] Samsung, timestamp:2021-12-14T19:25:32.064Z], mnmo:[value:TP2X_DA-KS-RANGE-0101X|40434141|5001021E03141151020000000000000, timestamp:2021-12-14T19:25:32.064Z], vid:[value:DA-KS-RANGE-0101X, timestamp:2021-12-14T19:25:32.064Z], mnmn:[value:Samsung Electronics, timestamp:2021-12-14T19:25:32.064Z], mnml:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], mnpv:[value:DAWIT 2.0, timestamp:2021-12-14T19:25:32.064Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-12-14T19:25:32.064Z], pi:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], icv:[value:core.1.1.0, timestamp:2021-12-14T19:25:32.064Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]], samsungce.customRecipe:[:], samsungce.kitchenDeviceIdentification:[regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], modelCode:[value:NY9803T-/AA0, timestamp:2021-12-14T19:25:29.505Z], type:[value:range, timestamp:2021-12-14T19:25:29.505Z]], samsungce.kitchenModeSpecification:[specification:[value:[single:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:175, resolution:5], F:[min:175, max:550, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:Broil, supportedOperations:[set], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:KeepWarm, supportedOperations:[], supportedOptions:[temperature:[C:[min:80, max:80, default:80, resolution:5], F:[min:175, max:175, default:175, resolution:5]]]], [mode:BreadProof, supportedOperations:[], supportedOptions:[temperature:[C:[min:35, max:35, default:35, resolution:5], F:[min:95, max:95, default:95, resolution:5]]]], [mode:Dehydrate, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:40, max:105, default:65, resolution:5], F:[min:100, max:225, default:150, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:AirFryer, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:175, max:260, default:220, resolution:5], F:[min:350, max:500, default:425, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], upper:[[mode:Broil, supportedOperations:[], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], lower:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:175, resolution:5], F:[min:175, max:480, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:SteamClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:SelfClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:NoOperation, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]]]], timestamp:2021-12-14T19:25:32.622Z]], custom.cooktopOperatingState:[supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z], cooktopOperatingState:[value:ready, timestamp:2022-04-12T19:01:54.389Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]], temperatureMeasurement:[temperature:[value:291, unit:F, timestamp:2022-04-12T19:03:35.115Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-12T19:55:30.746Z, timestamp:2022-04-12T19:03:31.755Z], operatingState:[value:running, timestamp:2022-04-12T19:02:18.824Z], progress:[value:2, timestamp:2022-04-12T19:03:31.755Z], ovenJobState:[value:preheat, timestamp:2022-04-12T19:02:18.878Z], operationTime:[value:00:52:00, timestamp:2022-04-12T19:02:59.160Z]], ovenMode:[supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]], ovenOperatingState:[completionTime:[value:2022-04-12T19:55:30.746Z, timestamp:2022-04-12T19:03:31.755Z], machineState:[value:running, timestamp:2022-04-12T19:02:18.824Z], progress:[value:2, unit:%, timestamp:2022-04-12T19:03:31.755Z], supportedMachineStates:[value:null], ovenJobState:[value:preheat, timestamp:2022-04-12T19:02:18.878Z], operationTime:[value:3120, timestamp:2022-04-12T19:02:59.160Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]], samsungce.lamp:[brightnessLevel:[value:off, timestamp:2022-04-12T19:02:11.975Z], supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]]]]]]
//Here is with both cavities done preheating in case there is something different:
//data:[components:[cavity-01:[ovenSetpoint:[ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:30.751Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], temperatureMeasurement:[temperature:[value:325, unit:F, timestamp:2022-04-12T19:05:13.717Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z], operatingState:[value:running, timestamp:2022-04-12T19:02:30.481Z], progress:[value:5, timestamp:2022-04-12T19:05:36.707Z], ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z], operationTime:[value:01:00:00, timestamp:2022-04-12T19:03:12.976Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]], custom.ovenCavityStatus:[ovenCavityStatus:[value:on, timestamp:2022-04-12T19:02:09.437Z]], ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]], ovenOperatingState:[completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z], machineState:[value:running, timestamp:2022-04-12T19:02:30.481Z], progress:[value:5, unit:%, timestamp:2022-04-12T19:05:36.707Z], supportedMachineStates:[value:null], ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z], operationTime:[value:3600, timestamp:2022-04-12T19:03:12.976Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]]], main:[ovenSetpoint:[ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:18.947Z]], samsungce.meatProbe:[temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z], status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]], refresh:[:], samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-12T19:02:11.728Z]], samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z], defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]], execute:[data:[value:[payload:[rt:[x.com.samsung.da.operation], if:[oic.if.baseline, oic.if.a], x.com.samsung.da.state:Run, x.com.samsung.da.operationTime:01:00:00, x.com.samsung.da.remainingTime:00:57:59, x.com.samsung.da.progressPercentage:5, x.com.samsung.da.defaultTime:01:00:00]], data:[href:/operational/state/vs/1], timestamp:2022-04-12T19:05:36.707Z]], ocf:[st:[value:null], mndt:[value:null], mnfv:[value:A-RG-WW-TP2-21-COMM_40210802, timestamp:2021-12-14T19:25:32.064Z], mnhw:[value:MediaTek, timestamp:2021-12-14T19:25:32.064Z], di:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], mnsl:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], dmv:[value:1.2.1, timestamp:2021-12-14T19:25:37.714Z], n:[value:[Range] Samsung, timestamp:2021-12-14T19:25:32.064Z], mnmo:[value:TP2X_DA-KS-RANGE-0101X|40434141|5001021E03141151020000000000000, timestamp:2021-12-14T19:25:32.064Z], vid:[value:DA-KS-RANGE-0101X, timestamp:2021-12-14T19:25:32.064Z], mnmn:[value:Samsung Electronics, timestamp:2021-12-14T19:25:32.064Z], mnml:[value:http://www.samsung.com, timestamp:2021-12-14T19:25:32.064Z], mnpv:[value:DAWIT 2.0, timestamp:2021-12-14T19:25:32.064Z], mnos:[value:TizenRT 1.0 + IPv6, timestamp:2021-12-14T19:25:32.064Z], pi:[value:1d801730-98a0-ec16-a7d6-85bc16c9203f, timestamp:2021-12-14T19:25:32.064Z], icv:[value:core.1.1.0, timestamp:2021-12-14T19:25:32.064Z]], remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]], samsungce.customRecipe:[:], samsungce.kitchenDeviceIdentification:[regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], modelCode:[value:NY9803T-/AA0, timestamp:2021-12-14T19:25:29.505Z], type:[value:range, timestamp:2021-12-14T19:25:29.505Z]], samsungce.kitchenModeSpecification:[specification:[value:[single:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:175, resolution:5], F:[min:175, max:550, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:Broil, supportedOperations:[set], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:KeepWarm, supportedOperations:[], supportedOptions:[temperature:[C:[min:80, max:80, default:80, resolution:5], F:[min:175, max:175, default:175, resolution:5]]]], [mode:BreadProof, supportedOperations:[], supportedOptions:[temperature:[C:[min:35, max:35, default:35, resolution:5], F:[min:95, max:95, default:95, resolution:5]]]], [mode:Dehydrate, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:40, max:105, default:65, resolution:5], F:[min:100, max:225, default:150, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:AirFryer, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:175, max:260, default:220, resolution:5], F:[min:350, max:500, default:425, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], upper:[[mode:Broil, supportedOperations:[], supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionRoast, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], lower:[[mode:Bake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:175, resolution:5], F:[min:175, max:480, default:350, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:ConvectionBake, supportedOperations:[start, set], supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], [mode:SteamClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:SelfClean, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], [mode:NoOperation, supportedOperations:[], supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]]]], timestamp:2021-12-14T19:25:32.622Z]], custom.cooktopOperatingState:[supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z], cooktopOperatingState:[value:ready, timestamp:2022-04-12T19:01:54.389Z]], custom.disabledCapabilities:[disabledCapabilities:[value:null]], samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]], temperatureMeasurement:[temperature:[value:325, unit:F, timestamp:2022-04-12T19:04:38.829Z]], samsungce.ovenOperatingState:[completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], operatingState:[value:running, timestamp:2022-04-12T19:02:18.824Z], progress:[value:6, timestamp:2022-04-12T19:05:35.614Z], ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], operationTime:[value:00:52:00, timestamp:2022-04-12T19:02:59.160Z]], ovenMode:[supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]], ovenOperatingState:[completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], machineState:[value:running, timestamp:2022-04-12T19:02:18.824Z], progress:[value:6, unit:%, timestamp:2022-04-12T19:05:35.614Z], supportedMachineStates:[value:null], ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], operationTime:[value:3120, timestamp:2022-04-12T19:02:59.160Z]], samsungce.ovenMode:[supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]], samsungce.lamp:[brightnessLevel:[value:off, timestamp:2022-04-12T19:02:11.975Z], supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]], samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]]]]]]

/*
//	===== Oven =====
//def ovenNoDevider: [
data: [
	components:[
			cavity-01:[
				ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2021-12-14T19:25:30.534Z]], 
				custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
				temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2021-12-14T19:25:30.534Z]], 
				samsungce.ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z], 
											  operatingState:[value:ready, timestamp:2021-12-14T19:25:30.821Z], 
											  progress:[value:1, timestamp:2021-12-14T19:25:30.821Z], 
											  ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z], 
											  operationTime:[value:00:00:00, timestamp:2021-12-14T19:25:30.821Z]], 
				samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:null], 
												 defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], 
												 defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]], 
				custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2022-04-08T20:09:37.891Z]], 
				ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], 
						  ovenMode:[value:Others, timestamp:2021-12-14T19:25:30.779Z]], 
				ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.483Z, timestamp:2022-04-09T23:09:07.494Z], 
									machineState:[value:ready, timestamp:2021-12-14T19:25:30.821Z], 
									progress:[value:1, unit:%, timestamp:2021-12-14T19:25:30.821Z], 
									supportedMachineStates:[value:null], 
									ovenJobState:[value:ready, timestamp:2021-12-14T19:25:31.886Z], 
									operationTime:[value:0, timestamp:2021-12-14T19:25:30.821Z]], 
				samsungce.ovenMode:[supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], 
									ovenMode:[value:NoOperation, timestamp:2021-12-14T19:25:30.779Z]]], 
			main:[
				samsungce.kitchenDeviceDefaults:[defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], 
												 defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z], 
												 defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]], 
				execute:[VARIOUS], 
				ocf:[VARIOUS], 
				remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]], 
				samsungce.customRecipe:[:], 
				samsungce.kitchenDeviceIdentification:[regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], 
													   modelCode:[value:NY9803T-AA0, timestamp:2021-12-14T19:25:29.505Z], 
													   type:[value:range, timestamp:2021-12-14T19:25:29.505Z]], 
				samsungce.kitchenModeSpecification:[
					specification:[
						value:[
							single:[
								[
									mode:Bake,
									supportedOperations:[start, set],
									supportedOptions:[temperature:[C:[min:80, max:285, default:175, resolution:5], F:[min:175, max:550, default:350, resolution:5]], 
												   operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]],
								[
									mode:Broil,
									supportedOperations:[set],
									supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]],
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionRoast, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:285, default:160, resolution:5], F:[min:175, max:550, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:KeepWarm, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:80, max:80, default:80, resolution:5], F:[min:175, max:175, default:175, resolution:5]]]], 
								[
									mode:BreadProof, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:35, max:35, default:35, resolution:5], F:[min:95, max:95, default:95, resolution:5]]]], 
								[
									mode:Dehydrate, supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:40, max:105, default:65, resolution:5], F:[min:100, max:225, default:150, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:AirFryer, supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:175, max:260, default:220, resolution:5], F:[min:350, max:500, default:425, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], 
							upper:[
								[
									mode:Broil, 
									supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:61442, max:61441, default:61441, resolution:5], F:[min:61442, max:61441, default:61441, resolution:5]]]], 
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionRoast, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]]], 
							lower:[
								[mode:Bake, 
								 supportedOperations:[start, set], 
								 supportedOptions:[temperature:[C:[min:80, max:250, default:175, resolution:5], F:[min:175, max:480, default:350, resolution:5]], 
												   operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:ConvectionBake, 
									supportedOperations:[start, set], 
									supportedOptions:[temperature:[C:[min:80, max:250, default:160, resolution:5], F:[min:175, max:480, default:325, resolution:5]], 
													  operationTime:[min:00:01:00, max:09:59:00, default:01:00:00, resolution:00:01:00]]], 
								[
									mode:SteamClean, 
									supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
													  operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
													  probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], 
								[
									mode:SelfClean, supportedOperations:[], 
									supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
													  operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
													  probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]], 
								[mode:NoOperation, 
								 supportedOperations:[], 
								 supportedOptions:[temperature:[C:[min:0, max:0, default:0, resolution:5], F:[min:0, max:0, default:0, resolution:5]], 
												   operationTime:[min:00:00:00, max:00:00:00, default:00:00:00, resolution:00:00:00], 
												   probeTemperature:[C:[min:0, max:0, default:0, resolution:1], F:[min:0, max:0, default:0, resolution:1]]]]]], 
						timestamp:2021-12-14T19:25:32.622Z]], 
				custom.cooktopOperatingState:[supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z],
											  cooktopOperatingState:[value:ready, timestamp:2022-04-09T02:56:27.073Z]], 
				custom.disabledCapabilities:[disabledCapabilities:[value:null]], 
				samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]], 
				temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-09T16:35:22.265Z]], 
				samsungce.ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.647Z, timestamp:2022-04-09T23:09:07.656Z], 
											  operatingState:[value:ready, timestamp:2022-04-09T21:15:23.919Z], 
											  progress:[value:1, timestamp:2022-03-25T19:17:36.737Z], 
											  ovenJobState:[value:ready, timestamp:2022-04-09T21:15:23.806Z], 
											  operationTime:[value:00:00:00, timestamp:2022-03-25T19:17:36.737Z]],
				ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2022-04-08T20:09:37.891Z], 
						  ovenMode:[value:Others, timestamp:2022-04-09T21:15:24.902Z]], 
				ovenOperatingState:[completionTime:[value:2022-04-09T23:09:07.647Z, timestamp:2022-04-09T23:09:07.656Z], 
									machineState:[value:ready, timestamp:2022-04-09T21:15:23.919Z], 
									progress:[value:1, unit:%, timestamp:2022-03-25T19:17:36.737Z], 
									supportedMachineStates:[value:null], 
									ovenJobState:[value:ready, timestamp:2022-04-09T21:15:23.806Z], 
									operationTime:[value:0, timestamp:2022-03-25T19:17:36.737Z]], 
				samsungce.ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2022-04-08T20:09:37.891Z], 
									ovenMode:[value:NoOperation, timestamp:2022-04-09T21:15:24.902Z]], 
				samsungce.lamp:[brightnessLevel:[value:off, timestamp:2022-04-09T21:15:28.582Z], 
								supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]], 
				ovenSetpoint:[
					ovenSetpoint:[value:0, timestamp:2022-04-09T21:15:24.901Z]], 
				samsungce.meatProbe:[
					temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],
					temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],
					status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]], 
				refresh:[:], 
				samsungce.doorState:[
					doorState:[value:closed, timestamp:2022-04-09T21:15:28.309Z]], 
				samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]]]]]]

//def ovenWithDivider: 
data:[
	components:[
		cavity-01:[
			ovenSetpoint:[
				ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:30.751Z]],	//	ThermostatHeatingSetpoint
			temperatureMeasurement:[
				temperature:[value:325, unit:F, timestamp:2022-04-12T19:05:13.717Z]],	//	TemperatureSetpoint
			ovenMode:[
				supportedOvenModes:[value:[Bake, ConvectionBake, Others], timestamp:2021-12-14T19:25:32.622Z], 
				ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]]	//	Custom
			ovenOperatingState:[
				completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z], //xx
				machineState:[value:running, timestamp:2022-04-12T19:02:30.481Z]
				progress:[value:5, unit:%, timestamp:2022-04-12T19:05:36.707Z], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z],
				operationTime:[value:3600, timestamp:2022-04-12T19:03:12.976Z]],	//	Custom
			custom.ovenCavityStatus:[
				ovenCavityStatus:[value:on, timestamp:2022-04-12T19:02:09.437Z]],	//	PresenceSensor

			custom.disabledCapabilities:[
				disabledCapabilities:[value:null]],
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:30.779Z], 
				defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.534Z]],
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Bake, ConvectionBake, SteamClean, SelfClean, NoOperation], timestamp:2021-12-14T19:25:32.622Z], 
				ovenMode:[value:Bake, timestamp:2022-04-12T19:02:30.672Z]],
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-12T20:03:35.698Z, timestamp:2022-04-12T19:05:36.707Z],
				operatingState:[value:running, timestamp:2022-04-12T19:02:30.481Z],	
				progress:[value:5, timestamp:2022-04-12T19:05:36.707Z], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:05:12.615Z], //xx
				operationTime:[value:01:00:00, timestamp:2022-04-12T19:03:12.976Z]],
		],
		main:[
			ovenSetpoint:[
				ovenSetpoint:[value:325, timestamp:2022-04-12T19:02:18.947Z]],	//	ThermostatHeatingSetpoint
			temperatureMeasurement:[
				temperature:[value:325, unit:F, timestamp:2022-04-12T19:04:38.829Z]],	//	TemperatureSetpoint
			ovenMode:[
				supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z],
				ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]]		//	Custom
			ovenOperatingState:[
				completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], 
				machineState:[value:running, timestamp:2022-04-12T19:02:18.824Z], 
				progress:[value:6, unit:%, timestamp:2022-04-12T19:05:35.614Z], 
				supportedMachineStates:[value:null], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], 
				operationTime:[value:3120, timestamp:2022-04-12T19:02:59.160Z]],		//	Custom
			samsungce.kidsLock:[
				lockState:[value:unlocked, timestamp:2021-12-14T19:25:30.192Z]],	//	Custom
			samsungce.lamp:[
				brightnessLevel:[value:off, timestamp:2022-04-12T19:02:11.975Z], 
				supportedBrightnessLevel:[value:[off, high], timestamp:2021-12-14T19:25:29.505Z]],	//	Custom
			refresh:[:],	//	Refresh
			remoteControlStatus:[
				remoteControlEnabled:[value:false, timestamp:2022-03-16T23:20:47.952Z]],		//	Custom
			samsungce.doorState:[
				doorState:[value:closed, timestamp:2022-04-12T19:02:11.728Z]],		//	Contact Sensor
			custom.cooktopOperatingState:[
				supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-12-14T19:25:30.234Z], 
				cooktopOperatingState:[value:ready, timestamp:2022-04-12T19:01:54.389Z]],		//	Custom
			
			samsungce.meatProbe:[
				temperatureSetpoint:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],	//	ThermostatHeatingSetpoint
				temperature:[value:0, unit:F, timestamp:2022-03-20T00:25:56.191Z],	//	TemperatureSetpoint
				status:[value:disconnected, timestamp:2022-03-20T00:26:35.589Z]		//	PresenceSensor
			],	//	Child

			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:3600, timestamp:2021-12-14T19:25:30.618Z], 
				defaultOvenMode:[value:ConvectionBake, timestamp:2021-12-14T19:25:29.505Z],
				defaultOvenSetpoint:[value:350, timestamp:2021-12-14T19:25:30.549Z]],
			execute:[
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.operation], 
							if:[oic.if.baseline, oic.if.a], 
							x.com.samsung.da.state:Run, 
							x.com.samsung.da.operationTime:01:00:00, 
							x.com.samsung.da.remainingTime:00:57:59, 
							x.com.samsung.da.progressPercentage:5, 
							x.com.samsung.da.defaultTime:01:00:00]], 
					data:[href:/operational/state/vs/1], 
					timestamp:2022-04-12T19:05:36.707Z]],
			ocf:[VARIOUS],
			samsungce.customRecipe:[:], 
			samsungce.kitchenDeviceIdentification:[
				regionCode:[value:US, timestamp:2021-12-14T19:25:29.505Z], 
				modelCode:[value:NY9803T-AA0, timestamp:2021-12-14T19:25:29.505Z], 
				type:[value:range, timestamp:2021-12-14T19:25:29.505Z]],
			samsungce.kitchenModeSpecification:[VARIOUS],
			custom.disabledCapabilities:[
				disabledCapabilities:[value:null]],
			samsungce.driverVersion:[
				versionNumber:[value:21042801, timestamp:2021-12-14T19:25:29.505Z]],
			samsungce.ovenMode:[
				supportedOvenModes:[value:[Broil, ConvectionBake, ConvectionRoast], timestamp:2022-04-12T19:02:09.437Z], 
				ovenMode:[value:ConvectionBake, timestamp:2022-04-12T19:02:18.979Z]],
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-12T19:55:34.605Z, timestamp:2022-04-12T19:05:35.614Z], 
				operatingState:[value:running, timestamp:2022-04-12T19:02:18.824Z], 
				progress:[value:6, timestamp:2022-04-12T19:05:35.614Z], 
				ovenJobState:[value:cooking, timestamp:2022-04-12T19:04:36.849Z], 
				operationTime:[value:00:52:00, timestamp:2022-04-12T19:02:59.160Z]],
		]
	]
]


===== Range

Range: [
	deviceId:b440aa23-9f34-bfb4-eef2-5c0d0bfdf4e8, 
	name:[Range] Samsung, label:Range, 
	manufacturerName:Samsung Electronics, presentationId:DA-KS-RANGE-0101X, 
	deviceManufacturerCode:Samsung Electronics, locationId:55d80aa6-11a6-4456-9aed-c13e2c76fb93, 
	roomId:564192d9-95ba-4518-8577-45b11f27de5a, 
	deviceTypeName:Samsung OCF Range, 
	components:[
		[
			id:main, label:Range, 
			capabilities:[
				[id:ocf, version:1], 
				[id:execute, version:1], 
				[id:refresh, version:1], 
				[id:remoteControlStatus, version:1], 
				[id:ovenSetpoint, version:1], 
				[id:ovenMode, version:1], 
				[id:ovenOperatingState, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:samsungce.driverVersion, version:1], 
				[id:samsungce.kitchenDeviceIdentification, version:1], 
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:samsungce.doorState, version:1], 
				[id:samsungce.customRecipe, version:1], 
				[id:samsungce.ovenMode, version:1], 
				[id:samsungce.ovenOperatingState, version:1], 
				[id:samsungce.meatProbe, version:1], 
				[id:samsungce.lamp, version:1], 
				[id:samsungce.kitchenModeSpecification, version:1], 
				[id:samsungce.kidsLock, version:1], 
				[id:custom.cooktopOperatingState, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Range, categoryType:manufacturer]]], 
		[
			id:cavity-01, label:1, 
			capabilities:[
				[id:ovenSetpoint, version:1], 
				[id:ovenMode, version:1], 
				[id:ovenOperatingState, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:samsungce.ovenMode, version:1], 
				[id:samsungce.ovenOperatingState, version:1], 
				[id:samsungce.kitchenDeviceDefaults, version:1], 
				[id:custom.ovenCavityStatus, version:1], 
				[id:custom.disabledCapabilities, version:1]], 
			categories:[[name:Other, categoryType:manufacturer]]]], 
	createTime:2020-11-29T02:34:41Z, 
	profile:[id:00eef220-8a5d-3f6a-be53-69823e28e5cc], 
	ocf:[ocfDeviceType:oic.d.range, name:[Range] Samsung, specVersion:core.1.1.0, verticalDomainSpecVersion:1.2.1, 
		 manufacturerName:Samsung Electronics, modelNumber:TP2X_DA-KS-RANGE-0101X|40433941|5001011E03141101020000000000000, 
		 platformVersion:DAWIT 2.0, platformOS:TizenRT 1.0 + IPv6, hwVersion:MediaTek, firmwareVersion:A-RG-WW-TP2-21-COMM_40210802, 
		 vendorId:DA-KS-RANGE-0101X, vendorResourceClientServerVersion:MediaTek Release 2.210709.1, lastSignupTime:2022-02-06T21:41:38.344027Z], 
	type:OCF, 
	restrictionTier:0, 
	allowed:[]]]

Status: [
	components:[
		cavity-01:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2020-11-29T02:35:20.254Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2020-11-29T02:35:20.290Z]], 
			samsungce.ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z], 
				operatingState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				progress:[value:1, timestamp:2021-01-16T07:47:02.811Z], 
				ovenJobState:[value:ready, timestamp:2021-01-16T07:47:02.811Z], 
				operationTime:[value:00:00:00, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:null], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-06T20:56:23.566Z], defaultOvenSetpoint:[value:350, timestamp:2021-07-06T20:56:23.610Z]], 
			custom.ovenCavityStatus:[ovenCavityStatus:[value:off, timestamp:2020-11-29T02:35:20.385Z]], 
			ovenMode:[
				supportedOvenModes:[value:[Others], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:Others, timestamp:2021-07-26T04:43:08.029Z]], 
			ovenOperatingState:[
				completionTime:[value:2022-04-26T16:19:02.945Z, timestamp:2022-04-26T16:19:02.955Z],
				machineState:[value:ready, timestamp:2020-11-29T02:35:20.495Z], 
				progress:[value:1, unit:%, timestamp:2021-01-16T07:47:02.811Z], 
				supportedMachineStates:[value:null, timestamp:2020-11-29T02:43:38.329Z], 
				ovenJobState:[value:ready, timestamp:2020-11-29T02:35:20.589Z], 
				operationTime:[value:0, timestamp:2021-01-16T07:47:02.811Z]], 
			samsungce.ovenMode:[
				supportedOvenModes:[value:[SteamClean, SelfClean, NoOperation], timestamp:2021-07-26T05:01:09.707Z], 
				ovenMode:[value:NoOperation, timestamp:2021-07-26T04:43:08.029Z]]], 
		main:[
			ovenSetpoint:[ovenSetpoint:[value:0, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.meatProbe:[
				temperatureSetpoint:[value:0, unit:F, timestamp:2021-07-05T23:01:20.610Z],
				temperature:[value:0, unit:F, timestamp:2021-11-06T21:59:15.685Z], 
				satus:[value:disconnected, timestamp:2021-01-16T07:47:02.729Z]], 
			refresh:[:], 
			samsungce.doorState:[doorState:[value:closed, timestamp:2022-04-19T22:54:42.948Z]], 
			samsungce.kitchenDeviceDefaults:[
				defaultOperationTime:[value:3600, timestamp:2021-01-16T07:47:02.729Z], defaultOvenMode:[value:ConvectionBake, timestamp:2021-07-26T04:43:08.166Z], 
				defaultOvenSetpoint:[value:350, timestamp:2021-01-16T07:47:02.729Z]], 
			execute:[], 
			ocf:[], 
			remoteControlStatus:[remoteControlEnabled:[value:false, timestamp:2022-02-28T01:53:04.641Z]], 
			samsungce.customRecipe:[:], 
			samsungce.kitchenDeviceIdentification:[], 
			samsungce.kitchenModeSpecification:[],
			custom.cooktopOperatingState:[
				supportedCooktopOperatingState:[value:[run, ready], timestamp:2021-11-05T02:59:11.253Z], 
				cooktopOperatingState:[value:ready, timestamp:2022-04-26T21:44:25.086Z]], 
			custom.disabledCapabilities:[disabledCapabilities:[value:[], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.driverVersion:[versionNumber:[value:21042801, timestamp:2021-11-05T12:16:33.903Z]], 
			temperatureMeasurement:[temperature:[value:175, unit:F, timestamp:2022-04-19T22:54:43.792Z]], 
			samsungce.ovenOperatingState:[completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
										  operatingState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
										  progress:[value:1, timestamp:2021-01-16T07:47:01.589Z], 
										  ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
										  operationTime:[value:00:00:00, timestamp:2022-02-26T03:52:38.958Z]], 
			ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, warming, Others, Dehydrate], timestamp:2021-11-12T02:59:11.564Z], 
					  ovenMode:[value:Others, timestamp:2022-04-19T22:54:43.795Z]], 
			ovenOperatingState:[completionTime:[value:2022-04-26T16:19:02.917Z, timestamp:2022-04-26T16:19:02.927Z], 
								machineState:[value:ready, timestamp:2022-04-19T22:54:43.617Z], 
								progress:[value:1, unit:%, timestamp:2021-11-06T21:59:01.515Z], 
								supportedMachineStates:[value:null, timestamp:2020-11-29T02:39:28.212Z], 
								ovenJobState:[value:ready, timestamp:2022-04-19T22:54:43.542Z], 
								operationTime:[value:0, timestamp:2022-02-26T03:52:38.958Z]], 
			samsungce.ovenMode:[supportedOvenModes:[value:[Bake, Broil, ConvectionBake, ConvectionRoast, KeepWarm, BreadProof, Dehydrate, AirFryer], timestamp:2021-11-12T02:59:11.564Z], 
								ovenMode:[value:NoOperation, timestamp:2022-04-19T22:54:43.795Z]], 
			samsungce.lamp:[brightnessLevel:[value:off, timestamp:2022-04-19T22:54:43.120Z], supportedBrightnessLevel:[value:[off, high], timestamp:2021-07-05T01:15:09.933Z]], 
			samsungce.kidsLock:[lockState:[value:unlocked, timestamp:2022-04-17T15:45:36.776Z]]]]]]
*/























