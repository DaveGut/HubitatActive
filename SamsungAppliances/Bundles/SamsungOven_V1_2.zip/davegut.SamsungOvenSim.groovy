library (
	name: "Samsung-Oven-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Samsung Oven-Range Simulator",
	category: "utilities",
	documentationLink: ""
)

def testData() {
	def tempUnit = "F"
	def kidsLock = "locked"
	def doorState = "open"
	def cooktopState = "run"
	def remoteControl = "true"
	def setpoint = 225
	def temperature = 300
	def endTime = "2022-05-09T19:03:35.698Z"
	//	attribute timeRemaining
	def ovenState = "running"
	def ovenJobState = "cooking"
	def ovenMode = "Whatever"
	def brightness = "high"

	def probeStatus = "connected"
	def probeTemp = 200
	def probeSetpoint = 225

	def cavityStatus = "on"
	def cavitySetpoint = 350
	def cavityTemperature = 300
	def cavityEndTime = "2022-05-31T16:17:35.698Z"
	//	attribute timeRemaining
	def cavityState = "xxrunning"
	def cavityJobState = "xxcooking"
	def cavityMode = "xxBake"

	return  [components:[
		"cavity-01":[
			ovenSetpoint:[ovenSetpoint:[value: cavitySetpoint, unit: tempUnit]],
			temperatureMeasurement:[temperature:[value: cavityTemperature, unit: tempUnit]],
			ovenMode:[ovenMode:[value: cavityMode]],
			ovenOperatingState:[
				completionTime:[value: cavityEndTime], 
				machineState:[value: cavityState], 
				ovenJobState:[value: cavityJobState]],
			"custom.ovenCavityStatus":[ovenCavityStatus:[value: cavityStatus]],
		],
		main:[
			ovenSetpoint:[ovenSetpoint:[value: setpoint, unit: tempUnit]],
			temperatureMeasurement:[temperature:[value:temperature, unit: tempUnit]],
			ovenMode:[ovenMode:[value: ovenMode]],
			ovenOperatingState:[
				completionTime:[value: endTime], 
				machineState:[value: ovenState], 
				ovenJobState:[value: ovenJobState]],
			
			"samsungce.kidsLock":[lockState:[value:kidsLock]],
			"samsungce.lamp":[brightnessLevel:[value:brightness]],
			remoteControlStatus:[remoteControlEnabled:[value: remoteControl]],
			"samsungce.doorState":[doorState:[value: doorState]],
			"custom.cooktopOperatingState":[cooktopOperatingState:[value: cooktopState]],
			"samsungce.meatProbe":[
				temperatureSetpoint:[value: probeSetpoint, unit: tempUnit],
				temperature:[value: probeTemp, unit: tempUnit], 
				status:[value: probeStatus]]
		]
	]]
}

def testResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
