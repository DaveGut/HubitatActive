/*	Samsung Oven Probe using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This is a child driver to Samsung Oven and will not work indepenently of same.
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Oven probe",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Oven_probe.groovy"
			   ){
		capability "Thermostat Setpoint"
		capability "Temperature Measurement"
		command "setProbeSetpoint", ["NUM"]
		attribute "probeStatus", "string"
	}
	preferences {
		input ("infoLog", "bool",  
			   title: "Info logging", defaultValue: false)
		input ("debugLog", "bool",  
			   title: "Enable debug logging for 30 minutes", defaultValue: false)
	}
}

def installed() {
	runIn(1, updated)
}

def updated() {
	def logData = [:]
	if (driverVer() != parent.driverVer()) {
		logWarn("updated: Child driver version does not match parent.")
	}
	if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		logData << [driverVersion: driverVer()]
	}
	if (logData != [:]) {
		logInfo("updated: ${logData}")
	}
}

def setProbeSetpoint(setpoint) {
	logDebug("setProbeSetpoint: ${setpoint}")
	def cmdData = [
		component: "main",
		capability: "samsungce.meatProbe",
		command: "setTemperatureSetpoint",
		arguments: [setpoint]]
	def cmdStatus = parent.deviceCommand(cmdData)
	logInfo("setProbeSetpoint: [setpoint: ${setpoint}, status: ${cmdStatus}]")
}

def statusParse(respData) {
	try {
		respData = respData.components.main["samsungce.meatProbe"]
	} catch (err) {
		logWarn("status: [status: ERROR, error: ${err}]")
		return
	}

	def tempUnit = respData.temperature.unit
	def temperature = 0
	def thermostatSetpoint = 0
	def probeStatus = "not present"
	def status = respData.status.value
	if (status == "connected") {probeStatus = "present" }
	if (probeStatus == "present") {
		temperature = respData.temperature.value
		thermostatSetpoint = respData.temperatureSetpoint.value
	}
	sendEvent(name: "probeStatus", value: probeStatus)
	sendEvent(name: "temperature", value: temperature, unit: tempUnit)
	sendEvent(name: "thermostatSetpoint", value: thermostatSetpoint, unit: tempUnit)

	if (parent.simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
