/*	Samsung Oven Cavity using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This is a child driver to Samsung Oven and will not work indepenently of same.
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Oven cavity",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Oven_cavity.groovy"
			   ){
		capability "Thermostat Setpoint"
		capability "Temperature Measurement"
		command "pauseOven"
		command "runOven"
		command "stopOven"
		command "setOvenSetpoint", ["NUMBER"]
		attribute "cavityStatus", "string"
		attribute "timeRemaining", "string"
		attribute "completionTime", "NUMBER"
		attribute "ovenState", "string"
		attribute "jobState", "string"
		attribute "ovenMode", "string"
	}
	preferences {
		input ("infoLog", "bool",  
			   title: "Info logging", defaultValue: false)
		input ("debugLog", "bool",  
			   title: "Enable debug logging for 30 minutes", defaultValue: false)
	}
}

def installed() {
	runIn(1, updated)
}

def updated() {
	def logData = [:]
	if (driverVer() != parent.driverVer()) {
		logWarn("updated: Child driver version does not match parent.")
	}
	if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
		updateDataValue("driverVersion", driverVer())
		logData << [driverVersion: driverVer()]
	}
	if (logData != [:]) {
		logInfo("updated: ${logData}")
	}
}

def pauseOven() {
	parent.setMachineState("paused", "cavity-01")
}
def runOven() {
	parent.setMachineState("running", "cavity-01")
}

def stopOven() { 
	parent.stopOven("cavity-01")
}

def setOvenSetpoint(setpoint) {
	parent.setOvenSetpoint(setpoint, "cavity-01")
}

def statusParse(respData) {
	try {
		respData = respData.components["cavity-01"]
	} catch (err) {
		logWarn("statusParse: [respData: ${respData}, error: ${error}]")
		return
	}
	
	def logData = [:]
	def tempUnit = respData.temperatureMeasurement.temperature.unit
	def temperature = 0
	def thermostatSetpoint = 0
	def completionTime = 0
	def timeRemaining = 0
	def ovenState = "notPresent"
	def jobState = "notPresent"
	def ovenMode = "notPresent"

	def cavityStatus = "not present"
	def status = respData["custom.ovenCavityStatus"].ovenCavityStatus.value
	if (status == "on") { cavityStatus = "present" }
	
	if (cavityStatus == "present") {
		temperature = respData.temperatureMeasurement.temperature.value
		thermostatSetpoint = respData.ovenSetpoint.ovenSetpoint.value
		completionTime = respData.ovenOperatingState.completionTime.value
		if (completionTime != null) {
			timeRemaining = parent.calcTimeRemaining(completionTime)
		}
		ovenState = respData.ovenOperatingState.machineState.value
		jobState = respData.ovenOperatingState.ovenJobState.value
		ovenMode = respData.ovenMode.ovenMode.value
	}
	
	sendEvent(name: "cavityStatus", value: cavityStatus)
	sendEvent(name: "temperature", value: temperature, unit: tempUnit)
	sendEvent(name: "thermostatSetpoint", value: thermostatSetpoint, unit: tempUnit)
	sendEvent(name: "completionTime", value: completionTime)
	sendEvent(name: "timeRemaining", value:timeRemaining)
	sendEvent(name: "ovenState", value: ovenState)
	sendEvent(name: "jobState", value: jobState)
	sendEvent(name: "ovenMode", value: ovenMode)
	
	if (parent.simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}
	
//	===== Library Integration =====
#include davegut.Logging