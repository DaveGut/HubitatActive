library (
	name: "Samsung-Dryer-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Simulator - Samsung Dryer",
	category: "utilities",
	documentationLink: ""
)

def testData() {
	def flex = true
	def altTest = true
	
	def completionTime = "2022-08-29T18:15:00Z"
	def machineState = "run"
	def jobState = "drying"
	def onOff = "on"
	def kidsLock = "locked"
	def remoteControl = "true"
	if (altTest) {
		completionTime = "2022-08-29T18:15:30Z"
		machineState = "stopped"
		jobState = "stopped"
		onOff = "off"
		kidsLock = "unlocked"
		remoteControl = "false"
	}

	if (flex) {
		return  [components:[
			sub:[
				remoteControlStatus:[remoteControlEnabled:[value:remoteControl]], 
				dryerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					dryerJobState:[value:jobState]], 
				switch:[switch:[value:onOff]]], 
			main:[
				switch:[switch:[value:onOff]],
				"samsungce.kidsLock":[lockState:[value:kidsLock]], 
				dryerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					dryerJobState:[value:jobState]], 
				remoteControlStatus:[remoteControlEnabled:[value:remoteControl]], 
			]]]
	} else {
		return  [components:[
			main:[
				switch:[switch:[value:onOff]],
				"samsungce.kidsLock":[lockState:[value:kidsLock]], 
				dryerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					dryerJobState:[value:jobState]], 
				remoteControlStatus:[remoteControlEnabled:[value:remoteControl]], 
			]]]
	}
}

def testResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
