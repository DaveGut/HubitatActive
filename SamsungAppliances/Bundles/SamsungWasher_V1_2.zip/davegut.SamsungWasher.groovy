/*	Samsung Washer using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung Washers for import of control
and status of defined functions into Hubitat Environment.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
===== Version 1.1 ==============================================================================*/
def driverVer() { return "1.2" }
def nameSpace() { return "davegut" }

metadata {
	definition (name: "Samsung Washer",
				namespace: nameSpace(),
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_Washer.groovy"
			   ){
		capability "Refresh"
		attribute "switch", "string"
		command "start"
		command "pause"
		command "stop"
		attribute "machineState", "string"
		attribute "kidsLock", "string"
		attribute "remoteControlEnabled", "string"
		attribute "completionTime", "string"
		attribute "timeRemaining", "number"
		attribute "waterTemperature", "string"
		attribute "jobState", "string"
		attribute "soilLevel", "string"
		attribute "spinLevel", "string"
	}
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["10sec", "20sec", "30sec", "1", "5", "10", "30"], defaultValue: "10")
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: true)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
			input("installChildren", "bool", title: "Install child devices",
				  defaultValue: false)
		}
	}
}

def installed() { }

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "FAILED") {
		logWarn("updated: ${commonStatus}")
	} else {
		logInfo("updated: ${commonStatus}")
	}
	if (installChildren) {
		deviceSetup()
		device.updateSetting("installChildren", [type:"bool", value: false])
	}
}

def start() { setMachineState("run") }
def pause() { setMachineState("pause") }
def stop() { setMachineState("stop") }
def setMachineState(machState) {
	def cmdData = [
		component: "main",
		capability: "dryerOperatingState",
		command: "setMachineState",
		arguments: [machState]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setMachineState: [cmd: ${machState}, status: ${cmdStatus}]")
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData)
			} else {
				def children = getChildDevices()
				children.each {
						it.statusParse(respData)
				}
				statusParse(respData)
			}
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(respData) {
	def respLog = []
	def compData = respData.components
	def dni = device.getDeviceNetworkId()
	compData.each {
		if (it.key != "main") {
			def childDni = dni + "-${it.key}"
			def isChild = getChildDevice(childDni)
			if (!isChild) {
				def disabledComponents = []
				if (disabledComponents == null) {
					disabledComponents = compData.main["custom.disabledComponents"].disabledComponents.value
				}
				if(!disabledComponents.contains(it.key)) {
					respLog << [component: it.key, status: "Installing"]
					addChild(it.key, childDni)
				}
			}
		} else {
			updateDataValue("component", "main")
		}
	}
			
	if (respLog != []) {
		logInfo("deviceSetupParse: ${respLog}")
	}
}
def addChild(component, childDni) {
	def type = "Samsung Washer flex"
	try {
		addChildDevice(nameSpace(), "${type}", "${childDni}", [
			 "label": "${device.displayName} flex", component: component])
		logInfo("addChild: [status: ADDED, label: ${component}, type: ${type}]")
	} catch (error) {
		logWarn("addChild: [status: FAILED, type: ${type}, dni: ${childDni}, component: ${component}, error: ${error}]")
	}
}

def statusParse(respData) {
	def parseData
	try {
		parseData = respData.components.main
	} catch (error) {
		logWarn("statusParse: [parseData: ${respData}, error: ${error}]")
		return
	}

	def onOff = parseData.switch.switch.value
	sendEvent(name: "switch", value: onOff)
	if (device.currentValue("switch") != onOff) {
		if (onOff == "off") {
			setPollInterval(state.pollInterval)
		} else {
			runEvery1Minute(poll)
		}
	}
	
	if (parseData["samsungce.kidsLock"]) {
		def kidsLock = parseData["samsungce.kidsLock"].lockState.value
		sendEvent(name: "kidsLock", value: kidsLock)
	}
	
	def machineState = parseData.washerOperatingState.machineState.value
	sendEvent(name: "machineState", value: machineState)
	
	if (parseData["samsungce.kidsLock"]) {
		def kidsLock = parseData["samsungce.kidsLock"].lockState.value
		sendEvent(name: "kidsLock", value: kidsLock)
	}

	def jobState = parseData.washerOperatingState.washerJobState.value
	sendEvent(name: "jobState", value: jobState)
	
	def remoteControlEnabled = parseData.remoteControlStatus.remoteControlEnabled.value
	sendEvent(name: "remoteControlEnabled", value: remoteControlEnabled)
	
	def completionTime = parseData.washerOperatingState.completionTime.value
	if (completionTime != null) {
		def timeRemaining = calcTimeRemaining(completionTime)
		sendEvent(name: "completionTime", value: completionTime)
		sendEvent(name: "timeRemaining", value: timeRemaining)
	}

	def waterTemperature = parseData["custom.washerWaterTemperature"].washerWaterTemperature.value
	sendEvent(name: "waterTemperature", value: waterTemperature)

	def soilLevel = parseData["custom.washerSoilLevel"].washerSoilLevel.value
	sendEvent(name: "soilLevel", value: soilLevel)

	def spinLevel = parseData["custom.washerSpinLevel"].washerSpinLevel.value
	sendEvent(name: "spinLevel", value: spinLevel)
	
	if (simulate() == true) {
		runIn(1, listAttributes, [data: true])
	} else {
		runIn(1, listAttributes)
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return false }
//#include davegut.Samsung-Washer-Sim
