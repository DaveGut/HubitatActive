library (
	name: "Samsung-Washer-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Simulator - Samsung Washer",
	category: "utilities",
	documentationLink: ""
)

def testData() {
	def flex = true
	def altTest = true
	
	def waterTemp = "hot"
	def completionTime = "2022-09-06T20:00:00Z"
	def machineState = "running"
	def jobState = "spin"
	def onOff = "off"
	def kidsLock = "locked"
	def soilLevel = "low"
	def remoteControlEnabled = "false"
	def spinLevel = "high"
	if (altTest) {
		waterTemp = "cold"
		completionTime = "2022-09-06T20:00:30Z"
		machineState = "stopped"
		jobState = "stop"
		onOff = "on"
		kidsLock = "unlocked"
		soilLevel = "high"
		remoteControlEnabled = "true"
		spinLevel = "slow"
	}
	
	if (flex) {
		return  [components:[
			sub:[
				"custom.washerWaterTemperature":[washerWaterTemperature:[value:waterTemp]], 
				washerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					washerJobState:[value:jobState]], 
				switch:[switch:[value:onOff]], 
				"samsungce.kidsLock":[lockState:[value:kidsLock]], 
				remoteControlStatus:[remoteControlEnabled:[value:remoteControlEnabled]]
			],
			main:[
				"custom.washerWaterTemperature":[washerWaterTemperature:[value:waterTemp]], 
				washerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					washerJobState:[value:jobState]], 
				switch:[switch:[value:onOff]], 
				"samsungce.kidsLock":[lockState:[value:kidsLock]], 
				"custom.washerSoilLevel":[washerSoilLevel:[value:soilLevel]], 
				remoteControlStatus:[remoteControlEnabled:[value:remoteControlEnabled]], 
				"custom.washerSpinLevel":[washerSpinLevel:[value:spinLevel]]
			]]]
	} else {
		return  [components:[
			main:[
				"custom.washerWaterTemperature":[washerWaterTemperature:[value:waterTemp]], 
				washerOperatingState:[
					completionTime:[value:completionTime], 
					machineState:[value:machineState], 
					washerJobState:[value:jobState]], 
				switch:[switch:[value:onOff]], 
				"samsungce.kidsLock":[lockState:[value:kidsLock]], 
				"custom.washerSoilLevel":[washerSoilLevel:[value:soilLevel]], 
				remoteControlStatus:[remoteControlEnabled:[value:remoteControlEnabled]], 
				"custom.washerSpinLevel":[washerSpinLevel:[value:spinLevel]]
			]]]
	}
}

def testResp(cmdData) {
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
