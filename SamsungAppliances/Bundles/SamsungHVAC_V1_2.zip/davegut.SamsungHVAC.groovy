/*	Samsung HVAC using SmartThings Interface
		Copyright Dave Gutheinz
License Information:
	https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== Description
This driver is for SmartThings-installed Samsung HVAC for import of control
and status of defined functions into Hubitat Environment.
=====	Library Use
This driver uses libraries for the functions common to SmartThings devices. 
Library code is at the bottom of the distributed single-file driver.
===== Installation Instructions Link =====
https://github.com/DaveGut/HubitatActive/blob/master/SamsungAppliances/Install_Samsung_Appliance.pdf
1.2.1 = MX release to fix US version.
==============================================================================*/
def driverVer() { return "1.2.1" }

metadata {
	definition (name: "Samsung HVAC",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: "https://raw.githubusercontent.com/DaveGut/HubitatActive/master/SamsungAppliances/Samsung_HVAC.groovy"
			   ){
		capability "Refresh"
		capability "Thermostat"
		command "setThermostatMode", [[
			name: "Thermostat Mode",
			constraints: ["off", "auto", "cool", "heat", "dry", "wind", "samsungAuto"],
			type: "ENUM"]]
		command "emergencyHeat", [[name: "NOT IMPLEMENTED"]]
		command "samsungAuto"
		command "wind"
		command "dry"
		command "setThermostatFanMode", [[
			name: "Thermostat Fan Mode",
			constraints: ["auto", "low", "medium", "high"],
			type: "ENUM"]]
		command "fanLow"
		command "fanMedium"
		command "fanHigh"
		command "setSamsungAutoSetpoint", ["number"]
		attribute "samsungAutoSetpoint", "number"
		//	Set the light on the remote control.
		command "togglePanelLight"
		attribute "lightStatus", "string"
		command "setLevel", ["number"]		//	To set samsungAutoSetpoint via slider
		attribute "level", "number"			//	Reflects samsungAutoSetpoint
	}
	preferences {
		input ("stApiKey", "string", title: "SmartThings API Key", defaultValue: "")
		if (stApiKey) {
			input ("stDeviceId", "string", title: "SmartThings Device ID", defaultValue: "")
		}
		if (stDeviceId) {
			input ("tempOffset", "number", title: "Min Heat/Cool temperature delta",
					   defaultValue: 4)
			input ("pollInterval", "enum", title: "Poll Interval (minutes)",
				   options: ["1", "5", "10", "30"], defaultValue: "1")
			input ("infoLog", "bool",  
				   title: "Info logging", defaultValue: false)
			input ("debugLog", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
		}
	}
}

def installed() { }

def updated() {
	def commonStatus = commonUpdate()
	if (commonStatus.status == "FAILED") {
		logWarn("updated: ${commonStatus}")
	} else {
		logInfo("updated: ${commonStatus}")
	}
	deviceSetup()
}

def auto() { setThermostatMode("auto") }
def cool() { setThermostatMode("cool") }
def heat() { setThermostatMode("heat") }
def wind() { setThermostatMode("wind") }
def dry() { setThermostatMode("dry") }
def samsungAuto() { setThermostatMode("samsungAuto") }
def emergencyHeat() { logInfo("emergencyHeat: Not Available on this device") }
def off() { setThermostatMode("off") }
def setOn() {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: "on",
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	return cmdStatus
}
def setOff() {
	def cmdData = [
		component: "main",
		capability: "switch",
		command: "off",
		arguments: []]
	def cmdStatus = deviceCommand(cmdData)
	return cmdStatus
}
def setThermostatMode(thermostatMode) {
	def cmdStatus
	def prevMode = device.currentValue("thermostatMode")
	if (thermostatMode == "auto") {
		state.autoMode = true
		cmdStatus = [status: "OK", mode: "Auto Emulation"]
		poll()
	} else if (thermostatMode == "off") {
		state.autoMode = false
		cmdStatus = setOff()
	} else {
		state.autoMode = false
		if (thermostatMode == "samsungAuto") {
			thermostatMode = "auto"
		}
		cmdStatus = setOn()
		logInfo("setOn: [cmd: on, ${cmdStatus}]")
		cmdStatus = sendModeCommand(thermostatMode)
	}
	logInfo("setThermostatMode: [cmd: ${thermostatMode}, ${cmdStatus}]")
}
def sendModeCommand(thermostatMode) {
	def cmdData = [
		component: "main",
		capability: "airConditionerMode",
		command: "setAirConditionerMode",
		arguments: [thermostatMode]]
	cmdStatus = deviceCommand(cmdData)
	return cmdStatus
}

def fanAuto() { setThermostatFanMode("auto") }
def fanCirculate() { setThermostatFanMode("medium") }
def fanOn() { setThermostatFanMode("medium") }
def fanLow() { setThermostatFanMode("low") }
def fanMedium() { setThermostatFanMode("medium") }
def fanHigh() { setThermostatFanMode("high") }
def setThermostatFanMode(fanMode) {
	def cmdData = [
		component: "main",
		capability: "airConditionerFanMode",
		command: "setFanMode",
		arguments: [fanMode]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setThermostatFanMode: [cmd: ${fanMode}, ${cmdStatus}]")
}

def setHeatingSetpoint(setpoint) {
	if (setpoint < state.minSetpoint || setpoint > state.maxSetpoint) {
		logWarn("setHeatingSetpoint: Setpoint out of range")
		return
	}
	def logData = [:]
	def offset = tempOffset
	if (offset < 0) { offset = -offset }
	if (state.tempUnit == "°F") {
		setpoint = setpoint.toInteger()
		offset = offset.toInteger()		
	}

	if (device.currentValue("heatingSetpoint") != setpoint) {
		sendEvent(name: "heatingSetpoint", value: setpoint, unit: state.tempUnit)
		logData << [heatingSetpoint: setpoint]
	}

	def minSetpoint = setpoint + offset
	if (minSetpoint > device.currentValue("coolingSetpoint")) {
		sendEvent(name: "coolingSetpoint", value: minSetpoint, unit: state.tempUnit)
		logData << [coolingSetpoint: minSetpoint]
	}
	
	runIn(1, updateOperation)
	if (logData != [:]) {
		logInfo("setHeatingSetpoint: ${logData}")
	}
}
def setCoolingSetpoint(setpoint) {
	if (setpoint < state.minSetpoint || setpoint > state.maxSetpoint) {
		logWarn("setCoolingSetpoint: Setpoint out of range")
		return
	}
	def logData = [:]
	def offset = tempOffset
	if (offset < 0) { offset = -offset }
	if (state.tempUnit == "°F") {
		setpoint = setpoint.toInteger()
		offset = offset.toInteger()		
	}

	if (device.currentValue("coolingSetpoint") != setpoint) {
		sendEvent(name: "coolingSetpoint", value: setpoint, unit: state.tempUnit)
		logData << [coolingSetpoint: setpoint]
	}

	def maxSetpoint = setpoint - 4
	if (maxSetpoint < device.currentValue("heatingSetpoint")) {
		sendEvent(name: "heatingSetpoint", value: maxSetpoint, unit: state.tempUnit)
		logData << [heatingSetpoint: maxSetpoint]
	}
	
	runIn(1, updateOperation)
	if (logData != [:]) {
		logInfo("setCoolingSetpoint: ${logData}")
	}
}
def setSamsungAutoSetpoint(setpoint) {
	if (setpoint < state.minSetpoint || setpoint > state.maxSetpoint) {
		logWarn("setSamsungAutoSetpoint: Setpoint out of range")
		return
	}
	if (state.tempUnit == "°F") {
		setpoint = setpoint.toInteger()
	}
	def logData = [:]
	if (device.currentValue("samsungAutoSetpoint") != setpoint) {
		sendEvent(name: "samsungAutoSetpoint", value: setpoint, unit: state.tempUnit)
		sendEvent(name: "level", value: setpoint)
		logData << [samsungAutoSetpoint: setpoint]
		if (samsungAuto && device.currentValue("thermostatMode") == "auto") {
			setThermostatSetpoint(setpoint)
		}
	}
	
	runIn(1, updateOperation)
	if (logData != [:]) {
		logInfo("setSamsungAutoSetpoint: ${logData}")
	}
}
def setLevel(level) { setSamsungAutoSetpoint(level) }
def setThermostatSetpoint(setpoint) {
	def cmdData = [
		component: "main",
		capability: "thermostatCoolingSetpoint",
		command: "setCoolingSetpoint",
		arguments: [setpoint]]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setThermostatSetpoint: [cmd: ${setpoint}, ${cmdStatus}]")
}

def togglePanelLight() {
	def newOnOff = "on"
	if (device.currentValue("lightStatus") == "on") {
		newOnOff = "off"
	}
	def lightCmd = "Light_Off"
	if (newOnOff == "off") {
		lightCmd = "Light_On"
	}
	def arguments = [
		"mode/vs/0",
		["x.com.samsung.da.options":[lightCmd]]
		]

	def cmdData = [
		component: "main",
		capability: "execute",
		command: "execute",
		arguments: arguments]
	def cmdStatus = deviceCommand(cmdData)
	logInfo("setThermostatSetpoint: [cmd: ${setpoint}, ${cmdStatus}]")
}

def stringPostHttp(cmdString) {
	def respData = [:]
	def sendCmdParams = [
			uri: "https://api.smartthings.com/v1",
			path: "/devices/${stDeviceId.trim()}/commands",
			headers: ['Authorization': 'Bearer ' + stApiKey.trim()],
			body : cmdString]
	try {
		httpPost(sendCmdParams) {resp ->
			if (resp.status == 200 && resp.data != null) {
				respData << [status: "OK", results: resp.data.results]
				refresh()
			} else {
				respData << [status: "FAILED",
							 httpCode: resp.status,
							 errorMsg: resp.errorMessage]
			}
		}
	} catch (error) {
		respData << [status: "FAILED",
					 httpCode: "Timeout",
					 errorMsg: error]
	}
	return respData
}

def distResp(resp, data) {
	def respLog = [:]
	if (resp.status == 200) {
		try {
			def respData = new JsonSlurper().parseText(resp.data)
			if (data.reason == "deviceSetup") {
				deviceSetupParse(respData.components.main)
			}
			statusParse(respData.components.main)
		} catch (err) {
			respLog << [status: "ERROR",
						errorMsg: err,
						respData: resp.data]
		}
	} else {
		respLog << [status: "ERROR",
					httpCode: resp.status,
					errorMsg: resp.errorMessage]
	}
	if (respLog != [:]) {
//		logWarn("distResp: ${respLog}")
	}
}

def deviceSetupParse(parseData) {
	def logData = [:]
	tempUnit = parseData.temperatureMeasurement.temperature.unit
	state.tempUnit = "°${tempUnit}"
	logData << [tempUnit: tempUnit]

	def supportedThermostatModes = parseData.airConditionerMode.supportedAcModes.value
	supportedThermostatModes << "samsungAuto"
	supportedThermostatModes << "off"
	sendEvent(name: "supportedThermostatModes", value: supportedThermostatModes)
	logData << [supportedThermostatModes: supportedThermostatModes]

	def supportedThermostatFanModes = parseData.airConditionerFanMode.supportedAcFanModes.value
	sendEvent(name: "supportedThermostatFanModes", value: supportedThermostatFanModes)
	logData << [supportedThermostatFanModes: supportedThermostatFanModes]

	state.minSetpoint = parseData["custom.thermostatSetpointControl"].minimumSetpoint.value
	state.maxSetpoint = parseData["custom.thermostatSetpointControl"].maximumSetpoint.value 
	
	//	Initialize setpoints if required.
	def coolSetpoint = 76
	def heatSetpoint = 68
	def samsungAutoSetpoint = 72
	if (state.tempUnit == "°C") {
		coolSetpoint = 24
		heatSetpoint = 20
		samsungAutoSetpoint = 22
	}
	if (!device.currentValue("coolingSetpoint")) {
		sendEvent(name: "coolingSetpoint", value: coolSetpoint, unit: state.tempUnit)
	}
	if (!device.currentValue("heatingSetpoint")) {
		sendEvent(name: "heatingSetpoint", value: heatSetpoint, unit: state.tempUnit)
	}
	if (!device.currentValue("samsungAutoSetpoint")) {
		sendEvent(name: "samsungAutoSetpoint", value: samsungAutoSetpoint, unit: state.tempUnit)
	}
	logInfo("deviceSetupParse: ${logData}")
}

def statusParse(parseData) {
	def logData = [:]
	
	def temperature = parseData.temperatureMeasurement.temperature.value
	if (device.currentValue("temperature") != temperature) {
		sendEvent(name: "temperature", value: temperature, unit: tempUnit)
		logData << [temperature: temperature]
	}

	def thermostatSetpoint = parseData.thermostatCoolingSetpoint.coolingSetpoint.value
	if (device.currentValue("thermostatSetpoint") != thermostatSetpoint) {
		sendEvent(name: "thermostatSetpoint", value: thermostatSetpoint, unit: tempUnit)
		logData << [thermostatSetpoint: thermostatSetpoint]
	}

	def onOff = parseData.switch.switch.value
	def thermostatMode = parseData.airConditionerMode.airConditionerMode.value
	state.rawMode = thermostatMode
	if (state.autoMode) {
		thermostatMode = "auto"
	} else if (onOff == "off") {
		thermostatMode = "off"
	} else if (thermostatMode != "cool" && thermostatMode != "heat" &&
			   thermostatMode != "wind" && thermostatMode != "dry" &&
			   thermostatMode != "off") {
		thermostatMode = "samsungAuto"
	}
	if (device.currentValue("thermostatMode") != thermostatMode) {
		sendEvent(name: "thermostatMode", value: thermostatMode)
		logData << [thermostatMode: thermostatMode]
	}

	def thermostatFanMode = parseData.airConditionerFanMode.fanMode.value
	if (device.currentValue("thermostatFanMode") != thermostatFanMode) {
		sendEvent(name: "thermostatFanMode", value: thermostatFanMode)
		logData << [thermostatFanMode: thermostatFanMode]
	}
	
	def execStatus = parseData.execute.data.value.payload["x.com.samsung.da.options"]
	def lightStatus = "on"
	if (execStatus.contains("Light_On")) { lightStatus = "off" }
	if (device.currentValue("lightStatus") != lightStatus) {
		sendEvent(name: "lightStatus", value: lightStatus)
		logData << [lightStatus: lightStatus]
	}
	
	runIn(2, updateOperation)
	if (simulate() == true) {
		runIn(4, listAttributes, [data: true])
	} else {
		runIn(4, listAttributes)
	}
}

def updateOperation() {
	def respData = [:]
	def setpoint = device.currentValue("thermostatSetpoint")
	def temperature = device.currentValue("temperature")
	def heatPoint = device.currentValue("heatingSetpoint")
	def coolPoint = device.currentValue("coolingSetpoint")
	def samsungPoint = device.currentValue("samsungAutoSetpoint")
	def mode = device.currentValue("thermostatMode")
	def rawMode = state.rawMode
	def autoMode = state.autoMode

	if (state.autoMode) {
		def opMode
		if (temperature <= heatPoint) {
			opMode = "heat"
		} else if (temperature >= coolSetpoint) {
			opMode = "cool"
		}
		if (rawMode != opMode) {
			def cmdStatus = sendModeCommand(opMode)
			respData << [sendModeCommand: opMode]
			logInfo("updateOperation: ${respData}")
			return
		}
	}

	def newSetpoint = setpoint
	if (rawMode == "cool") {
		newSetpoint = coolPoint
	} else if (rawMode == "heat") {
		newSetpoint = heatPoint
	} else if (mode == "samsungAuto") {
		newSetpoint = samsungPoint
	}
	if (newSetpoint != setpoint) {
		setThermostatSetpoint(newSetpoint)
		respData << [thermostatSetpoint: newSetpoint]
		logInfo("updateOperation: ${respData}")
		return
	}
	
	def opState = "idle"
	if (mode == "off" || mode == "wind" || mode == "dry") {
		opState = mode
	} else if (mode == "samsungAuto") {
		if (temperature - setpoint > 1.5) {
			opState = "cooling"
		} else if (setpoint - temperature > 1.5) {
			opState = "heating"
		}
	} else if (rawMode == "cool") {
		if (temperature - setpoint > 0) {
			opState = "cooling"
		}
	} else if (rawMode == "heat") {
		if (setpoint - temperature > 0) {
			opState = "heating"
		}
	}
	if (device.currentValue("thermostatOperatingState") != opState) {
		sendEvent(name: "thermostatOperatingState", value: opState)
		respData << [thermostatOperatingState: opState]
		logInfo("updateOperation: ${respData}")
	}
}

//	===== Library Integration =====
#include davegut.Logging
#include davegut.ST-Communications
#include davegut.ST-Common
def simulate() { return true}
#include davegut.Samsung-HVAC-Sim
