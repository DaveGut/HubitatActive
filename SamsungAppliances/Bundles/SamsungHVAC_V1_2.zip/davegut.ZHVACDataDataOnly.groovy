metadata {
	definition (name: "Z HVAC Data Data Only",
				namespace: "davegut",
				author: "David Gutheinz",
				importUrl: ""
			   ){
	}
}

/*def Light_Off(){
    def params = buildParms("execute", "execute", ["mode/vs/0",["x.com.samsung.da.options":["Light_Off"]]])
    post(params)
}

def buildParms(String capability_, String command_, arg_ = ""){
    def builder = new groovy.json.JsonBuilder()
    def c
    
    if (arg_ instanceof List){
        c = [component:"main", capability:capability_, command:command_, arguments:arg_.collect()]
    }
    else if(arg_ != ""){
        def d = [arg_]
        c = [component:"main", capability:capability_, command:command_, arguments:d.collect()]
    }
    else{
        c = [component:"main", capability:capability_, command:command_]
    }
    
    builder commands:[c]

    def params = [
        uri: "https://api.smartthings.com/v1/devices/" + deviceid + "/commands",
        headers: ['Authorization' : "Bearer " + token],
        body: builder.toString()
    ]
    log.debug(builder.toString())
    return params
}*/






/*

dev:9772022-05-19 12:50:38.581 pm trace[devDescription: [deviceId:a13f7d6a-ea3c-97e7-a705-000001200000, name:Air Conditioner, label:Air Conditioner, manufacturerName:Samsung Electronics, presentationId:DA-SAC-INDOOR-000001-SUB, deviceManufacturerCode:Samsung Electronics, locationId:52b311c5-54bf-4ed3-acd2-a6333733769f, ownerId:756bc1e2-2856-1ab8-7efa-d698fbcdb042, roomId:5173ce73-cdae-43ad-b3ba-c92f13d0d890, deviceTypeName:Samsung OCF Air Conditioner, components:[[id:main, label:main, capabilities:[[id:ocf, version:1], [id:switch, version:1], [id:airConditionerMode, version:1], [id:airConditionerFanMode, version:1], [id:fanOscillationMode, version:1], [id:temperatureMeasurement, version:1], [id:thermostatCoolingSetpoint, version:1], [id:relativeHumidityMeasurement, version:1], [id:powerConsumptionReport, version:1], [id:demandResponseLoadControl, version:1], [id:remoteControlStatus, version:1], [id:refresh, version:1], [id:execute, version:1], [id:airQualitySensor, version:1], [id:dustSensor, version:1], [id:veryFineDustSensor, version:1], [id:custom.spiMode, version:1], [id:custom.thermostatSetpointControl, version:1], [id:custom.airConditionerOptionalMode, version:1], [id:custom.energyType, version:1], [id:custom.dustFilter, version:1], [id:custom.autoCleaningMode, version:1], [id:custom.deviceReportStateConfiguration, version:1], [id:custom.deodorFilter, version:1], [id:custom.hepaFilter, version:1], [id:custom.veryFineDustFilter, version:1], [id:custom.disabledCapabilities, version:1], [id:samsungce.softwareUpdate, version:1], [id:samsungce.driverVersion, version:1]], categories:[[name:AirConditioner, categoryType:manufacturer]]]], createTime:2022-03-01T06:44:26.313Z, parentDeviceId:a13f7d6a-ea3c-97e7-a705-b6f0433ff66c, profile:[id:1194a9ba-ece4-34ce-a29c-b258fa60e74b], ocf:[ocfDeviceType:oic.d.airconditioner, name:Air Conditioner, specVersion:core.1.1.0, verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, manufacturerName:Samsung Electronics, modelNumber:SAC_BIGDUCT|201207|61003E00001400840400010000000000, platformVersion:4.0, platformOS:Tizen, hwVersion:, firmwareVersion:20211102.1, vendorId:DA-SAC-INDOOR-000001-SUB, vendorResourceClientServerVersion:2.2.18, lastSignupTime:2022-03-01T06:44:24.656237Z], type:OCF, restrictionTier:0, allowed:[]]]

dev:9772022-05-19 12:50:37.388 pm trace[devStatus: [
	components:[
		main:[
			relativeHumidityMeasurement:[
				DISABLED, humidity:[value:null]], 
			custom.thermostatSetpointControl:[
				NOTIMPLEMENTED,
				minimumSetpoint:[value:16.0, unit:C, timestamp:2022-05-16T23:49:52.353Z], 
				maximumSetpoint:[value:30.0, unit:C, timestamp:2022-03-01T06:44:28.010Z]], 
			airConditionerMode:[
				supportedAcModes:[value:[auto, cool, dry, wind, heat], timestamp:2022-03-01T06:44:28.010Z],
				airConditionerMode:[value:heat, timestamp:2022-05-16T23:49:52.353Z]], 
			custom.spiMode:[
				DISABLED,spiMode:[value:null]], 
			airQualitySensor:[
				DISABLED, airQuality:[value:null]], 
			custom.airConditionerOptionalMode:[
				NOTIMPLEMENTED,
				supportedAcOptionalMode:[value:[off], timestamp:2022-03-01T06:44:28.010Z],
				acOptionalMode:[value:null]], 
			switch:[
				switch:[value:off, timestamp:2022-05-19T01:15:12.425Z]], 
			ocf:[
				NOTIMPLEMENTED,
				st:[value:2022-02-28T21:44:26Z, timestamp:2022-03-01T06:44:27.389Z], mndt:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				 mnfv:[value:20211102.1, timestamp:2022-03-01T06:44:26.956Z], mnhw:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				 di:[value:a13f7d6a-ea3c-97e7-a705-000001200000, timestamp:2022-03-01T06:44:26.956Z], mnsl:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				 dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-03-01T06:44:26.956Z], n:[value:Air Conditioner, timestamp:2022-03-01T06:44:26.956Z], 
				 mnmo:[value:SAC_BIGDUCT|201207|61003E00001400840400010000000000, timestamp:2022-03-01T06:44:26.956Z], 
				 vid:[value:DA-SAC-INDOOR-000001-SUB, timestamp:2022-03-01T06:44:26.956Z], mnmn:[value:Samsung Electronics, timestamp:2022-03-01T06:44:26.956Z], 
				 mnml:[value:, timestamp:2022-03-01T06:44:26.956Z], mnpv:[value:4.0, timestamp:2022-03-01T06:44:26.956Z], 
				 mnos:[value:Tizen, timestamp:2022-03-01T06:44:26.956Z], pi:[value:a13f7d6a-ea3c-97e7-a705-000001200000, timestamp:2022-03-01T06:44:26.956Z], 
				 icv:[value:core.1.1.0, timestamp:2022-03-01T06:44:26.956Z]], 
			airConditionerFanMode:[
				fanMode:[value:auto, timestamp:2022-05-17T08:26:39.726Z], 
				supportedAcFanModes:[value:[auto, low, medium, high], timestamp:2022-03-01T06:44:28.010Z]], 
			custom.disabledCapabilities:[
				NOTIMPLEMENTED,
				disabledCapabilities:[value:[
				custom.spiMode, remoteControlStatus, relativeHumidityMeasurement, demandResponseLoadControl, custom.veryFineDustFilter, 
				custom.hepaFilter, custom.deodorFilter, airQualitySensor, dustSensor, veryFineDustSensor, custom.airConditionerOptionalMode], 
															   timestamp:2022-03-01T06:44:28.010Z]], 
			samsungce.driverVersion:[
				NOTIMPLEMENTED,versionNumber:[value:21123001, timestamp:2022-03-01T06:44:26.981Z]], 
			fanOscillationMode:[
				NOTIMPLEMENTED, supportedFanOscillationModes:[value:null], fanOscillationMode:[value:null]],
			temperatureMeasurement:[
				temperature:[value:26.5, unit:C, timestamp:2022-05-19T03:17:48.322Z]], 
			custom.hepaFilter:[
				DISABLED,
				hepaFilterCapacity:[value:null], hepaFilterStatus:[value:null], hepaFilterResetType:[value:null], 
				hepaFilterUsageStep:[value:null], hepaFilterUsage:[value:null], hepaFilterLastResetDate:[value:null]], 
			dustSensor:[dustLevel:[value:null], fineDustLevel:[value:null]], 
			custom.deviceReportStateConfiguration:[
				NOTIMPLEMENTED,
				reportStateRealtimePeriod:[value:enabled, timestamp:2022-03-01T06:44:55.976Z], 
				reportStateRealtime:[value:[state:disabled], timestamp:2022-05-19T00:58:48.418Z], 
				reportStatePeriod:[value:enabled, timestamp:2022-03-01T06:44:55.976Z]], 
			thermostatCoolingSetpoint:[
				coolingSetpoint:[value:22.0, unit:C, timestamp:2022-05-17T09:02:04.419Z]], 
			demandResponseLoadControl:[
				DISABLED,
				drlcStatus:[value:[drlcType:1, drlcLevel:-1, start:1970-01-01T00:00:00Z, duration:0, override:false], timestamp:2022-03-01T06:44:28.010Z]], 
			powerConsumptionReport:[
				NOTIMPLEMENTED,
				powerConsumption:[value:[energy:240189.0, deltaEnergy:200.0, power:1.721, powerEnergy:0.23990616003672283, 
										 persistedEnergy:240189.0, energySaved:0, start:2022-05-19T01:07:19Z, end:2022-05-19T01:15:12Z], timestamp:2022-05-19T01:15:12.526Z]], 
			custom.autoCleaningMode:[
				NOTIMPLEMENTED,autoCleaningMode:[value:off, timestamp:2022-03-01T06:44:27.010Z]], 
			refresh:[:], 
			execute:[
				NOTIMPLEMENTED,
				data:[
					value:[
						payload:[
							rt:[x.com.samsung.da.temperatures], 
							if:[oic.if.a], 
							x.com.samsung.da.current:26.5, 
							x.com.samsung.da.desired:22.0,
							x.com.samsung.da.minimum:16.0, 
							x.com.samsung.da.maximum:30.0, 
							x.com.samsung.da.increment:1.0, 
							x.com.samsung.da.unit:Celsius,
							x.com.samsung.da.displaycondition.text:Enable, 
							x.com.samsung.da.displaycondition.button:Enable]], 
					  data:[href:/temperatures/indoor/vs/0], timestamp:2022-05-19T03:17:48.322Z]], 
			custom.dustFilter:[
				dustFilterUsageStep:[value:null], dustFilterUsage:[value:null], dustFilterLastResetDate:[value:null], 
				dustFilterStatus:[value:normal, timestamp:2022-03-01T06:44:28.010Z], 
				dustFilterCapacity:[value:2000, unit:Hour, timestamp:2022-03-01T06:44:28.010Z], 
				dustFilterResetType:[value:[washable], timestamp:2022-03-01T06:44:28.010Z]], 
			remoteControlStatus:[
				DISABLED,
				remoteControlEnabled:[value:true, timestamp:2022-03-01T06:44:26.981Z]], 
			custom.deodorFilter:[
				DISABLE,
				deodorFilterLastResetDate:[value:null], 
								 deodorFilterCapacity:[value:null], deodorFilterStatus:[value:null], deodorFilterResetType:[value:null], 
								 deodorFilterUsage:[value:null], deodorFilterUsageStep:[value:null]], 
			custom.energyType:[
				NOTIMPLEMENTED,
				energyType:[value:2.0, timestamp:2022-03-01T06:44:28.010Z], energySavingSupport:[value:false, timestamp:2022-03-01T06:44:28.010Z], 
				drMaxDuration:[value:null], energySavingOperation:[value:null], energySavingOperationSupport:[value:null]], 
			samsungce.softwareUpdate:[
				NOTIMPLEMENTED,
				otnDUID:[value:null], availableModules:[value:[], timestamp:2022-03-01T06:44:28.010Z], 
				newVersionAvailable:[value:false, timestamp:2022-03-01T06:44:28.010Z]], 
			veryFineDustSensor:[
				DISABLED,
				veryFineDustLevel:[value:null]], 
			custom.veryFineDustFilter:[
				DISABLED,
				veryFineDustFilterStatus:[value:null], veryFineDustFilterResetType:[value:null],
				veryFineDustFilterUsage:[value:null], veryFineDustFilterLastResetDate:[value:null],
				veryFineDustFilterUsageStep:[value:null], veryFineDustFilterCapacity:[value:null]]]]]]


devDescription: [
	deviceId:a13f7d6a-ea3c-97e7-a705-000001200000, 
	name:Air Conditioner, label:Air Conditioner, 
	manufacturerName:Samsung Electronics, presentationId:DA-SAC-INDOOR-000001-SUB, deviceManufacturerCode:Samsung Electronics, 
	locationId:52b311c5-54bf-4ed3-acd2-a6333733769f, ownerId:756bc1e2-2856-1ab8-7efa-d698fbcdb042, roomId:5173ce73-cdae-43ad-b3ba-c92f13d0d890, 
	deviceTypeName:Samsung OCF Air Conditioner, 
	components:[
		[
			id:main, label:main, 
			capabilities:[
				[id:ocf, version:1], 
				[id:switch, version:1], 
				[id:airConditionerMode, version:1], 
				[id:airConditionerFanMode, version:1], 
				[id:fanOscillationMode, version:1], 
				[id:temperatureMeasurement, version:1], 
				[id:thermostatCoolingSetpoint, version:1], 
				[id:relativeHumidityMeasurement, version:1], 
				[id:powerConsumptionReport, version:1], 
				[id:demandResponseLoadControl, version:1], 
				[id:remoteControlStatus, version:1], 
				[id:refresh, version:1], 
				[id:execute, version:1], 
				[id:airQualitySensor, version:1], 
				[id:dustSensor, version:1], 
				[id:veryFineDustSensor, version:1], 
				[id:custom.spiMode, version:1], 
				[id:custom.thermostatSetpointControl, version:1], 
				[id:custom.airConditionerOptionalMode, version:1], 
				[id:custom.energyType, version:1], 
				[id:custom.dustFilter, version:1], 
				[id:custom.autoCleaningMode, version:1], 
				[id:custom.deviceReportStateConfiguration, version:1], 
				[id:custom.deodorFilter, version:1], 
				[id:custom.hepaFilter, version:1], 
				[id:custom.veryFineDustFilter, version:1], 
				[id:custom.disabledCapabilities, version:1], 
				[id:samsungce.softwareUpdate, version:1], 
				[id:samsungce.driverVersion, version:1]], 
			categories:[[name:AirConditioner, categoryType:manufacturer]]]], 
	createTime:2022-03-01T06:44:26.313Z, 
	parentDeviceId:a13f7d6a-ea3c-97e7-a705-b6f0433ff66c, 
	profile:[id:1194a9ba-ece4-34ce-a29c-b258fa60e74b], 
	ocf:[ocfDeviceType:oic.d.airconditioner, name:Air Conditioner, specVersion:core.1.1.0, verticalDomainSpecVersion:res.1.1.0,sh.1.1.0, manufacturerName:Samsung Electronics, 
		 modelNumber:SAC_BIGDUCT|201207|61003E00001400840400010000000000, platformVersion:4.0, platformOS:Tizen, hwVersion:, firmwareVersion:20211102.1, 
		 vendorId:DA-SAC-INDOOR-000001-SUB, vendorResourceClientServerVersion:2.2.18, lastSignupTime:2022-03-01T06:44:24.656237Z], type:OCF, restrictionTier:0, allowed:[]]]


[
	components:[
		main:[
			relativeHumidityMeasurement:[humidity:[value:null]], 
			custom.thermostatSetpointControl:[
				minimumSetpoint:[value:16.0, unit:C, timestamp:2022-05-16T23:49:52.353Z], 
				maximumSetpoint:[value:30.0, unit:C, timestamp:2022-03-01T06:44:28.010Z]], 
			airConditionerMode:[supportedAcModes:[value:[auto, cool, dry, wind, heat], timestamp:2022-03-01T06:44:28.010Z], 
								airConditionerMode:[value:heat, timestamp:2022-05-16T23:49:52.353Z]], 
			custom.spiMode:[spiMode:[value:null]], 
			airQualitySensor:[airQuality:[value:null]], 
			custom.airConditionerOptionalMode:[
				supportedAcOptionalMode:[value:[off], timestamp:2022-03-01T06:44:28.010Z], 
				acOptionalMode:[value:null]], 
			switch:[switch:[value:off, timestamp:2022-05-19T01:15:12.425Z]], 
			ocf:[
				st:[value:2022-02-28T21:44:26Z, timestamp:2022-03-01T06:44:27.389Z], 
				mndt:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				mnfv:[value:20211102.1, timestamp:2022-03-01T06:44:26.956Z], 
				mnhw:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				di:[value:a13f7d6a-ea3c-97e7-a705-000001200000, timestamp:2022-03-01T06:44:26.956Z], 
				mnsl:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				dmv:[value:res.1.1.0,sh.1.1.0, timestamp:2022-03-01T06:44:26.956Z], 
				n:[value:Air Conditioner, timestamp:2022-03-01T06:44:26.956Z], 
				mnmo:[value:SAC_BIGDUCT|201207|61003E00001400840400010000000000, timestamp:2022-03-01T06:44:26.956Z], 
				vid:[value:DA-SAC-INDOOR-000001-SUB, timestamp:2022-03-01T06:44:26.956Z], 
				mnmn:[value:Samsung Electronics, timestamp:2022-03-01T06:44:26.956Z], 
				mnml:[value:, timestamp:2022-03-01T06:44:26.956Z], 
				mnpv:[value:4.0, timestamp:2022-03-01T06:44:26.956Z], 
				mnos:[value:Tizen, timestamp:2022-03-01T06:44:26.956Z], 
				pi:[value:a13f7d6a-ea3c-97e7-a705-000001200000, timestamp:2022-03-01T06:44:26.956Z], 
				icv:[value:core.1.1.0, timestamp:2022-03-01T06:44:26.956Z]], 
			airConditionerFanMode:[fanMode:[value:auto, timestamp:2022-05-17T08:26:39.726Z], 
								   supportedAcFanModes:[value:[auto, low, medium, high], timestamp:2022-03-01T06:44:28.010Z]], 
			custom.disabledCapabilities:[
				disabledCapabilities:[value:[
					custom.spiMode, remoteControlStatus, relativeHumidityMeasurement, demandResponseLoadControl, 
					custom.veryFineDustFilter, custom.hepaFilter, custom.deodorFilter, airQualitySensor, 
					dustSensor, veryFineDustSensor, custom.airConditionerOptionalMode], timestamp:2022-03-01T06:44:28.010Z]], 
			samsungce.driverVersion:[versionNumber:[value:21123001, timestamp:2022-03-01T06:44:26.981Z]], 
			fanOscillationMode:[supportedFanOscillationModes:[value:null], fanOscillationMode:[value:null]], 
			temperatureMeasurement:[temperature:[value:26.5, unit:C, timestamp:2022-05-19T03:17:48.322Z]], 
			custom.hepaFilter:[hepaFilterCapacity:[value:null], 
							   hepaFilterStatus:[value:null], 
							   hepaFilterResetType:[value:null], 
							   hepaFilterUsageStep:[value:null], 
							   hepaFilterUsage:[value:null], 
							   epaFilterLastResetDate:[value:null]], 
			dustSensor:[dustLevel:[value:null], fineDustLevel:[value:null]], 
			custom.deviceReportStateConfiguration:[
				reportStateRealtimePeriod:[value:enabled, timestamp:2022-03-01T06:44:55.976Z], 
				reportStateRealtime:[value:[state:disabled], timestamp:2022-05-19T00:58:48.418Z], 
				reportStatePeriod:[value:enabled, timestamp:2022-03-01T06:44:55.976Z]], 
			thermostatCoolingSetpoint:[
				coolingSetpoint:[value:22.0, unit:C, timestamp:2022-05-17T09:02:04.419Z]], 
			demandResponseLoadControl:[
				drlcStatus:[value:[drlcType:1, drlcLevel:-1, start:1970-01-01T00:00:00Z, duration:0, override:false], timestamp:2022-03-01T06:44:28.010Z]], 
			powerConsumptionReport:[
				powerConsumption:[value:[
					energy:240189.0, deltaEnergy:200.0, power:1.721, powerEnergy:0.23990616003672283, persistedEnergy:240189.0, 
					energySaved:0, start:2022-05-19T01:07:19Z, end:2022-05-19T01:15:12Z], timestamp:2022-05-19T01:15:12.526Z]], 
			custom.autoCleaningMode:[autoCleaningMode:[value:off, timestamp:2022-03-01T06:44:27.010Z]], 
			refresh:[:], 
			execute:[
				data:[
					value:[
						payload:[
							rt:[
								x.com.samsung.da.temperatures],
							if:[oic.if.a], 
							x.com.samsung.da.current:26.5, 
							x.com.samsung.da.desired:22.0, 
							x.com.samsung.da.minimum:16.0, 
							x.com.samsung.da.maximum:30.0, 
							x.com.samsung.da.increment:1.0, 
							x.com.samsung.da.unit:Celsius, 
							x.com.samsung.da.type:Air,
							x.com.samsung.da.displaycondition.text:Enable, 
							x.com.samsung.da.displaycondition.button:Enable]], 
					data:[
						href:/temperatures/indoor/vs/0], 
					timestamp:2022-05-19T03:17:48.322Z]], 
			custom.dustFilter:[dustFilterUsageStep:[value:null], 
							   dustFilterUsage:[value:null], dustFilterLastResetDate:[value:null], 
							   dustFilterStatus:[value:normal, timestamp:2022-03-01T06:44:28.010Z], 
							   dustFilterCapacity:[value:2000, unit:Hour, timestamp:2022-03-01T06:44:28.010Z], 
							   dustFilterResetType:[value:[washable], timestamp:2022-03-01T06:44:28.010Z]], 
			remoteControlStatus:[remoteControlEnabled:[value:true, timestamp:2022-03-01T06:44:26.981Z]], 
			custom.deodorFilter:[
				deodorFilterLastResetDate:[value:null],deodorFilterCapacity:[value:null], 
				deodorFilterStatus:[value:null], deodorFilterResetType:[value:null], 
				deodorFilterUsage:[value:null], deodorFilterUsageStep:[value:null]], 
			custom.energyType:[
				energyType:[value:2.0, timestamp:2022-03-01T06:44:28.010Z], 
				energySavingSupport:[value:false, timestamp:2022-03-01T06:44:28.010Z], 
				drMaxDuration:[value:null], energySavingOperation:[value:null], 
				energySavingOperationSupport:[value:null]], 
			samsungce.softwareUpdate:[
				otnDUID:[value:null], availableModules:[value:[], timestamp:2022-03-01T06:44:28.010Z], 
				newVersionAvailable:[value:false, timestamp:2022-03-01T06:44:28.010Z]], 
			veryFineDustSensor:[veryFineDustLevel:[value:null]], custom.veryFineDustFilter:[veryFineDustFilterStatus:[value:null], veryFineDustFilterResetType:[value:null], veryFineDustFilterUsage:[value:null], veryFineDustFilterLastResetDate:[value:null], veryFineDustFilterUsageStep:[value:null], veryFineDustFilterCapacity:[value:null]]]]]]

*/


























