library (
	name: "Samsung-HVAC-Sim",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "ST Samsung AC Simulator",
	category: "utilities",
	documentationLink: ""
)

def setTemperature(temperature) {
	state.temperature = temperature.toInteger()
	poll()
}

def testData() {
	if (!state.fanMode) { 
		state.switch = "off"
		state.fanMode = "auto"
		state.temperature = 55
		state.setpoint = 60
		state.mode = "auto"
		state.light = ["Sleep_0", "Light_On", "Volume_Mute"]
	}
	
	return [
			switch:[switch:[value: state.switch]],
			"custom.thermostatSetpointControl":[
				minimumSetpoint:[value:60],
				maximumSetpoint:[value:86]],
			airConditionerFanMode:[
				supportedAcFanModes:[value:["auto", "low", "medium", "high"]],
				fanMode:[value: state.fanMode]],
			temperatureMeasurement:[temperature:[value: state.temperature, unit: "F"]],
			thermostatCoolingSetpoint:[coolingSetpoint:[value: state.setpoint, unit: "F"]],
			airConditionerMode:[
				supportedAcModes:[value:["auto", "cool", "dry", "wind", "heat"]],
				airConditionerMode:[value: state.mode]],
			execute:[data:[value:[payload:["x.com.samsung.da.options": state.light]]]]
			]
}

def testResp(cmdData) {
	def cmd = cmdData.command
	def args = cmdData.arguments
	switch(cmd) {
		case "off":
			state.switch = "off"
			state.mode = "off"
			break
		case "setAirConditionerMode":
			state.switch = "on"
			state.mode = args[0]
			break
		case "setFanMode":
			state.fanMode = args[0]
			break
		case "setCoolingSetpoint":
			state.setpoint = args[0]
			break
		case "execute":
			def onOff = args[0]["mode/vs/0"]["x.com.samsung.da.options"][0]
			state.light = ["Sleep_0", onOff, "Volume_Mute"]
			break
		case "refresh":
			break
		default:
			logWarn("testResp: [unhandled: ${cmdData}]")
	}
	
	return [
		cmdData: cmdData,
		status: [status: "OK",
				 results:[[id: "e9585885-3848-4fea-b0db-ece30ff1701e", status: "ACCEPTED"]]]]
}
